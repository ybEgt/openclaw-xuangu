const https = require('https');
const fs = require('fs');
const path = require('path');

// 使用环境变量中的API密钥
const MX_APIKEY = process.env.MX_APIKEY || "mkt_fgN0XtXWjMxR9zxtDS9EkHx9pz6-OzfHl06C1ywGdls";

// 智能选股策略
const strategies = [
    {
        name: "短线强势股筛选",
        query: "A股主板 今日涨幅大于5% 成交量大于2亿",
        desc: "筛选今日强势上涨且成交活跃的股票",
        minCount: 10,
        maxCount: 20
    }
];

function callMXStockScreener(query) {
    return new Promise((resolve, reject) => {
        const postData = JSON.stringify({
            keyword: query
        });

        const options = {
            hostname: 'mkapi2.dfcfs.com',
            port: 443,
            path: '/finskillshub/api/claw/stock-screen',
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'apikey': MX_APIKEY,
                'Content-Length': Buffer.byteLength(postData)
            }
        };

        const req = https.request(options, (res) => {
            let data = '';
            
            res.on('data', (chunk) => {
                data += chunk;
            });
            
            res.on('end', () => {
                try {
                    const result = JSON.parse(data);
                    resolve(result);
                } catch (e) {
                    reject(new Error(`JSON解析错误: ${e.message}`));
                }
            });
        });

        req.on('error', (e) => {
            reject(new Error(`请求错误: ${e.message}`));
        });

        req.write(postData);
        req.end();
    });
}

// 智能解析股票数据
function parseStockData(stock, columns) {
    // 创建字段映射
    const fieldMap = {};
    columns.forEach(col => {
        if (col.key && col.title) {
            fieldMap[col.key] = {
                title: col.title,
                unit: col.unit || '',
                dataType: col.dataType
            };
        }
    });
    
    // 提取关键信息
    const result = {
        code: stock.SECURITY_CODE || '',
        name: stock.SECURITY_SHORT_NAME || '',
        market: stock.MARKET_SHORT_NAME || '',
        serial: stock.SERIAL || ''
    };
    
    // 动态提取数值字段
    const numericFields = {};
    for (const [key, value] of Object.entries(stock)) {
        if (key === 'SECURITY_CODE' || key === 'SECURITY_SHORT_NAME' || 
            key === 'MARKET_SHORT_NAME' || key === 'SERIAL') {
            continue;
        }
        
        // 尝试解析数值
        if (typeof value === 'string' || typeof value === 'number') {
            const strValue = String(value);
            
            // 检查是否是数值字段
            if (fieldMap[key]) {
                const fieldInfo = fieldMap[key];
                numericFields[fieldInfo.title] = {
                    value: strValue,
                    unit: fieldInfo.unit,
                    rawKey: key
                };
            } else if (key.includes('CHG') || key.includes('涨跌幅')) {
                numericFields['涨跌幅'] = { value: strValue, unit: '%', rawKey: key };
            } else if (key.includes('NEWEST_PRICE') || key.includes('最新价')) {
                numericFields['最新价'] = { value: strValue, unit: '元', rawKey: key };
            } else if (key.includes('TURNOVER_RATE') || key.includes('换手率')) {
                numericFields['换手率'] = { value: strValue, unit: '%', rawKey: key };
            } else if (key.includes('MARKET_VALUE') || key.includes('市值')) {
                numericFields['市值'] = { value: strValue, unit: '元', rawKey: key };
            } else if (key.includes('PE_') || key.includes('市盈率')) {
                numericFields['市盈率'] = { value: strValue, unit: '倍', rawKey: key };
            } else if (key.includes('VOLUME') || key.includes('成交量')) {
                numericFields['成交量'] = { value: strValue, unit: '股', rawKey: key };
            }
        }
    }
    
    result.numericFields = numericFields;
    return result;
}

// 风险评估
function assessRisk(parsedStock) {
    const riskFactors = [];
    let riskLevel = "低";
    
    const fields = parsedStock.numericFields;
    
    // 检查涨跌幅
    const change = parseFloat(fields['涨跌幅']?.value || 0);
    if (change > 9.9) { // 接近涨停
        riskFactors.push(`涨幅较大(${change}%)`);
        riskLevel = "中";
    }
    
    // 检查换手率
    const turnover = parseFloat(fields['换手率']?.value || 0);
    if (turnover > 20) {
        riskFactors.push(`换手率过高(${turnover}%)`);
        riskLevel = "高";
    } else if (turnover > 10) {
        riskFactors.push(`换手率较高(${turnover}%)`);
        riskLevel = "中";
    }
    
    // 检查市盈率
    const pe = parseFloat(fields['市盈率']?.value || 0);
    if (pe > 100) {
        riskFactors.push(`市盈率过高(${pe})`);
        riskLevel = "高";
    } else if (pe < 0) {
        riskFactors.push(`净利润为负(${pe})`);
        riskLevel = "高";
    } else if (pe > 50) {
        riskFactors.push(`市盈率偏高(${pe})`);
        riskLevel = "中";
    }
    
    // 检查成交量
    const volume = fields['成交量']?.value || '0';
    if (volume.includes('万') && parseFloat(volume) < 100) {
        riskFactors.push(`成交量偏小(${volume})`);
        riskLevel = "中";
    }
    
    return {
        riskLevel,
        riskFactors,
        change,
        turnover,
        pe
    };
}

async function runSmartAnalysis() {
    console.log("🧠 A股主板短线智能选股分析");
    console.log("=".repeat(60));
    console.log("📅 分析时间:", new Date().toLocaleString('zh-CN', { timeZone: 'Asia/Shanghai' }));
    console.log("=".repeat(60));
    
    const query = "A股主板 今日涨幅大于5% 成交量大于1亿";
    console.log(`🔍 选股条件: ${query}`);
    
    try {
        const result = await callMXStockScreener(query);
        
        if (result.status === 0 && result.data && result.data.code === 0) {
            const data = result.data.data;
            const total = data.securityCount || 0;
            
            console.log(`✅ 筛选结果: ${total} 只股票符合条件`);
            
            if (data.allResults && data.allResults.result) {
                const columns = data.allResults.result.columns || [];
                const stocks = data.allResults.result.dataList || [];
                
                console.log(`📊 获取到 ${stocks.length} 只股票详细数据`);
                
                // 解析前20只股票
                const analyzedStocks = stocks.slice(0, 20).map(stock => {
                    const parsed = parseStockData(stock, columns);
                    const risk = assessRisk(parsed);
                    
                    return {
                        ...parsed,
                        riskAssessment: risk
                    };
                });
                
                // 按涨幅排序
                analyzedStocks.sort((a, b) => b.riskAssessment.change - a.riskAssessment.change);
                
                // 显示分析结果
                console.log("\n🏆 涨幅排名前10的股票分析:");
                console.log("=".repeat(60));
                
                analyzedStocks.slice(0, 10).forEach((stock, idx) => {
                    console.log(`\n${idx + 1}. ${stock.name} (${stock.code}.${stock.market})`);
                    console.log(`   📈 涨幅: ${stock.riskAssessment.change}%`);
                    
                    const fields = stock.numericFields;
                    if (fields['最新价']) {
                        console.log(`   💰 价格: ${fields['最新价'].value}${fields['最新价'].unit}`);
                    }
                    if (fields['换手率']) {
                        console.log(`   🔄 换手率: ${fields['换手率'].value}${fields['换手率'].unit}`);
                    }
                    if (fields['市盈率']) {
                        console.log(`   📊 市盈率: ${fields['市盈率'].value}${fields['市盈率'].unit}`);
                    }
                    if (fields['成交量']) {
                        console.log(`   📦 成交量: ${fields['成交量'].value}`);
                    }
                    
                    console.log(`   ⚠️  风险等级: ${stock.riskAssessment.riskLevel}`);
                    if (stock.riskAssessment.riskFactors.length > 0) {
                        console.log(`   🚨 风险因素: ${stock.riskAssessment.riskFactors.join(', ')}`);
                    }
                });
                
                // 生成统计报告
                console.log("\n" + "=".repeat(60));
                console.log("📈 市场统计摘要:");
                console.log("=".repeat(60));
                
                const avgChange = analyzedStocks.reduce((sum, s) => sum + s.riskAssessment.change, 0) / analyzedStocks.length;
                const highRiskCount = analyzedStocks.filter(s => s.riskAssessment.riskLevel === "高").length;
                const mediumRiskCount = analyzedStocks.filter(s => s.riskAssessment.riskLevel === "中").length;
                const lowRiskCount = analyzedStocks.filter(s => s.riskAssessment.riskLevel === "低").length;
                
                console.log(`📊 平均涨幅: ${avgChange.toFixed(2)}%`);
                console.log(`⚠️  高风险股票: ${highRiskCount} 只`);
                console.log(`⚠️  中风险股票: ${mediumRiskCount} 只`);
                console.log(`✅ 低风险股票: ${lowRiskCount} 只`);
                
                // 保存详细报告
                saveDetailedReport(analyzedStocks, total, query);
                
            } else {
                console.log("❌ 无法获取详细股票数据");
            }
        } else {
            console.log(`❌ API错误: ${result.message || '未知错误'}`);
        }
        
    } catch (error) {
        console.error(`❌ 分析失败: ${error.message}`);
    }
}

function saveDetailedReport(stocks, total, query) {
    const timestamp = new Date().toLocaleString('zh-CN', { 
        timeZone: 'Asia/Shanghai',
        hour12: false 
    }).replace(/[/:]/g, '-').replace(/\s+/g, '_');
    
    let report = `# A股主板短线选股智能分析报告\n`;
    report += `## 生成时间: ${timestamp}\n`;
    report += `## 数据来源: 东方财富妙想API\n`;
    report += `## 选股条件: ${query}\n\n`;
    
    report += `## 执行摘要\n`;
    report += `- 符合条件的股票总数: ${total} 只\n`;
    report += `- 详细分析股票数量: ${stocks.length} 只\n`;
    report += `- 分析时间: ${new Date().toLocaleString('zh-CN')}\n\n`;
    
    report += `## 股票详细分析\n`;
    
    stocks.forEach((stock, idx) => {
        report += `### ${idx + 1}. ${stock.name} (${stock.code}.${stock.market})\n`;
        report += `- **涨幅**: ${stock.riskAssessment.change}%\n`;
        report += `- **风险等级**: ${stock.riskAssessment.riskLevel}\n`;
        
        const fields = stock.numericFields;
        if (fields['最新价']) {
            report += `- **最新价**: ${fields['最新价'].value}${fields['最新价'].unit}\n`;
        }
        if (fields['换手率']) {
            report += `- **换手率**: ${fields['换手率'].value}${fields['换手率'].unit}\n`;
        }
        if (fields['市盈率']) {
            report += `- **市盈率**: ${fields['市盈率'].value}${fields['市盈率'].unit}\n`;
        }
        if (fields['成交量']) {
            report += `- **成交量**: ${fields['成交量'].value}\n`;
        }
        
        if (stock.riskAssessment.riskFactors.length > 0) {
            report += `- **风险提示**: ${stock.riskAssessment.riskFactors.join('; ')}\n`;
        }
        
        report += `\n`;
    });
    
    report += `## 风险提示与操作建议\n`;
    report += `### 主要风险\n`;
    report += `1. **市场风险**: 股市波动可能导致短期亏损\n`;
    report += `2. **流动性风险**: 部分股票成交量较小，可能难以快速买卖\n`;
    report += `3. **估值风险**: 高市盈率股票可能存在估值泡沫\n`;
    report += `4. **政策风险**: 监管政策变化可能影响短线交易\n\n`;
    
    report += `### 操作建议\n`;
    report += `1. **仓位控制**: 建议单只股票仓位不超过总资金的10%\n`;
    report += `2. **止损设置**: 建议设置5-8%的止损位\n`;
    report += `3. **持有周期**: 短线操作建议持有1-3个交易日\n`;
    report += `4. **分散投资**: 避免过度集中投资于单一股票或板块\n`;
    report += `5. **实时监控**: 密切关注市场动态和个股表现\n\n`;
    
    report += `## 免责声明\n`;
    report += `本报告仅为研究分析，基于公开数据生成，不构成任何投资建议。\n`;
    report += `投资者应独立判断，自行承担投资风险。股市有风险，入市需谨慎。\n`;
    
    // 保存报告
    const outputDir = path.join(process.env.HOME || process.env.USERPROFILE, '.openclaw', 'workspace', 'research_reports');
    if (!fs.existsSync(outputDir)) {
        fs.mkdirSync(outputDir, { recursive: true });
    }
    
    const dateStr = new Date().toISOString().split('T')[0];
    const reportFile = path.join(outputDir, `smart_analysis_${dateStr}_${timestamp}.md`);
    
    fs.writeFileSync(reportFile, report, 'utf8');
    console.log(`\n✅ 详细分析报告已保存: ${reportFile}`);
    
    // 显示报告摘要
    console.log("\n" + "=".repeat(60));
    console.log("📋 报告摘要");
    console.log("=".repeat(60));
    const summaryLines = report.split('\n').slice(0, 15);
    console.log(summaryLines.join('\n'));
    console.log("\n... (完整报告已保存至文件)");
}

// 运行分析
runSmartAnalysis().catch(console.error);