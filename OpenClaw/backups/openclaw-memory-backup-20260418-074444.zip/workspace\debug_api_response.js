// 调试API响应
console.log("🔍 调试API响应结构");
console.log("=".repeat(70));

const fs = require('fs');
const path = require('path');
const https = require('https');

async function debugApiResponse() {
    const API_KEY = process.env.MX_APIKEY || "mkt_fgN0XtXWjMxR9zxtDS9EkHx9pz6-OzfHl06C1ywGdls";
    const query = "A股主板今日上涨的股票";
    
    console.log(`发送查询: "${query}"`);
    
    const apiResponse = await new Promise((resolve, reject) => {
        const postData = JSON.stringify({ keyword: query });
        const options = {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'apikey': API_KEY,
                'Content-Length': Buffer.byteLength(postData)
            },
            timeout: 15000
        };
        
        const req = https.request("https://mkapi2.dfcfs.com/finskillshub/api/claw/stock-screen", options, (res) => {
            let data = '';
            res.on('data', (chunk) => {
                data += chunk;
            });
            
            res.on('end', () => {
                try {
                    resolve(JSON.parse(data));
                } catch (error) {
                    reject(error);
                }
            });
        });
        
        req.on('error', reject);
        req.write(postData);
        req.end();
    });
    
    console.log(`\n✅ API响应状态: ${apiResponse.status}`);
    console.log(`消息: ${apiResponse.message}`);
    console.log(`请求ID: ${apiResponse.requestId}`);
    
    // 检查数据结构
    console.log(`\n🔍 检查数据结构:`);
    console.log(`data 存在: ${!!apiResponse.data}`);
    console.log(`data.data 存在: ${!!apiResponse.data?.data}`);
    
    const innerData = apiResponse.data?.data;
    if (innerData) {
        console.log(`\n内部数据键: ${Object.keys(innerData).join(', ')}`);
        
        // 检查allResults
        const allResults = innerData.allResults;
        if (allResults) {
            console.log(`\nallResults 结构:`);
            console.log(`  result 存在: ${!!allResults.result}`);
            
            if (allResults.result) {
                console.log(`  result 键: ${Object.keys(allResults.result).join(', ')}`);
                
                const dataList = allResults.result.dataList;
                if (dataList && Array.isArray(dataList)) {
                    console.log(`\n✅ dataList 存在，长度: ${dataList.length}`);
                    
                    if (dataList.length > 0) {
                        console.log(`\n📊 第一条数据示例:`);
                        const firstItem = dataList[0];
                        console.log(`类型: ${typeof firstItem}`);
                        console.log(`键: ${Object.keys(firstItem).join(', ')}`);
                        
                        // 显示前5个键值对
                        const entries = Object.entries(firstItem);
                        for (let i = 0; i < Math.min(5, entries.length); i++) {
                            const [key, value] = entries[i];
                            console.log(`  ${key}: ${value} (${typeof value})`);
                        }
                        
                        // 特别检查代码字段
                        console.log(`\n🔍 检查代码字段:`);
                        const codeFields = ['代码', 'code', '证券代码', 'stock_code'];
                        codeFields.forEach(field => {
                            if (firstItem[field] !== undefined) {
                                console.log(`  ${field}: ${firstItem[field]}`);
                            }
                        });
                    }
                }
            }
        }
        
        // 检查partialResults
        const partialResults = innerData.partialResults;
        if (partialResults) {
            console.log(`\n📄 partialResults 存在，长度: ${partialResults.length}`);
            console.log(`前200字符: ${partialResults.substring(0, 200)}...`);
        }
    }
    
    // 保存完整响应用于分析
    const debugDir = path.join(__dirname, 'debug');
    if (!fs.existsSync(debugDir)) {
        fs.mkdirSync(debugDir, { recursive: true });
    }
    
    const debugFile = path.join(debugDir, `api_response_${Date.now()}.json`);
    fs.writeFileSync(debugFile, JSON.stringify(apiResponse, null, 2), 'utf8');
    
    console.log(`\n💾 完整响应已保存: ${debugFile}`);
    
    return apiResponse;
}

debugApiResponse().then(() => {
    console.log("\n" + "=".repeat(70));
    console.log("🔍 调试完成");
    console.log("=".repeat(70));
    
    console.log("\n💡 根据调试结果:");
    console.log("1. 检查保存的响应文件了解数据结构");
    console.log("2. 根据实际字段名调整数据处理代码");
    console.log("3. 重新运行选股系统");
}).catch(error => {
    console.error(`❌ 调试失败: ${error.message}`);
});