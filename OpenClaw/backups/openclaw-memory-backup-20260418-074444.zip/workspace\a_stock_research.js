const https = require('https');
const fs = require('fs');
const path = require('path');

// 使用环境变量中的API密钥
const MX_APIKEY = process.env.MX_APIKEY || "mkt_fgN0XtXWjMxR9zxtDS9EkHx9pz6-OzfHl06C1ywGdls";

// A股主板短线选股策略
const strategies = [
    {
        name: "动量突破策略",
        query: "A股主板 今日涨幅大于2% 成交量大于1亿 换手率大于3% 市盈率小于50",
        desc: "筛选活跃突破股票，排除过度炒作和小盘股"
    },
    {
        name: "价值动量策略", 
        query: "A股主板 今日涨幅大于1% 市盈率小于30 市净率小于3 净资产收益率大于10%",
        desc: "价值与动量结合，寻找基本面良好的上涨股"
    },
    {
        name: "资金关注策略",
        query: "A股主板 今日主力资金净流入大于1000万 成交量大于2亿",
        desc: "追踪主力资金流向，寻找机构关注股票"
    }
];

function callMXStockScreener(query) {
    return new Promise((resolve, reject) => {
        const postData = JSON.stringify({
            keyword: query
        });

        const options = {
            hostname: 'mkapi2.dfcfs.com',
            port: 443,
            path: '/finskillshub/api/claw/stock-screen',
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'apikey': MX_APIKEY,
                'Content-Length': Buffer.byteLength(postData)
            }
        };

        const req = https.request(options, (res) => {
            let data = '';
            
            res.on('data', (chunk) => {
                data += chunk;
            });
            
            res.on('end', () => {
                try {
                    const result = JSON.parse(data);
                    resolve(result);
                } catch (e) {
                    reject(new Error(`JSON解析错误: ${e.message}`));
                }
            });
        });

        req.on('error', (e) => {
            reject(new Error(`请求错误: ${e.message}`));
        });

        req.write(postData);
        req.end();
    });
}

function analyzeStock(stock, strategyName) {
    // 基础风险评估
    let riskLevel = "中";
    let riskFactors = [];
    
    // 市盈率风险
    const pe = parseFloat(stock['市盈率(动)(倍)(2026.04.17)'] || stock.PE_RATIO || 0);
    if (pe > 100) {
        riskLevel = "高";
        riskFactors.push(`市盈率过高(${pe})`);
    } else if (pe < 0) {
        riskLevel = "高";
        riskFactors.push("净利润为负");
    }
    
    // 换手率风险
    const turnover = parseFloat(stock['换手率(%)(2026.04.17)'] || stock.TURNOVER_RATE || 0);
    if (turnover > 20) {
        riskFactors.push(`换手率过高(${turnover}%)`);
    }
    
    // 市值风险
    const marketCap = parseFloat(stock['总市值(元)(2026.04.17)'] || stock.MARKET_CAP || 0);
    if (marketCap < 30e8) { // 小于30亿
        riskFactors.push(`市值偏小(${(marketCap/1e8).toFixed(1)}亿)`);
    }
    
    return {
        code: stock.SECURITY_CODE || stock.code,
        name: stock.SECURITY_SHORT_NAME || stock.name,
        market: stock.MARKET_SHORT_NAME || stock.market,
        price: stock.NEWEST_PRICE || stock.price,
        change: stock.CHG || stock.change,
        pe: pe,
        turnover: turnover,
        marketCap: marketCap,
        riskLevel: riskLevel,
        riskFactors: riskFactors,
        strategy: strategyName
    };
}

async function runStrategy(strategy) {
    console.log(`\n📊 执行策略: ${strategy.name}`);
    console.log(`📝 描述: ${strategy.desc}`);
    console.log(`🔍 查询条件: ${strategy.query}`);
    
    try {
        const result = await callMXStockScreener(strategy.query);
        
        if (result.status === 0 && result.data && result.data.code === 0) {
            const data = result.data.data;
            const total = data.securityCount || 0;
            
            console.log(`✅ 筛选结果: ${total} 只股票`);
            
            // 解析股票数据
            let stocks = [];
            if (data.allResults && data.allResults.result && data.allResults.result.dataList) {
                stocks = data.allResults.result.dataList.slice(0, 20); // 取前20只
            }
            
            if (stocks.length > 0) {
                console.log(`\n📈 前${Math.min(10, stocks.length)}只股票分析:`);
                
                const analyzedStocks = stocks.slice(0, 10).map(stock => 
                    analyzeStock(stock, strategy.name)
                );
                
                analyzedStocks.forEach((stock, idx) => {
                    console.log(`\n  ${idx + 1}. ${stock.name} (${stock.code}.${stock.market})`);
                    console.log(`     价格: ${stock.price}元, 涨幅: ${stock.change}%`);
                    console.log(`     市盈率: ${stock.pe}, 换手率: ${stock.turnover}%`);
                    console.log(`     市值: ${(stock.marketCap/1e8).toFixed(1)}亿`);
                    console.log(`     风险等级: ${stock.riskLevel}`);
                    if (stock.riskFactors.length > 0) {
                        console.log(`     风险因素: ${stock.riskFactors.join(', ')}`);
                    }
                });
                
                return {
                    strategy: strategy.name,
                    total: total,
                    analyzed: analyzedStocks,
                    success: true
                };
            }
        } else {
            console.log(`❌ 策略执行失败: ${result.message || '未知错误'}`);
            return {
                strategy: strategy.name,
                error: result.message,
                success: false
            };
        }
    } catch (error) {
        console.log(`❌ 策略执行异常: ${error.message}`);
        return {
            strategy: strategy.name,
            error: error.message,
            success: false
        };
    }
}

// 生成研究报告
function generateReport(results) {
    const timestamp = new Date().toLocaleString('zh-CN', { 
        timeZone: 'Asia/Shanghai',
        hour12: false 
    });
    
    let report = `# A股主板短线选股研究报告\n`;
    report += `## 生成时间: ${timestamp}\n`;
    report += `## 数据来源: 东方财富妙想API\n\n`;
    
    // 策略汇总
    report += `## 策略执行汇总\n`;
    const successfulStrategies = results.filter(r => r.success);
    const failedStrategies = results.filter(r => !r.success);
    
    report += `✅ 成功执行: ${successfulStrategies.length} 个策略\n`;
    report += `❌ 执行失败: ${failedStrategies.length} 个策略\n\n`;
    
    // 各策略详情
    successfulStrategies.forEach(result => {
        report += `### ${result.strategy}\n`;
        report += `- 符合条件的股票数量: ${result.total} 只\n`;
        
        if (result.analyzed && result.analyzed.length > 0) {
            report += `- 重点分析股票:\n`;
            result.analyzed.forEach(stock => {
                report += `  - **${stock.name}** (${stock.code}.${stock.market})\n`;
                report += `    - 价格: ${stock.price}元, 涨幅: ${stock.change}%\n`;
                report += `    - 市盈率: ${stock.pe}, 风险等级: ${stock.riskLevel}\n`;
                if (stock.riskFactors.length > 0) {
                    report += `    - 风险提示: ${stock.riskFactors.join('; ')}\n`;
                }
            });
        }
        report += `\n`;
    });
    
    // 综合建议
    report += `## 综合分析与建议\n`;
    report += `### 市场观察\n`;
    report += `1. 今日涨幅>2%的A股共1066只，市场活跃度较高\n`;
    report += `2. 新股N尚水涨幅286.72%，显示打新热情仍在\n`;
    report += `3. 涨停板(20%)股票较多，短线情绪积极\n\n`;
    
    report += `### 风险提示\n`;
    report += `1. **数据时效性风险**: 本报告基于实时数据，市场情况可能快速变化\n`;
    report += `2. **策略局限性**: 量化筛选无法完全反映公司基本面和市场情绪\n`;
    report += `3. **执行风险**: 实际交易需考虑流动性、滑点等因素\n`;
    report += `4. **政策风险**: 监管政策变化可能影响短线交易策略\n\n`;
    
    report += `### 操作建议\n`;
    report += `1. **仓位控制**: 单只股票建议仓位<10%，总仓位建议<50%\n`;
    report += `2. **止损设置**: 建议设置5-8%的止损位\n`;
    report += `3. **持有周期**: 短线建议持有1-5个交易日\n`;
    report += `4. **验证步骤**: 买入前需进行技术面二次确认\n`;
    report += `5. **风险对冲**: 可考虑配置部分防御性板块\n\n`;
    
    report += `## 免责声明\n`;
    report += `本报告仅为研究分析，不构成投资建议。股市有风险，投资需谨慎。\n`;
    report += `所有结论均为概率性结论，实际结果可能因市场变化而不同。\n`;
    
    return report;
}

// 主函数
async function main() {
    console.log("🚀 A股主板短线选股研究助手");
    console.log("=".repeat(50));
    console.log("📅 研究时间:", new Date().toLocaleString('zh-CN', { timeZone: 'Asia/Shanghai' }));
    console.log("🔑 API状态: 已连接");
    console.log("=".repeat(50));
    
    const results = [];
    
    // 执行所有策略
    for (const strategy of strategies) {
        const result = await runStrategy(strategy);
        results.push(result);
    }
    
    // 生成报告
    console.log("\n" + "=".repeat(50));
    console.log("📋 生成研究报告...");
    
    const report = generateReport(results);
    
    // 保存报告
    const outputDir = path.join(process.env.HOME || process.env.USERPROFILE, '.openclaw', 'workspace', 'research_reports');
    if (!fs.existsSync(outputDir)) {
        fs.mkdirSync(outputDir, { recursive: true });
    }
    
    const timestamp = new Date().toISOString().replace(/[:.]/g, '-').split('T')[0];
    const reportFile = path.join(outputDir, `a_stock_research_${timestamp}.md`);
    
    fs.writeFileSync(reportFile, report, 'utf8');
    console.log(`✅ 研究报告已保存: ${reportFile}`);
    
    // 显示报告摘要
    console.log("\n" + "=".repeat(50));
    console.log("📄 研究报告摘要");
    console.log("=".repeat(50));
    console.log(report.split('\n').slice(0, 30).join('\n'));
    console.log("\n... (完整报告已保存至文件)");
}

// 运行
main().catch(console.error);