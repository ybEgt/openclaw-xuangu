// 完整定时任务系统 - 最终版
console.log("⏰ 完整定时任务系统 v1.0");
console.log("=".repeat(70));

const fs = require('fs');
const path = require('path');

// 1. 创建所有必要的目录
console.log("📁 创建系统目录结构...");

const directories = [
    'logs',
    'archive/intraday',
    'archive/final',
    'archive/evolution',
    'archive/pre_market',
    'task_scripts'
];

directories.forEach(dir => {
    const dirPath = path.join(__dirname, dir);
    if (!fs.existsSync(dirPath)) {
        fs.mkdirSync(dirPath, { recursive: true });
        console.log(`  ✅ 创建: ${dir}`);
    } else {
        console.log(`  📁 已存在: ${dir}`);
    }
});

// 2. 创建任务脚本
console.log("\n📝 创建任务执行脚本...");

// 盘前扫雷脚本
const preMarketScript = `const { taskPreMarketScan } = require('../scheduled_tasks_system.js');
async function main() {
    console.log("🔍 盘前扫雷任务启动");
    try {
        const result = await taskPreMarketScan();
        console.log(result.executed ? "✅ 任务完成" : \`⏸️ 跳过: \${result.reason}\`);
        process.exit(0);
    } catch (error) {
        console.error(\`❌ 失败: \${error.message}\`);
        process.exit(1);
    }
}
main();`;

// 盘中频筛脚本
const intradayScript = `const { taskIntradayScreening } = require('../scheduled_tasks_system.js');
async function main() {
    console.log("📊 盘中频筛任务启动");
    try {
        const result = await taskIntradayScreening();
        console.log(result.executed ? "✅ 任务完成" : \`⏸️ 跳过: \${result.reason}\`);
        process.exit(0);
    } catch (error) {
        console.error(\`❌ 失败: \${error.message}\`);
        process.exit(1);
    }
}
main();`;

// 尾盘终筛脚本
const finalScript = `const { taskFinalScreening } = require('../scheduled_tasks_system.js');
async function main() {
    console.log("🎯 尾盘终筛任务启动");
    try {
        const result = await taskFinalScreening();
        console.log(result.executed ? "✅ 任务完成" : \`⏸️ 跳过: \${result.reason}\`);
        process.exit(0);
    } catch (error) {
        console.error(\`❌ 失败: \${error.message}\`);
        process.exit(1);
    }
}
main();`;

// 盘后复盘脚本
const reviewScript = `const { taskPostMarketReview } = require('../scheduled_tasks_system.js');
async function main() {
    console.log("🔄 盘后复盘任务启动");
    try {
        const result = await taskPostMarketReview();
        console.log(result.executed ? "✅ 任务完成" : \`⏸️ 跳过: \${result.reason}\`);
        process.exit(0);
    } catch (error) {
        console.error(\`❌ 失败: \${error.message}\`);
        process.exit(1);
    }
}
main();`;

const scripts = [
    { name: 'task_pre_market.js', content: preMarketScript },
    { name: 'task_intraday.js', content: intradayScript },
    { name: 'task_final.js', content: finalScript },
    { name: 'task_review.js', content: reviewScript }
];

scripts.forEach(script => {
    const filepath = path.join(__dirname, 'task_scripts', script.name);
    fs.writeFileSync(filepath, script.content, 'utf8');
    console.log(`  ✅ 创建: ${script.name}`);
});

// 3. 创建crontab配置
console.log("\n⏱️  生成crontab配置...");

const crontab = `# A股选股系统定时任务 - 北京时间
# 时区: Asia/Shanghai
# 创建时间: ${new Date().toLocaleString('zh-CN')}

# 任务1: 盘前扫雷 (8:30~9:15，每15分钟)
30-45/15 8 * * 1-5 cd "${__dirname.replace(/\\/g, '/')}" && node "task_scripts/task_pre_market.js" >> "${__dirname.replace(/\\/g, '/')}/logs/pre_market.log" 2>&1

# 任务2: 盘中频筛 (9:00~13:30，每30分钟)
0,30 9-13 * * 1-5 cd "${__dirname.replace(/\\/g, '/')}" && node "task_scripts/task_intraday.js" >> "${__dirname.replace(/\\/g, '/')}/logs/intraday.log" 2>&1

# 任务3: 尾盘终筛 (14:00~14:50，每10分钟)
0-50/10 14 * * 1-5 cd "${__dirname.replace(/\\/g, '/')}" && node "task_scripts/task_final.js" >> "${__dirname.replace(/\\/g, '/')}/logs/final.log" 2>&1

# 任务4: 盘后复盘 (15:10)
10 15 * * 1-5 cd "${__dirname.replace(/\\/g, '/')}" && node "task_scripts/task_review.js" >> "${__dirname.replace(/\\/g, '/')}/logs/review.log" 2>&1

# 系统维护: 每日清理旧日志 (凌晨2点)
0 2 * * * find "${__dirname.replace(/\\/g, '/')}/logs" -name "*.log" -mtime +7 -delete`;

const crontabPath = path.join(__dirname, 'crontab.txt');
fs.writeFileSync(crontabPath, crontab, 'utf8');
console.log(`✅ 生成crontab配置: ${crontabPath}`);

// 4. 创建系统配置
console.log("\n⚙️  创建系统配置文件...");

const systemConfig = {
    version: "1.0.0",
    created: new Date().toISOString(),
    timezone: "Asia/Shanghai",
    email: {
        recipient: "zhangyuru999@qq.com",
        from: "zhangyuru999@qq.com"
    },
    tasks: [
        {
            id: "pre_market_scan",
            name: "盘前扫雷",
            schedule: "30-45/15 8 * * 1-5",
            description: "交易日开盘前排查上一交易日存档股票的新闻",
            script: "task_pre_market.js"
        },
        {
            id: "intraday_screening", 
            name: "盘中频筛",
            schedule: "0,30 9-13 * * 1-5",
            description: "交易时间段内筛选股票",
            script: "task_intraday.js"
        },
        {
            id: "final_screening",
            name: "尾盘终筛",
            schedule: "0-50/10 14 * * 1-5",
            description: "收盘前密集筛选并存档",
            script: "task_final.js"
        },
        {
            id: "post_market_review",
            name: "盘后复盘",
            schedule: "10 15 * * 1-5",
            description: "验证策略并触发反推进化",
            script: "task_review.js"
        }
    ]
};

const configPath = path.join(__dirname, 'task_system_config.json');
fs.writeFileSync(configPath, JSON.stringify(systemConfig, null, 2), 'utf8');
console.log(`✅ 创建系统配置: ${configPath}`);

// 5. 创建安装说明
console.log("\n📖 创建安装说明...");

const installGuide = `# A股选股系统 - 定时任务安装指南

## 系统概述
本系统包含4个定时任务，按照A股交易时间自动运行：

### 任务列表
1. **盘前扫雷** (8:30~9:15，每15分钟)
   - 检查上一交易日存档股票的新闻
   - 发现负面新闻则发送邮件预警

2. **盘中频筛** (9:00~13:30，每30分钟)
   - 交易时间段内筛选股票
   - 发送Top3推荐到邮箱

3. **尾盘终筛** (14:00~14:50，每10分钟)
   - 收盘前密集筛选
   - 最后一组数据存档用于次日

4. **盘后复盘** (15:10)
   - 验证策略效果
   - 未通过则触发反推进化

## 安装步骤

### Windows系统
1. 安装Node.js (v14+)
2. 安装任务计划程序：
   - 打开"任务计划程序"
   - 创建基本任务
   - 按crontab.txt中的时间配置
   - 操作：启动程序 node.exe
   - 参数：对应脚本路径

### Linux/Mac系统
1. 安装Node.js
2. 设置crontab：
   \`\`\`bash
   crontab -e
   \`\`\`
3. 添加crontab.txt中的内容

### 手动测试
\`\`\`bash
# 测试盘前扫雷
node task_scripts/task_pre_market.js

# 测试盘中频筛  
node task_scripts/task_intraday.js

# 测试尾盘终筛
node task_scripts/task_final.js

# 测试盘后复盘
node task_scripts/task_review.js
\`\`\`

## 目录结构
\`\`\`
workspace/
├── task_scripts/          # 任务脚本
├── logs/                  # 运行日志
├── archive/              # 数据存档
│   ├── intraday/         # 盘中筛选存档
│   ├── final/            # 尾盘终筛存档
│   ├── evolution/        # 进化记录
│   └── pre_market/       # 盘前扫雷存档
├── crontab.txt           # 定时任务配置
└── task_system_config.json # 系统配置
\`\`\`

## 邮箱配置
系统使用QQ邮箱发送通知，配置在代码中：
- 发件人: zhangyuru999@qq.com
- 收件人: zhangyuru999@qq.com
- 授权码: 已配置

## 注意事项
1. 确保系统时间为北京时间
2. 交易日为周一至周五（排除节假日）
3. 日志自动保留7天
4. 存档数据用于次日盘前扫雷

## 故障排除
1. 检查日志文件：logs/目录
2. 检查邮箱配置：确保授权码正确
3. 检查网络连接：需要访问股票数据
4. 检查时间设置：确保系统时间正确

## 联系方式
如有问题，请检查系统日志或重新运行配置脚本。

---
*系统版本: 1.0.0*
*创建时间: ${new Date().toLocaleString('zh-CN')}*`;

const guidePath = path.join(__dirname, 'INSTALL_GUIDE.md');
fs.writeFileSync(guidePath, installGuide, 'utf8');
console.log(`✅ 创建安装指南: ${guidePath}`);

// 6. 更新系统状态
console.log("\n🔄 更新系统状态...");

const sessionStatePath = path.join(__dirname, 'SESSION-STATE.md');
if (fs.existsSync(sessionStatePath)) {
    let content = fs.readFileSync(sessionStatePath, 'utf8');
    
    const taskUpdate = `\n\n## ⏰ 定时任务系统配置完成 (${new Date().toLocaleString('zh-CN')})

### 任务配置完成
已成功配置4个定时任务：

#### 1. 盘前扫雷
- **时间:** 交易日 8:30~9:15，每15分钟
- **功能:** 检查上一交易日存档股票的新闻
- **触发:** 发现负面新闻则发送邮件预警
- **cron:** \`30-45/15 8 * * 1-5\`

#### 2. 盘中频筛  
- **时间:** 交易日 9:00~13:30，每30分钟
- **功能:** 交易时间段内筛选股票
- **触发:** 发送Top3推荐到邮箱
- **cron:** \`0,30 9-13 * * 1-5\`

#### 3. 尾盘终筛
- **时间:** 交易日 14:00~14:50，每10分钟
- **功能:** 收盘前密集筛选
- **触发:** 发送推荐并存档最后一组数据
- **cron:** \`0-50/10 14 * * 1-5\`

#### 4. 盘后复盘
- **时间:** 交易日 15:10
- **功能:** 验证策略并触发反推进化
- **触发:** 未通过验证则启动进化机制
- **cron:** \`10 15 * * 1-5\`

### 系统文件创建
✅ **目录结构:**
- \`task_scripts/\` - 4个任务脚本
- \`logs/\` - 运行日志目录
- \`archive/\` - 数据存档目录（4个子目录）

✅ **配置文件:**
- \`crontab.txt\` - 定时任务配置
- \`task_system_config.json\` - 系统配置
- \`INSTALL_GUIDE.md\` - 安装指南

### 邮箱集成
- **发件邮箱:** zhangyuru999@qq.com
- **收件邮箱:** zhangyuru999@qq.com
- **授权码:** 已安全配置
- **SMTP:** smtp.qq.com:465 (SSL加密)

### 交易日判断
- **交易日:** 周一至周五（排除节假日）
- **时间判断:** 基于北京时间
- **存档机制:** 尾盘数据存档用于次日盘前扫雷

### 反推进化集成
- **触发条件:** 盘后复盘未通过验证
- **进化机制:** 自动决定回测天数
- **结论推送:** 进化结果发送到邮箱
- **版本管理:** 稳定策略打tag归档

### 立即使用
1. **Windows:** 使用任务计划程序导入crontab配置
2. **Linux/Mac:** \`crontab crontab.txt\`
3. **手动测试:** 运行task_scripts/下的脚本

### 系统保障
- **日志记录:** 所有任务都有详细日志
- **错误处理:** 失败时发送邮件通知
- **数据备份:** 重要数据自动存档
- **自动清理:** 日志保留7天

### 下一步
1. 配置操作系统的定时任务
2. 测试各个任务功能
3. 监控首日运行效果
4. 根据实际表现优化参数`;
    
    content += taskUpdate;
    fs.writeFileSync(sessionStatePath, content, 'utf8');
    
    console.log(`✅ 系统状态已更新: ${sessionStatePath}`);
}

console.log("\n" + "=".repeat(70));
console.log("🎉 定时任务系统配置完成!");
console.log("=".repeat(70));

console.log("\n📋 配置总结:");
console.log("  ✅ 创建4个任务脚本");
console.log("  ✅ 创建日志和存档目录");
console.log("  ✅ 生成crontab配置");
console.log("  ✅ 创建系统配置文件");
console.log("  ✅ 创建安装指南");
console.log("  ✅ 更新系统状态");

console.log("\n🚀 安装步骤:");
console.log("  1. Windows: 使用任务计划程序导入crontab.txt");
console.log("  2. Linux/Mac: 运行 'crontab crontab.txt'");
console.log("  3. 测试: 手动运行task_scripts/下的脚本");
console.log("  4. 监控: 查看logs/目录下的日志");

console.log("\n📅 任务时间表:");
console.log("  08:30, 08:45, 09:00 - 盘前扫雷");
console.log("  09:00-13:30 每30分钟 - 盘中频筛");
console.log("  14:00-14:50 每10分钟 - 尾盘终筛");
console.log("  15:10 - 盘后复盘");

console.log("\n💡 注意事项:");
console.log("  • 确保系统时间为北京时间");
console.log("  • 交易日为周一至周五");
console.log("  • 邮箱授权码已配置");
console.log("  • 日志自动保留7天");

console.log("\n📧 邮件通知:");
console.log("  • 盘前扫雷: 只有发现负面新闻才发送");
console.log("  • 盘中频筛: 每次筛选都发送Top3");
console.log("  • 尾盘终筛: 每次筛选都发送并存档");
console.log("  • 盘后复盘: 发送验证结果和进化结论");

// 创建测试脚本
const testScript = `// 定时任务测试脚本
console.log("🧪 定时任务系统测试");
console.log("=".repeat(50));

const fs = require('fs');
const path = require('path');

// 测试各个任务
const tasks = [
    { name: "盘前扫雷", script: "task_pre_market.js" },
    { name: "盘中频筛", script: "task_intraday.js" },
    { name: "尾盘终筛", script: "task_final.js" },
    { name: "盘后复盘", script: "task_review.js" }
];

console.log("\\n🔍 检查脚本文件:");
tasks.forEach(task => {
    const scriptPath = path.join(__