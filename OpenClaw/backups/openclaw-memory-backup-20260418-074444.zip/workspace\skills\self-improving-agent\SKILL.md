---
name: self-improving-agent
description: Capture errors, corrections, and new best practices into structured learning notes for continuous improvement.
---

# Self Improving Agent

Use this skill to keep a durable improvement loop for your workspace.

## When to use

- A command failed and you want to record root cause and fix.
- The user corrected the assistant and you want to preserve the lesson.
- You discovered a better repeatable approach and want to standardize it.

## Output format

Always produce three blocks:

1. `Learning Summary` (one sentence)
2. `Actionable Rule` (clear do/don't statement)
3. `Next Checkpoint` (how to verify the improvement later)

## Recommended storage

- `.learnings/LEARNINGS.md` for reusable lessons
- `.learnings/ERRORS.md` for failure and remediation notes
- `MEMORY.md` for high-value stable rules after review

## Safety

- Do not rewrite project rules automatically.
- Propose changes first, then wait for explicit user confirmation.
