# 股票筛选工作流程

## 概述
本流程描述如何执行A股主板短线选股研究，从数据获取到报告生成的全过程。

## 步骤1：环境准备
### 1.1 检查API密钥
```javascript
// 优先级：环境变量 > 配置文件
const MX_APIKEY = process.env.MX_APIKEY || "从api-keys.json读取";
```

### 1.2 验证API连接
```javascript
// 测试查询
const testQuery = "今日涨幅大于2%";
const result = await callMXStockScreener(testQuery);
// 验证：result.status === 0 && result.data.code === 0
```

## 步骤2：执行选股筛选
### 2.1 定义筛选条件
```javascript
const strategies = [
    {
        name: "短线强势股筛选",
        query: "A股主板 今日涨幅大于5% 成交量大于1亿",
        desc: "筛选今日强势上涨且成交活跃的股票"
    }
];
```

### 2.2 调用API
```javascript
async function runStrategy(strategy) {
    const result = await callMXStockScreener(strategy.query);
    
    // 验证响应
    if (result.status === 0 && result.data && result.data.code === 0) {
        const data = result.data.data;
        const total = data.securityCount || 0;
        return { success: true, total, data };
    }
    return { success: false, error: result.message };
}
```

## 步骤3：数据解析
### 3.1 解析动态字段
```javascript
function parseStockData(stock, columns) {
    // 创建字段映射
    const fieldMap = {};
    columns.forEach(col => {
        if (col.key && col.title) {
            fieldMap[col.key] = {
                title: col.title,
                unit: col.unit || '',
                dataType: col.dataType
            };
        }
    });
    
    // 提取关键信息
    const result = {
        code: stock.SECURITY_CODE || '',
        name: stock.SECURITY_SHORT_NAME || '',
        market: stock.MARKET_SHORT_NAME || ''
    };
    
    // 动态提取数值字段
    const numericFields = {};
    for (const [key, value] of Object.entries(stock)) {
        // 跳过基础字段
        if (key === 'SECURITY_CODE' || key === 'SECURITY_SHORT_NAME' || 
            key === 'MARKET_SHORT_NAME' || key === 'SERIAL') {
            continue;
        }
        
        // 智能识别字段类型
        if (key.includes('CHG') || key.includes('涨跌幅')) {
            numericFields['涨跌幅'] = { value: String(value), unit: '%', rawKey: key };
        } else if (key.includes('NEWEST_PRICE') || key.includes('最新价')) {
            numericFields['最新价'] = { value: String(value), unit: '元', rawKey: key };
        }
        // ... 其他字段识别
    }
    
    result.numericFields = numericFields;
    return result;
}
```

### 3.2 风险评估
```javascript
function assessRisk(parsedStock) {
    const riskFactors = [];
    let riskLevel = "低";
    
    const fields = parsedStock.numericFields;
    
    // 检查涨跌幅
    const change = parseFloat(fields['涨跌幅']?.value || 0);
    if (change > 9.9) {
        riskFactors.push(`涨幅较大(${change}%)`);
        riskLevel = "中";
    }
    
    // 检查换手率
    const turnover = parseFloat(fields['换手率']?.value || 0);
    if (turnover > 20) {
        riskFactors.push(`换手率过高(${turnover}%)`);
        riskLevel = "高";
    }
    
    return {
        riskLevel,
        riskFactors,
        change,
        turnover
    };
}
```

## 步骤4：生成报告
### 4.1 报告结构
```javascript
function generateReport(analyzedStocks, total, query) {
    let report = `# A股主板短线选股智能分析报告\n`;
    report += `## 生成时间: ${new Date().toLocaleString('zh-CN')}\n`;
    report += `## 数据来源: 东方财富妙想API\n`;
    report += `## 选股条件: ${query}\n\n`;
    
    // 执行摘要
    report += `## 执行摘要\n`;
    report += `- 符合条件的股票总数: ${total} 只\n`;
    report += `- 详细分析股票数量: ${analyzedStocks.length} 只\n\n`;
    
    // 股票详细分析
    report += `## 股票详细分析\n`;
    analyzedStocks.forEach((stock, idx) => {
        report += `### ${idx + 1}. ${stock.name} (${stock.code}.${stock.market})\n`;
        report += `- **涨幅**: ${stock.riskAssessment.change}%\n`;
        report += `- **风险等级**: ${stock.riskAssessment.riskLevel}\n`;
        // ... 其他字段
    });
    
    // 风险提示与操作建议
    report += `## 风险提示与操作建议\n`;
    report += `### 主要风险\n`;
    report += `1. **市场风险**: 股市波动可能导致短期亏损\n`;
    // ... 其他风险
    
    report += `### 操作建议\n`;
    report += `1. **仓位控制**: 建议单只股票仓位不超过总资金的10%\n`;
    // ... 其他建议
    
    return report;
}
```

### 4.2 保存报告
```javascript
function saveReport(report) {
    const outputDir = path.join(process.env.HOME || process.env.USERPROFILE, 
        '.openclaw', 'workspace', 'research_reports');
    
    if (!fs.existsSync(outputDir)) {
        fs.mkdirSync(outputDir, { recursive: true });
    }
    
    const timestamp = new Date().toISOString().split('T')[0];
    const timeStr = new Date().toLocaleString('zh-CN', { hour12: false })
        .replace(/[/:]/g, '-').replace(/\s+/g, '_');
    
    const reportFile = path.join(outputDir, `smart_analysis_${timestamp}_${timeStr}.md`);
    fs.writeFileSync(reportFile, report, 'utf8');
    
    return reportFile;
}
```

## 步骤5：记忆管理
### 5.1 更新SESSION-STATE.md（WAL协议）
```javascript
function updateSessionState(key, value) {
    const sessionStatePath = path.join(workspaceRoot, 'SESSION-STATE.md');
    let content = fs.readFileSync(sessionStatePath, 'utf8');
    
    // 更新或添加键值对
    const regex = new RegExp(`## ${key}[\\s\\S]*?\\n([^#]*?)\\n(?=##|$)`);
    if (regex.test(content)) {
        content = content.replace(regex, `## ${key}\n${value}\n`);
    } else {
        content += `\n## ${key}\n${value}\n`;
    }
    
    fs.writeFileSync(sessionStatePath, content, 'utf8');
}
```

### 5.2 记录情景记忆
```javascript
function logEpisodicMemory(event, details) {
    const today = new Date().toISOString().split('T')[0];
    const episodicPath = path.join(workspaceRoot, 'memory', 'episodic', `${today}.md`);
    
    let content = '';
    if (fs.existsSync(episodicPath)) {
        content = fs.readFileSync(episodicPath, 'utf8');
    } else {
        content = `# ${today} - 情景记忆日志\n\n`;
    }
    
    const time = new Date().toLocaleTimeString('zh-CN', { hour12: false });
    content += `## ${time} - ${event}\n`;
    content += details.split('\n').map(line => `- ${line}`).join('\n') + '\n\n';
    
    fs.writeFileSync(episodicPath, content, 'utf8');
}
```

## 步骤6：质量控制
### 6.1 数据验证
- 验证API响应状态码
- 检查数据完整性
- 验证数值范围合理性

### 6.2 报告验证
- 检查所有必含章节
- 验证风险提示完整性
- 确保免责声明存在

### 6.3 记忆验证
- 确认SESSION-STATE.md已更新
- 检查情景记忆记录
- 验证文件保存位置

## 错误处理
### 常见错误及处理：
1. **API连接失败：** 检查网络和API密钥
2. **数据解析错误：** 记录原始响应并分析字段结构
3. **文件保存失败：** 检查目录权限和磁盘空间
4. **内存更新失败：** 回退到工作缓冲区

### 恢复流程：
1. 读取工作缓冲区（如果存在）
2. 恢复SESSION-STATE.md
3. 重新执行失败步骤
4. 记录错误到情景记忆

## 性能优化
### 缓存策略：
- API响应缓存5分钟
- 字段映射缓存到内存
- 常用查询结果缓存

### 并行处理：
- 多个筛选策略并行执行
- 数据解析与风险评估并行
- 文件保存异步执行

## 维护任务
### 每日维护：
1. 清理过期的缓存文件
2. 归档旧的研究报告（>30天）
3. 压缩记忆文件

### 每周维护：
1. 运行健康检查（agent-health-optimizer）
2. 更新语义记忆库
3. 优化工作流程

## 版本控制
### 变更记录：
- **v1.0 (2026-04-18):** 初始版本
- **基于：** smart_stock_analyzer.js
- **维护者：** A股主板短线选股研究助手

### 更新原则：
1. 向后兼容性优先
2. 变更前备份原流程
3. 更新后测试所有步骤
4. 更新版本号和日期