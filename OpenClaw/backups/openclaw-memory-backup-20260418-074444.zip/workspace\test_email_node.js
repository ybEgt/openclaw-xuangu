// Node.js测试QQ邮箱连接
const nodemailer = require('nodemailer');
const Imap = require('imap');

console.log("🚀 QQ邮箱连接测试");
console.log("=".repeat(50));

// QQ邮箱配置
const QQ_EMAIL = "zhangyuru999@qq.com";
const QQ_PASSWORD = "yjhatgqnbailcahb"; // 授权码
const SMTP_SERVER = "smtp.qq.com";
const SMTP_PORT = 465;
const IMAP_SERVER = "imap.qq.com";
const IMAP_PORT = 993;

// 读取配置文件
const fs = require('fs');
const path = require('path');

const configPath = path.join(__dirname, 'skills', 'email-manager', 'config.json');
try {
    const configData = fs.readFileSync(configPath, 'utf8');
    const config = JSON.parse(configData);
    console.log(`✅ 已读取配置文件: ${configPath}`);
    console.log(`   邮箱地址: ${config.email_address}`);
    console.log(`   SMTP服务器: ${config.smtp_server}:${config.smtp_port}`);
    console.log(`   IMAP服务器: ${config.imap_server}:${config.imap_port}`);
} catch (error) {
    console.log(`❌ 无法读取配置文件: ${error.message}`);
}

console.log("\n" + "=".repeat(50));

// 测试SMTP连接和发送邮件
async function testSMTP() {
    console.log("📨 测试SMTP连接和发送邮件...");
    
    try {
        // 创建transporter
        const transporter = nodemailer.createTransport({
            host: SMTP_SERVER,
            port: SMTP_PORT,
            secure: true, // 使用SSL
            auth: {
                user: QQ_EMAIL,
                pass: QQ_PASSWORD
            }
        });
        
        console.log(`✅ 已创建SMTP连接到 ${SMTP_SERVER}:${SMTP_PORT}`);
        
        // 验证连接
        await transporter.verify();
        console.log("✅ SMTP连接验证成功");
        
        // 发送测试邮件
        const mailOptions = {
            from: `"OpenClaw AI助手" <${QQ_EMAIL}>`,
            to: QQ_EMAIL, // 发送给自己测试
            subject: "测试邮件 - OpenClaw邮箱连接测试",
            text: `这是一封测试邮件，用于验证OpenClaw的email-manager技能是否能正常工作。

测试时间: ${new Date().toLocaleString('zh-CN')}
测试系统: A股主板短线选股研究助手
测试目的: 验证QQ邮箱配置和发送功能

如果收到此邮件，说明email-manager技能配置成功！

祝好，
OpenClaw AI助手`,
            html: `<div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
    <h2 style="color: #1890ff;">📧 OpenClaw邮箱连接测试</h2>
    <p>这是一封测试邮件，用于验证OpenClaw的email-manager技能是否能正常工作。</p>
    
    <div style="background-color: #f5f5f5; padding: 15px; border-radius: 5px; margin: 20px 0;">
        <h3>📋 测试信息</h3>
        <ul>
            <li><strong>测试时间:</strong> ${new Date().toLocaleString('zh-CN')}</li>
            <li><strong>测试系统:</strong> A股主板短线选股研究助手</li>
            <li><strong>测试目的:</strong> 验证QQ邮箱配置和发送功能</li>
            <li><strong>发送邮箱:</strong> ${QQ_EMAIL}</li>
        </ul>
    </div>
    
    <div style="background-color: #e6f7ff; padding: 15px; border-radius: 5px; margin: 20px 0;">
        <h3>✅ 如果收到此邮件</h3>
        <p>说明email-manager技能配置成功！系统现在可以：</p>
        <ol>
            <li>发送A股选股研究报告</li>
            <li>发送市场风险预警</li>
            <li>发送投资机会通知</li>
            <li>管理邮件通信</li>
        </ol>
    </div>
    
    <div style="border-top: 1px solid #ddd; padding-top: 20px; margin-top: 30px;">
        <p>祝好，<br>
        <strong>OpenClaw AI助手</strong><br>
        A股主板短线选股研究助手</p>
    </div>
</div>`
        };
        
        const info = await transporter.sendMail(mailOptions);
        console.log("✅ 测试邮件发送成功!");
        console.log(`   邮件ID: ${info.messageId}`);
        console.log(`   收件人: ${info.accepted.join(', ')}`);
        
        return { success: true, messageId: info.messageId };
        
    } catch (error) {
        console.log(`❌ SMTP测试失败: ${error.message}`);
        return { success: false, error: error.message };
    }
}

// 测试IMAP连接
function testIMAP() {
    console.log("\n🔍 测试IMAP连接...");
    
    return new Promise((resolve) => {
        try {
            const imap = new Imap({
                user: QQ_EMAIL,
                password: QQ_PASSWORD,
                host: IMAP_SERVER,
                port: IMAP_PORT,
                tls: true,
                tlsOptions: { rejectUnauthorized: false }
            });
            
            imap.once('ready', () => {
                console.log(`✅ 已连接到IMAP服务器 ${IMAP_SERVER}:${IMAP_PORT}`);
                
                // 打开收件箱
                imap.openBox('INBOX', false, (err, box) => {
                    if (err) {
                        console.log(`❌ 无法打开收件箱: ${err.message}`);
                        imap.end();
                        resolve({ success: false, error: err.message });
                        return;
                    }
                    
                    console.log(`✅ 收件箱打开成功`);
                    console.log(`   总邮件数: ${box.messages.total}`);
                    console.log(`   未读邮件: ${box.messages.total - box.messages.new}`);
                    
                    imap.end();
                    resolve({ success: true, total: box.messages.total });
                });
            });
            
            imap.once('error', (err) => {
                console.log(`❌ IMAP连接错误: ${err.message}`);
                resolve({ success: false, error: err.message });
            });
            
            imap.connect();
            
        } catch (error) {
            console.log(`❌ IMAP连接失败: ${error.message}`);
            resolve({ success: false, error: error.message });
        }
    });
}

// 主函数
async function main() {
    try {
        // 测试SMTP
        const smtpResult = await testSMTP();
        
        // 等待几秒让邮件发送
        console.log("\n⏳ 等待邮件发送完成...");
        await new Promise(resolve => setTimeout(resolve, 3000));
        
        // 测试IMAP
        const imapResult = await testIMAP();
        
        console.log("\n" + "=".repeat(50));
        console.log("📊 测试结果汇总:");
        console.log(`  SMTP连接和发送: ${smtpResult.success ? '✅ 成功' : '❌ 失败'}`);
        console.log(`  IMAP连接: ${imapResult.success ? '✅ 成功' : '❌ 失败'}`);
        
        if (smtpResult.success && imapResult.success) {
            console.log("\n🎉 所有测试成功！email-manager技能可以正常工作。");
            console.log("\n📧 接下来可以:");
            console.log("  1. 使用email-manager技能发送A股研究报告");
            console.log("  2. 设置自动邮件通知系统");
            console.log("  3. 集成到选股研究流程中");
            console.log("  4. 发送市场风险预警邮件");
            
            // 更新系统状态
            updateSystemState();
        } else {
            console.log("\n⚠️  部分测试失败，请检查:");
            console.log("  - QQ邮箱授权码是否正确");
            console.log("  - QQ邮箱的SMTP/IMAP服务是否已开启");
            console.log("  - 网络连接是否正常");
            console.log("  - 防火墙设置");
        }
        
    } catch (error) {
        console.log(`❌ 测试过程中出错: ${error.message}`);
    }
}

// 更新系统状态
function updateSystemState() {
    const workspaceRoot = path.join(__dirname);
    const sessionStatePath = path.join(workspaceRoot, 'SESSION-STATE.md');
    
    if (fs.existsSync(sessionStatePath)) {
        let content = fs.readFileSync(sessionStatePath, 'utf8');
        
        const emailUpdate = `\n\n## 📧 邮箱系统配置完成 (${new Date().toLocaleString('zh-CN')})
**邮箱服务:** QQ邮箱 (zhangyuru999@qq.com)

### 配置状态
- ✅ SMTP连接: smtp.qq.com:465 (已测试)
- ✅ IMAP连接: imap.qq.com:993 (已测试)
- ✅ 邮件发送: 测试邮件已发送
- ✅ 技能集成: email-manager技能可用

### 功能能力
1. **邮件发送** - 发送A股研究报告和通知
2. **收件箱管理** - 查看和管理邮件
3. **自动通知** - 设置选股结果自动发送
4. **风险预警** - 邮件形式的风险提示

### 安全配置
- 使用QQ邮箱授权码 (非密码)
- SSL/TLS加密连接
- 仅发送到已验证邮箱
- 邮件内容本地生成，不外传数据

### 应用场景
- 每日选股报告自动发送
- 重大市场风险邮件预警
- 投资机会及时通知
- 研究结果分享和存档`;
        
        content += emailUpdate;
        fs.writeFileSync(sessionStatePath, content, 'utf8');
        
        console.log("\n✅ 系统状态已更新 (SESSION-STATE.md)");
    }
}

// 运行测试
main();