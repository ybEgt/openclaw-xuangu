// 交易日和交易时间段检查器
console.log("📅 交易日和交易时间段检查器");
console.log("=".repeat(70));

// 上交所/深交所交易日定义
const TRADING_SCHEDULE = {
    // 交易日定义（中国大陆股市）
    trading_days: {
        // 正常交易日：周一至周五（除非是法定节假日）
        normal: [1, 2, 3, 4, 5], // 周一=1, 周日=0
        
        // 2026年已知节假日（示例，需要更新）
        holidays: [
            "2026-01-01", // 元旦
            "2026-01-28", "2026-01-29", "2026-01-30", // 春节
            "2026-04-04", "2026-04-05", "2026-04-06", // 清明节
            "2026-05-01", "2026-05-02", "2026-05-03", // 劳动节
            "2026-06-08", "2026-06-09", "2026-06-10", // 端午节
            "2026-09-15", "2026-09-16", "2026-09-17", // 中秋节
            "2026-10-01", "2026-10-02", "2026-10-03", "2026-10-04", "2026-10-05", "2026-10-06", "2026-10-07" // 国庆节
        ],
        
        // 调休工作日（周末上班但股市不开市）
        special_workdays: [
            // 2026年调休工作日（示例）
        ]
    },
    
    // 交易时间段（北京时间）
    trading_hours: {
        // 上午
        morning: {
            open: "09:15",  // 集合竞价开始
            start: "09:30", // 连续竞价开始
            end: "11:30"    // 上午收盘
        },
        
        // 下午
        afternoon: {
            start: "13:00", // 下午开盘
            end: "15:00"    // 收盘
        },
        
        // 盘后固定价格交易（可选）
        after_hours: {
            start: "15:05",
            end: "15:30"
        }
    },
    
    // 重要时间点
    key_times: {
        pre_market_start: "08:30",   // 盘前开始
        pre_market_end: "09:15",     // 盘前结束
        morning_start: "09:30",      // 上午交易开始
        morning_end: "11:30",        // 上午交易结束
        afternoon_start: "13:00",    // 下午交易开始
        afternoon_end: "15:00",      // 收盘
        post_market_start: "15:10"   // 盘后开始
    }
};

// 检查是否为交易日
function isTradingDay(date = new Date()) {
    const year = date.getFullYear();
    const month = (date.getMonth() + 1).toString().padStart(2, '0');
    const day = date.getDate().toString().padStart(2, '0');
    const dateStr = `${year}-${month}-${day}`;
    const dayOfWeek = date.getDay(); // 0=周日, 1=周一, ..., 6=周六
    
    // 1. 检查是否为周末
    if (!TRADING_SCHEDULE.trading_days.normal.includes(dayOfWeek)) {
        return { is_trading_day: false, reason: "周末" };
    }
    
    // 2. 检查是否为节假日
    if (TRADING_SCHEDULE.trading_days.holidays.includes(dateStr)) {
        return { is_trading_day: false, reason: "法定节假日" };
    }
    
    // 3. 检查是否为特殊调休工作日（周末上班但股市不开）
    if (TRADING_SCHEDULE.trading_days.special_workdays.includes(dateStr)) {
        return { is_trading_day: false, reason: "调休工作日（股市休市）" };
    }
    
    return { is_trading_day: true, reason: "正常交易日" };
}

// 检查当前是否在交易时间段内
function isTradingTime(date = new Date()) {
    const tradingDayCheck = isTradingDay(date);
    if (!tradingDayCheck.is_trading_day) {
        return { 
            is_trading_time: false, 
            reason: tradingDayCheck.reason,
            next_event: null
        };
    }
    
    const hours = date.getHours().toString().padStart(2, '0');
    const minutes = date.getMinutes().toString().padStart(2, '0');
    const currentTime = `${hours}:${minutes}`;
    
    const times = TRADING_SCHEDULE.key_times;
    
    // 检查各个时间段
    if (currentTime >= times.pre_market_start && currentTime < times.pre_market_end) {
        return { 
            is_trading_time: false, 
            reason: "盘前准备时段",
            next_event: `开盘 ${times.morning_start}`,
            period: "pre_market"
        };
    }
    
    if (currentTime >= times.morning_start && currentTime <= times.morning_end) {
        return { 
            is_trading_time: true, 
            reason: "上午交易时段",
            next_event: `午休 ${times.morning_end} - ${times.afternoon_start}`,
            period: "morning_trading"
        };
    }
    
    if (currentTime > times.morning_end && currentTime < times.afternoon_start) {
        return { 
            is_trading_time: false, 
            reason: "午间休市",
            next_event: `下午开盘 ${times.afternoon_start}`,
            period: "lunch_break"
        };
    }
    
    if (currentTime >= times.afternoon_start && currentTime <= times.afternoon_end) {
        return { 
            is_trading_time: true, 
            reason: "下午交易时段",
            next_event: `收盘 ${times.afternoon_end}`,
            period: "afternoon_trading"
        };
    }
    
    if (currentTime > times.afternoon_end && currentTime < times.post_market_start) {
        return { 
            is_trading_time: false, 
            reason: "收盘后准备时段",
            next_event: `盘后复盘 ${times.post_market_start}`,
            period: "post_close"
        };
    }
    
    if (currentTime >= times.post_market_start) {
        return { 
            is_trading_time: false, 
            reason: "盘后复盘时段",
            next_event: "次日交易",
            period: "post_market"
        };
    }
    
    // 开盘前
    return { 
        is_trading_time: false, 
        reason: "非交易时间",
        next_event: `盘前开始 ${times.pre_market_start}`,
        period: "before_market"
    };
}

// 获取下一个交易日
function getNextTradingDay(date = new Date()) {
    let nextDay = new Date(date);
    let attempts = 0;
    const maxAttempts = 10; // 最多查找10天
    
    while (attempts < maxAttempts) {
        nextDay.setDate(nextDay.getDate() + 1);
        const check = isTradingDay(nextDay);
        
        if (check.is_trading_day) {
            return {
                date: nextDay.toISOString().split('T')[0],
                weekday: ['周日', '周一', '周二', '周三', '周四', '周五', '周六'][nextDay.getDay()],
                days_until: attempts + 1
            };
        }
        
        attempts++;
    }
    
    return null;
}

// 获取上一个交易日
function getPreviousTradingDay(date = new Date()) {
    let prevDay = new Date(date);
    let attempts = 0;
    const maxAttempts = 10;
    
    while (attempts < maxAttempts) {
        prevDay.setDate(prevDay.getDate() - 1);
        const check = isTradingDay(prevDay);
        
        if (check.is_trading_day) {
            return {
                date: prevDay.toISOString().split('T')[0],
                weekday: ['周日', '周一', '周二', '周三', '周四', '周五', '周六'][prevDay.getDay()],
                days_ago: attempts + 1
            };
        }
        
        attempts++;
    }
    
    return null;
}

// 检查是否在特定任务时间段内
function checkTaskTimeWindow(taskName, date = new Date()) {
    const timeCheck = isTradingTime(date);
    const currentTime = `${date.getHours().toString().padStart(2, '0')}:${date.getMinutes().toString().padStart(2, '0')}`;
    
    const taskWindows = {
        // 任务1: 盘前扫雷 (8:30~9:15，每15分钟)
        "pre_market_scan": {
            enabled: timeCheck.period === "pre_market",
            window_start: "08:30",
            window_end: "09:15",
            interval_minutes: 15,
            description: "盘前扫雷：排查上一交易日存档股票的新闻"
        },
        
        // 任务2: 盘中频筛 (开盘后~14:00，每30分钟)
        "intraday_screening": {
            enabled: (timeCheck.period === "morning_trading" || 
                     (timeCheck.period === "afternoon_trading" && currentTime < "14:00")),
            window_start: "09:30",
            window_end: "14:00",
            interval_minutes: 30,
            description: "盘中频筛：交易时间段内筛选股票"
        },
        
        // 任务3: 尾盘终筛 (14:00~14:50，每10分钟)
        "final_screening": {
            enabled: timeCheck.period === "afternoon_trading" && 
                    currentTime >= "14:00" && currentTime <= "14:50",
            window_start: "14:00",
            window_end: "14:50",
            interval_minutes: 10,
            description: "尾盘终筛：收盘前密集筛选"
        },
        
        // 任务4: 盘后复盘 (15:10后)
        "post_market_review": {
            enabled: timeCheck.period === "post_market",
            window_start: "15:10",
            window_end: "23:59",
            interval_minutes: null, // 一次性任务
            description: "盘后复盘：验证策略并触发反推进化"
        }
    };
    
    const taskConfig = taskWindows[taskName];
    if (!taskConfig) {
        return { valid: false, reason: `未知任务: ${taskName}` };
    }
    
    if (!taskConfig.enabled) {
        return { 
            valid: false, 
            reason: `不在任务时间段内 (当前: ${timeCheck.period})`,
            current_period: timeCheck.period,
            task_period: taskConfig.description
        };
    }
    
    // 检查是否在时间窗口内
    if (currentTime < taskConfig.window_start || currentTime > taskConfig.window_end) {
        return { 
            valid: false, 
            reason: `当前时间 ${currentTime} 不在任务窗口 ${taskConfig.window_start}-${taskConfig.window_end}`,
            current_time: currentTime,
            window: `${taskConfig.window_start}-${taskConfig.window_end}`
        };
    }
    
    // 检查是否满足间隔要求
    if (taskConfig.interval_minutes) {
        const currentMinute = date.getHours() * 60 + date.getMinutes();
        const interval = taskConfig.interval_minutes;
        
        // 检查是否是间隔的整数倍
        if (currentMinute % interval !== 0) {
            const minutesToNext = interval - (currentMinute % interval);
            return { 
                valid: false, 
                reason: `未到执行时间，${minutesToNext}分钟后执行`,
                interval_minutes: interval,
                minutes_to_next: minutesToNext
            };
        }
    }
    
    return { 
        valid: true, 
        reason: `可以执行 ${taskConfig.description}`,
        task_config: taskConfig,
        current_time: currentTime
    };
}

// 主测试函数
function main() {
    console.log("📅 交易日检查系统测试");
    console.log("=".repeat(70));
    
    const now = new Date();
    console.log(`当前时间: ${now.toLocaleString('zh-CN')}`);
    console.log(`北京时间: ${now.getHours().toString().padStart(2, '0')}:${now.getMinutes().toString().padStart(2, '0')}`);
    
    // 检查交易日
    const tradingDayCheck = isTradingDay(now);
    console.log(`\n📊 交易日检查:`);
    console.log(`  是否交易日: ${tradingDayCheck.is_trading_day ? '✅ 是' : '❌ 否'}`);
    console.log(`  原因: ${tradingDayCheck.reason}`);
    
    // 检查交易时间
    const tradingTimeCheck = isTradingTime(now);
    console.log(`\n⏰ 交易时间检查:`);
    console.log(`  是否交易时间: ${tradingTimeCheck.is_trading_time ? '✅ 是' : '❌ 否'}`);
    console.log(`  原因: ${tradingTimeCheck.reason}`);
    if (tradingTimeCheck.next_event) {
        console.log(`  下一个事件: ${tradingTimeCheck.next_event}`);
    }
    console.log(`  时间段: ${tradingTimeCheck.period}`);
    
    // 获取前后交易日
    const prevTradingDay = getPreviousTradingDay(now);
    const nextTradingDay = getNextTradingDay(now);
    
    console.log(`\n📅 前后交易日:`);
    if (prevTradingDay) {
        console.log(`  上一个交易日: ${prevTradingDay.date} (${prevTradingDay.weekday})`);
    }
    if (nextTradingDay) {
        console.log(`  下一个交易日: ${nextTradingDay.date} (${nextTradingDay.weekday})`);
    }
    
    // 检查各个任务时间段
    console.log(`\n🔍 任务时间段检查:`);
    const tasks = ["pre_market_scan", "intraday_screening", "final_screening", "post_market_review"];
    
    tasks.forEach(task => {
        const check = checkTaskTimeWindow(task, now);
        console.log(`\n  ${task}:`);
        console.log(`    状态: ${check.valid ? '✅ 可执行' : '⏸️ 不可执行'}`);
        console.log(`    原因: ${check.reason}`);
        
        if (check.task_config) {
            console.log(`    描述: ${check.task_config.description}`);
            if (check.task_config.interval_minutes) {
                console.log(`    间隔: ${check.task_config.interval_minutes}分钟`);
            }
        }
    });
    
    // 生成cron表达式建议
    console.log(`\n⏱️  Cron表达式建议:`);
    console.log(`  盘前扫雷: 30-45/15 8 * * 1-5`);
    console.log(`  盘中频筛: 0,30 9-13 * * 1-5`);
    console.log(`  尾盘终筛: 0-50/10 14 * * 1-5`);
    console.log(`  盘后复盘: 10 15 * * 1-5`);
    
    // 保存配置
    const config = {
        trading_schedule: TRADING_SCHEDULE,
        current_status: {
            date: now.toISOString(),
            is_trading_day: tradingDayCheck,
            is_trading_time: tradingTimeCheck,
            task_checks: tasks.reduce((acc, task) => {
                acc[task] = checkTaskTimeWindow(task, now);
                return acc;
            }, {})
        }
    };
    
    const fs = require('fs');
    const path = require('path');
    const configPath = path.join(__dirname, 'trading_schedule_config.json');
    fs.writeFileSync(configPath, JSON.stringify(config, null, 2), 'utf8');
    
    console.log(`\n✅ 交易日检查配置已保存: ${configPath}`);
    
    return config;
}

// 运行测试
const config = main();

console.log("\n" + "=".repeat(70));
console.log("📋 系统状态总结:");
console.log("=".repeat(70));

console.log(`当前时间: ${new Date().toLocaleString('zh-CN')}`);
console.log(`交易日状态: ${config.current_status.is_trading_day.is_trading_day ? '✅ 交易日' : '❌ 非交易日'}`);
console.log(`交易时间状态: ${config.current_status.is_trading_time.is_trading_time ? '✅ 交易中' : '❌ 非交易时间'}`);

// 显示可执行任务
const executableTasks = Object.entries(config.current_status.task_checks)
    .filter(([_, check]) => check.valid)
    .map(([task, _]) => task);

if (executableTasks.length > 0) {
    console.log(`\n🚀 当前可执行任务: ${executableTasks.join(', ')}`);
} else {
    console.log(`\n⏸️  当前无可执行任务`);
}

console.log("\n💡 使用说明:");
console.log("  1. 在定时任务中调用 checkTaskTimeWindow('task_name') 检查是否可执行");
console.log("  2. 使用 isTradingDay() 检查是否为交易日");
console.log("  3. 使用 isTradingTime() 检查是否在交易时间段内");
console.log("  4. 节假日列表