// 简单测试mx-xuangu API连接
console.log("📡 测试mx-xuangu API连接");
console.log("=".repeat(70));

const fs = require('fs');
const path = require('path');
const https = require('https');

// API配置
const API_CONFIG = {
    endpoint: "https://mkapi2.dfcfs.com/finskillshub/api/claw/stock-screen",
    apiKey: "mkt_fgN0XtXWjMxR9zxtDS9EkHx9pz6-OzfHl06C1ywGdls",
    timeout: 15000
};

// 获取API密钥
function getApiKey() {
    // 优先使用环境变量
    if (process.env.MX_APIKEY) {
        console.log(`✅ 使用环境变量API密钥`);
        return process.env.MX_APIKEY;
    }
    
    console.log(`⚠️  使用配置文件API密钥`);
    return API_CONFIG.apiKey;
}

// 构建简单测试条件
function buildTestConditions() {
    return {
        // 简单条件：主板股票，今日上涨
        conditions: [
            {
                field: "code",
                operator: "regex",
                value: "^(60|00)"
            },
            {
                field: "change",
                operator: "gt",
                value: 0
            }
        ],
        sort: [
            {
                field: "change",
                order: "desc"
            }
        ],
        limit: 10,
        fields: ["code", "name", "price", "change", "volume"]
    };
}

// 发送测试请求
async function testApiConnection() {
    console.log("🔍 测试API连接...");
    
    const apiKey = getApiKey();
    if (!apiKey) {
        throw new Error("未找到API密钥");
    }
    
    const conditions = buildTestConditions();
    const postData = JSON.stringify({
        conditions: conditions,
        api_key: apiKey,
        timestamp: Date.now()
    });
    
    return new Promise((resolve, reject) => {
        const options = {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'Content-Length': Buffer.byteLength(postData),
                'User-Agent': 'A股选股系统测试/1.0'
            },
            timeout: API_CONFIG.timeout
        };
        
        console.log(`📤 发送请求到: ${API_CONFIG.endpoint}`);
        console.log(`🔑 API密钥: ${apiKey.substring(0, 15)}...`);
        
        const req = https.request(API_CONFIG.endpoint, options, (res) => {
            console.log(`📥 收到响应: 状态码 ${res.statusCode}`);
            
            let data = '';
            res.on('data', (chunk) => {
                data += chunk;
            });
            
            res.on('end', () => {
                try {
                    const result = JSON.parse(data);
                    
                    if (res.statusCode === 200) {
                        console.log(`✅ API连接成功`);
                        resolve(result);
                    } else {
                        console.error(`❌ API错误: ${result.message || '未知错误'}`);
                        reject(new Error(`API返回错误: ${result.message || '状态码 ' + res.statusCode}`));
                    }
                } catch (error) {
                    console.error(`❌ 响应解析失败: ${error.message}`);
                    console.log(`原始响应: ${data.substring(0, 200)}...`);
                    reject(new Error(`响应解析失败: ${error.message}`));
                }
            });
        });
        
        req.on('error', (error) => {
            console.error(`❌ 网络错误: ${error.message}`);
            reject(new Error(`网络错误: ${error.message}`));
        });
        
        req.on('timeout', () => {
            console.error(`❌ 请求超时`);
            req.destroy();
            reject(new Error('请求超时'));
        });
        
        req.write(postData);
        req.end();
    });
}

// 处理测试结果
function processTestResult(result) {
    console.log("\n🔍 处理测试结果...");
    
    if (!result || typeof result !== 'object') {
        throw new Error("无效的API响应");
    }
    
    // 检查响应结构
    console.log(`响应类型: ${typeof result}`);
    console.log(`响应键: ${Object.keys(result).join(', ')}`);
    
    if (result.data && Array.isArray(result.data)) {
        const stocks = result.data;
        console.log(`✅ 收到 ${stocks.length} 只股票数据`);
        
        // 显示前5只股票
        if (stocks.length > 0) {
            console.log("\n📊 前5只股票数据:");
            stocks.slice(0, 5).forEach((stock, index) => {
                console.log(`\n${index + 1}. ${stock.code || 'N/A'} ${stock.name || 'N/A'}`);
                console.log(`   价格: ${stock.price || 'N/A'}`);
                console.log(`   涨跌: ${stock.change || 'N/A'}%`);
                console.log(`   成交量: ${stock.volume || 'N/A'}`);
            });
        }
        
        return {
            success: true,
            stock_count: stocks.length,
            sample_data: stocks.slice(0, 5),
            raw_response: result
        };
    } else {
        console.log(`⚠️  响应数据格式不符，完整响应:`);
        console.log(JSON.stringify(result, null, 2).substring(0, 500) + '...');
        
        return {
            success: false,
            message: "响应数据格式不符",
            raw_response: result
        };
    }
}

// 保存测试结果
function saveTestResult(result) {
    const timestamp = new Date().toISOString().replace(/[:.]/g, '-');
    const filename = `api_test_${timestamp}.json`;
    
    const testDir = path.join(__dirname, 'api_tests');
    if (!fs.existsSync(testDir)) {
        fs.mkdirSync(testDir, { recursive: true });
    }
    
    const filepath = path.join(testDir, filename);
    
    const saveData = {
        timestamp: new Date().toISOString(),
        test_result: result,
        api_config: {
            endpoint: API_CONFIG.endpoint,
            api_key_used: getApiKey().substring(0, 10) + '...'
        }
    };
    
    fs.writeFileSync(filepath, JSON.stringify(saveData, null, 2), 'utf8');
    
    console.log(`💾 测试结果已保存: ${filepath}`);
    return filepath;
}

// 主函数
async function main() {
    console.log("🚀 开始API连接测试...");
    console.log("=".repeat(70));
    
    try {
        // 1. 测试API连接
        const apiResponse = await testApiConnection();
        
        // 2. 处理结果
        const testResult = processTestResult(apiResponse);
        
        // 3. 保存结果
        const savedFile = saveTestResult(testResult);
        
        // 4. 总结
        console.log("\n" + "=".repeat(70));
        console.log("🎉 API连接测试完成!");
        console.log("=".repeat(70));
        
        if (testResult.success) {
            console.log(`✅ 测试结果: 成功`);
            console.log(`📊 收到股票数据: ${testResult.stock_count} 只`);
            console.log(`💾 结果文件: ${savedFile}`);
            
            // 更新系统状态
            updateSystemState(true, testResult.stock_count);
            
            return {
                success: true,
                stock_count: testResult.stock_count,
                file: savedFile
            };
        } else {
            console.log(`⚠️  测试结果: 部分成功`);
            console.log(`📝 详情: ${testResult.message}`);
            console.log(`💾 结果文件: ${savedFile}`);
            
            updateSystemState(false, 0);
            
            return {
                success: false,
                message: testResult.message,
                file: savedFile
            };
        }
        
    } catch (error) {
        console.error(`\n❌ 测试失败: ${error.message}`);
        
        // 保存错误信息
        const errorData = {
            timestamp: new Date().toISOString(),
            error: error.message,
            stack: error.stack,
            api_config: API_CONFIG
        };
        
        const errorDir = path.join(__dirname, 'api_tests', 'errors');
        if (!fs.existsSync(errorDir)) {
            fs.mkdirSync(errorDir, { recursive: true });
        }
        
        const errorFile = path.join(errorDir, `error_${Date.now()}.json`);
        fs.writeFileSync(errorFile, JSON.stringify(errorData, null, 2), 'utf8');
        
        console.log(`📝 错误报告已保存: ${errorFile}`);
        
        updateSystemState(false, 0, error.message);
        
        return {
            success: false,
            error: error.message,
            errorFile: errorFile
        };
    }
}

// 更新系统状态
function updateSystemState(success, stockCount, error = null) {
    const sessionStatePath = path.join(__dirname, 'SESSION-STATE.md');
    
    if (fs.existsSync(sessionStatePath)) {
        let content = fs.readFileSync(sessionStatePath, 'utf8');
        
        const testUpdate = `\n\n## 📡 mx-xuangu API连接测试 (${new Date().toLocaleString('zh-CN')})

### 测试结果
${success ? '✅ **连接成功**' : '❌ **连接失败**'}

${success ? `
**成功指标:**
- API端点: ${API_CONFIG.endpoint}
- 响应状态: 200 OK
- 收到数据: ${stockCount} 只股票
- 测试时间: ${new Date().toLocaleString('zh-CN')}

**结论:** API连接正常，可以获取实时股票数据
` : `
**失败原因:**
- 错误信息: ${error || '未知错误'}
- API端点: ${API_CONFIG.endpoint}
- 测试时间: ${new Date().toLocaleString('zh-CN')}

**建议检查:**
1. API密钥是否正确
2. 网络连接是否正常
3. API服务是否可用
`}

### 下一步
${success ? `
1. **完善选股条件** - 添加更多筛选维度
2. **集成到主系统** - 替换模拟数据为真实数据
3. **定时任务更新** - 使用真实API数据
4. **性能优化** - 处理大量数据
` : `
1. **检查API密钥** - 确认密钥有效性
2. **网络诊断** - 检查网络连接
3. **联系支持** - 确认API服务状态
4. **使用备用方案** - 暂时使用模拟数据
`}`;
        
        content += testUpdate;
        fs.writeFileSync(sessionStatePath, content, 'utf8');
        
        console.log(`✅ 系统状态已更新`);
    }
}

// 运行测试
main().then(result => {
    console.log("\n📋 测试完成总结:");
    console.log(`   成功: ${result.success ? '✅ 是' : '❌ 否'}`);
    
    if (result.success) {
        console.log(`   股票数量: ${result.stock_count}`);
        console.log(`   结果文件: ${result.file}`);
        console.log("\n🚀 可以开始真实数据选股!");
    } else {
        console.log(`   错误: ${result.error || result.message}`);
        console.log(`   错误文件: ${result.errorFile || result.file}`);
        console.log("\n⚠️  需要先解决API连接问题");
    }
    
    process.exit(result.success ? 0 : 1);
}).catch(error => {
    console.error(`❌ 测试过程出错: ${error.message}`);
    process.exit(1);
});