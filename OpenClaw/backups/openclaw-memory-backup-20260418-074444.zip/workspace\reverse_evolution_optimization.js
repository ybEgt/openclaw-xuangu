// 反推进化系统优化
console.log("🔄 反推进化系统优化");
console.log("=".repeat(70));

const fs = require('fs');
const path = require('path');

// 1. 加载历史数据
console.log("📁 加载历史数据...");

function loadHistoricalData() {
    const dataDir = path.join(__dirname, 'working_results');
    const files = fs.readdirSync(dataDir)
        .filter(f => f.startsWith('working_') && f.endsWith('.json'))
        .sort()
        .reverse()
        .slice(0, 5); // 最近5次
    
    const historicalData = [];
    
    files.forEach(file => {
        try {
            const filePath = path.join(dataDir, file);
            const data = JSON.parse(fs.readFileSync(filePath, 'utf8'));
            historicalData.push({
                file: file,
                timestamp: data.metadata.timestamp,
                stocks: data.processed_stocks || [],
                query: data.metadata.query
            });
            console.log(`✅ 加载: ${file} (${data.metadata.timestamp})`);
        } catch (error) {
            console.log(`⚠️  跳过: ${file} - ${error.message}`);
        }
    });
    
    return historicalData;
}

// 2. 分析历史表现
console.log("\n📊 分析历史表现...");

function analyzeHistoricalPerformance(historicalData) {
    const analysis = {
        total_runs: historicalData.length,
        avg_stocks_per_run: 0,
        score_distribution: {},
        top_performers: [],
        consistency_metrics: {}
    };
    
    let totalStocks = 0;
    let totalScore = 0;
    const allStocks = [];
    
    historicalData.forEach(run => {
        totalStocks += run.stocks.length;
        
        run.stocks.forEach(stock => {
            totalScore += stock.score;
            allStocks.push({
                code: stock.code,
                name: stock.name,
                score: stock.score,
                run_date: run.timestamp
            });
        });
    });
    
    analysis.avg_stocks_per_run = Math.round(totalStocks / historicalData.length);
    analysis.avg_score = Math.round(totalScore / totalStocks);
    
    // 找出表现最好的股票
    const stockPerformance = {};
    allStocks.forEach(stock => {
        if (!stockPerformance[stock.code]) {
            stockPerformance[stock.code] = {
                code: stock.code,
                name: stock.name,
                appearances: 0,
                total_score: 0,
                dates: []
            };
        }
        
        stockPerformance[stock.code].appearances++;
        stockPerformance[stock.code].total_score += stock.score;
        stockPerformance[stock.code].dates.push(stock.run_date);
    });
    
    // 计算平均分并排序
    analysis.top_performers = Object.values(stockPerformance)
        .map(stock => ({
            ...stock,
            avg_score: Math.round(stock.total_score / stock.appearances)
        }))
        .sort((a, b) => b.avg_score - a.avg_score)
        .slice(0, 10);
    
    // 评分分布
    analysis.score_distribution = {
        '90-100': allStocks.filter(s => s.score >= 90).length,
        '80-89': allStocks.filter(s => s.score >= 80 && s.score < 90).length,
        '70-79': allStocks.filter(s => s.score >= 70 && s.score < 80).length,
        '60-69': allStocks.filter(s => s.score >= 60 && s.score < 70).length,
        '0-59': allStocks.filter(s => s.score < 60).length
    };
    
    return analysis;
}

// 3. 识别有效因子
console.log("\n🔍 识别有效因子...");

function identifyEffectiveFactors(historicalData) {
    const factors = {
        price_change: { total: 0, count: 0, avg_impact: 0 },
        volume_ratio: { total: 0, count: 0, avg_impact: 0 },
        turnover_rate: { total: 0, count: 0, avg_impact: 0 },
        market_cap: { total: 0, count: 0, avg_impact: 0 },
        pe_ratio: { total: 0, count: 0, avg_impact: 0 }
    };
    
    // 分析每个股票的因子表现
    historicalData.forEach(run => {
        run.stocks.forEach(stock => {
            // 模拟因子影响分析
            if (stock.change > 5) {
                factors.price_change.total += stock.score * 0.3;
                factors.price_change.count++;
            }
            
            if (stock.volume_ratio > 2) {
                factors.volume_ratio.total += stock.score * 0.2;
                factors.volume_ratio.count++;
            }
            
            if (stock.turnover > 2 && stock.turnover < 20) {
                factors.turnover_rate.total += stock.score * 0.15;
                factors.turnover_rate.count++;
            }
        });
    });
    
    // 计算平均影响
    Object.keys(factors).forEach(factor => {
        if (factors[factor].count > 0) {
            factors[factor].avg_impact = factors[factor].total / factors[factor].count;
        }
    });
    
    return factors;
}

// 4. 优化评分权重
console.log("\n⚖️  优化评分权重...");

function optimizeScoringWeights(currentWeights, factorAnalysis) {
    const optimized = { ...currentWeights };
    
    // 基于因子影响调整权重
    const totalImpact = Object.values(factorAnalysis).reduce((sum, f) => sum + (f.avg_impact || 0), 0);
    
    if (totalImpact > 0) {
        Object.keys(factorAnalysis).forEach(factor => {
            const impact = factorAnalysis[factor].avg_impact || 0;
            if (impact > 0) {
                // 增加有效因子的权重
                const increase = (impact / totalImpact) * 0.1; // 最多增加10%
                optimized[factor] = Math.min(0.4, optimized[factor] + increase);
            }
        });
        
        // 归一化
        const total = Object.values(optimized).reduce((a, b) => a + b, 0);
        Object.keys(optimized).forEach(key => {
            optimized[key] = optimized[key] / total;
        });
    }
    
    return optimized;
}

// 5. 生成进化建议
console.log("\n💡 生成进化建议...");

function generateEvolutionRecommendations(analysis, factors, optimizedWeights) {
    const recommendations = [];
    
    // 基于历史表现的建议
    if (analysis.avg_score < 70) {
        recommendations.push({
            type: "score_improvement",
            priority: "high",
            suggestion: "提高评分阈值，当前平均分较低",
            action: "将最低评分阈值从60提高到65"
        });
    }
    
    // 基于因子分析的建议
    const effectiveFactors = Object.entries(factors)
        .filter(([_, data]) => data.avg_impact > 50)
        .map(([factor]) => factor);
    
    if (effectiveFactors.length > 0) {
        recommendations.push({
            type: "factor_optimization",
            priority: "medium",
            suggestion: `加强有效因子权重: ${effectiveFactors.join(', ')}`,
            action: `调整权重配置`
        });
    }
    
    // 基于一致性的建议
    if (analysis.top_performers.length > 0) {
        const consistentStocks = analysis.top_performers.filter(s => s.appearances >= 2);
        if (consistentStocks.length > 0) {
            recommendations.push({
                type: "stock_selection",
                priority: "low",
                suggestion: `关注表现稳定的股票: ${consistentStocks.slice(0, 3).map(s => s.code).join(', ')}`,
                action: "将这些股票加入观察列表"
            });
        }
    }
    
    return recommendations;
}

// 6. 创建新版本策略
console.log("\n🏷️  创建新版本策略...");

function createNewStrategyVersion(currentConfig, optimizedWeights, recommendations) {
    const version = {
        version: "1.1.0",
        created: new Date().toISOString(),
        based_on: `分析 ${currentConfig.historical_runs || 0} 次历史运行`,
        changes: [],
        config: {
            ...currentConfig,
            scoring_weights: optimizedWeights,
            updated_at: new Date().toISOString()
        }
    };
    
    // 记录变化
    if (JSON.stringify(currentConfig.scoring_weights) !== JSON.stringify(optimizedWeights)) {
        version.changes.push("优化评分权重配置");
    }
    
    recommendations.forEach(rec => {
        version.changes.push(rec.suggestion);
    });
    
    return version;
}

// 7. 测试新策略
console.log("\n🧪 测试新策略...");

function testNewStrategy(newStrategy, historicalData) {
    const testResults = {
        strategy: newStrategy.version,
        test_cases: historicalData.length,
        improvements: [],
        regressions: [],
        overall_impact: "待评估"
    };
    
    // 模拟测试每个历史案例
    historicalData.forEach((run, index) => {
        const originalScores = run.stocks.map(s => s.score);
        const avgOriginal = originalScores.reduce((a, b) => a + b, 0) / originalScores.length;
        
        // 模拟新策略评分
        const newScores = run.stocks.map(stock => {
            let score = 50;
            
            // 使用新权重
            if (stock.change > 0) {
                score += Math.min(30, stock.change * newStrategy.config.scoring_weights.price_change * 100);
            }
            
            if (stock.volume_ratio > 1) {
                score += Math.min(20, (stock.volume_ratio - 1) * newStrategy.config.scoring_weights.volume_ratio * 100);
            }
            
            if (stock.turnover > 0.5 && stock.turnover < 20) {
                score += Math.min(15, stock.turnover * newStrategy.config.scoring_weights.turnover_rate * 10);
            }
            
            return Math.max(0, Math.min(100, Math.round(score)));
        });
        
        const avgNew = newScores.reduce((a, b) => a + b, 0) / newScores.length;
        const improvement = avgNew - avgOriginal;
        
        if (improvement > 0) {
            testResults.improvements.push({
                run: index + 1,
                improvement: improvement.toFixed(2),
                original_avg: avgOriginal.toFixed(1),
                new_avg: avgNew.toFixed(1)
            });
        } else if (improvement < 0) {
            testResults.regressions.push({
                run: index + 1,
                regression: Math.abs(improvement).toFixed(2)
            });
        }
    });
    
    // 评估整体影响
    const totalImprovement = testResults.improvements.reduce((sum, imp) => sum + parseFloat(imp.improvement), 0);
    const totalRegression = testResults.regressions.reduce((sum, reg) => sum + parseFloat(reg.regression), 0);
    
    if (totalImprovement > totalRegression * 2) {
        testResults.overall_impact = "显著改进";
    } else if (totalImprovement > totalRegression) {
        testResults.overall_impact = "轻微改进";
    } else if (totalImprovement === totalRegression) {
        testResults.overall_impact = "无变化";
    } else {
        testResults.overall_impact = "需要调整";
    }
    
    return testResults;
}

// 8. 保存进化结果
console.log("\n💾 保存进化结果...");

function saveEvolutionResults(newStrategy, testResults, recommendations) {
    const timestamp = new Date().toISOString().replace(/[:.]/g, '-');
    const evolutionDir = path.join(__dirname, 'evolution_results');
    
    if (!fs.existsSync(evolutionDir)) {
        fs.mkdirSync(evolutionDir, { recursive: true });
    }
    
    // 保存新策略
    const strategyFile = path.join(evolutionDir, `strategy_v${newStrategy.version.replace(/\./g, '_')}.json`);
    fs.writeFileSync(strategyFile, JSON.stringify(newStrategy, null, 2), 'utf8');
    
    // 保存测试结果
    const testFile = path.join(evolutionDir, `test_results_${timestamp}.json`);
    fs.writeFileSync(testFile, JSON.stringify(testResults, null, 2), 'utf8');
    
    // 保存进化报告
    const reportFile = path.join(evolutionDir, `evolution_report_${timestamp}.md`);
    const report = generateEvolutionReport(newStrategy, testResults, recommendations);
    fs.writeFileSync(reportFile, report, 'utf8');
    
    console.log(`✅ 策略保存: ${strategyFile}`);
    console.log(`✅ 测试结果: ${testFile}`);
    console.log(`✅ 进化报告: ${reportFile}`);
    
    return { strategyFile, testFile, reportFile };
}

// 9. 生成进化报告
function generateEvolutionReport(newStrategy, testResults, recommendations) {
    return `# 反推进化报告 - 版本 ${newStrategy.version}

## 进化概览
- **进化时间:** ${new Date().toLocaleString('zh-CN')}
- **基于数据:** ${newStrategy.based_on}
- **整体影响:** ${testResults.overall_impact}

## 主要变化
${newStrategy.changes.map(change => `- ${change}`).join('\n')}

## 配置更新
### 评分权重优化
${Object.entries(newStrategy.config.scoring_weights).map(([factor, weight]) => 
`- **${factor}:** ${weight.toFixed(3)}`
).join('\n')}

## 测试结果
### 改进案例 (${testResults.improvements.length}个)
${testResults.improvements.map(imp => 
`- 运行${imp.run}: 提升${imp.improvement}分 (${imp.original_avg} → ${imp.new_avg})`
).join('\n')}

### 回归案例 (${testResults.regressions.length}个)
${testResults.regressions.length > 0 ? 
testResults.regressions.map(reg => 
`- 运行${reg.run}: 下降${reg.regression}分`
).join('\n') : '无'}

## 进化建议
${recommendations.map(rec => 
`### ${rec.priority === 'high' ? '🔴 高优先级' : rec.priority === 'medium' ? '🟡 中优先级' : '🟢 低优先级'}
**建议:** ${rec.suggestion}
**行动:** ${rec.action}`
).join('\n\n')}

## 下一步
1. **验证新策略** - 在实际选股中测试
2. **监控效果** - 跟踪新策略表现
3. **持续优化** - 基于新数据进一步调整

---
*进化系统: A股主板短线选股系统 - 反推进化机制*`;
}

// 主函数
function main() {
    console.log("🚀 开始反推进化优化...");
    console.log("=".repeat(70));
    
    try {
        // 1. 加载历史数据
        const historicalData = loadHistoricalData();
        
        if (historicalData.length === 0) {
            console.log("⚠️  无历史数据，跳过进化");
            return;
        }
        
        console.log(`📊 加载 ${historicalData.length} 次历史运行`);
        
        // 2. 分析历史表现
        const performanceAnalysis = analyzeHistoricalPerformance(historicalData);
        console.log(`📈 平均评分: ${performanceAnalysis.avg_score}`);
        console.log(`📊 评分分布: ${JSON.stringify(performanceAnalysis.score_distribution)}`);
        
        // 3. 识别有效因子
        const factorAnalysis = identifyEffectiveFactors(historicalData);
        console.log(`🔍 有效因子分析完成`);
        
        // 4. 当前配置
        const currentConfig = {
            scoring_weights: {
                price_change: 0.30,
                volume_ratio: 0.20,
                turnover_rate: 0.15,
                market_cap: 0.10,
                pe_ratio: 0.10,
                pb_ratio: 0.10,
                capital_flow: 0.05
            },
            historical_runs: historicalData.length
        };
        
        // 5. 优化权重
        const optimizedWeights = optimizeScoringWeights(currentConfig.scoring_weights, factorAnalysis);
        console.log(`⚖️  权重优化完成`);
        
        // 6. 生成建议
        const recommendations = generateEvolutionRecommendations(performanceAnalysis, factorAnalysis, optimizedWeights);
        console.log(`💡 生成 ${recommendations.length} 条进化建议`);
        
        // 7. 创建新策略
        const newStrategy = createNewStrategyVersion(currentConfig, optimizedWeights, recommendations);
        console.log(`🏷️  创建新策略版本: ${newStrategy.version}`);
        
        // 8. 测试新策略
        const testResults = testNewStrategy(newStrategy, historicalData);
        console.log(`🧪 测试完成: ${testResults.overall_impact}`);
        
        // 9. 保存结果
        const savedFiles = saveEvolutionResults(newStrategy, testResults, recommendations);
        
        // 10. 更新系统配置
        updateSystemConfig(newStrategy, testResults);
        
        console.log("\n" + "=".repeat(70));
        console.log("🎉 反推进化优化完成!");
        console.log("=".repeat(70));
        
        console.log(`\n📋 进化总结:`);
        console.log(`