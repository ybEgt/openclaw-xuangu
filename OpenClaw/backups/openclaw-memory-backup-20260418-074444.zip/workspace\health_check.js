const fs = require('fs');
const path = require('path');
const { execSync } = require('child_process');

// 工作区根目录
const workspaceRoot = path.join(process.env.HOME || process.env.USERPROFILE, '.openclaw', 'workspace');

// 健康评分函数
function calculateHealthScore() {
    let score = 100;
    const issues = [];
    const recommendations = [];

    console.log("🏥 开始Agent健康检查...");
    console.log("=".repeat(60));

    // 1. 检查记忆系统
    console.log("1. 🧠 记忆系统检查");
    
    // 检查SESSION-STATE.md
    const sessionStatePath = path.join(workspaceRoot, 'SESSION-STATE.md');
    if (fs.existsSync(sessionStatePath)) {
        const content = fs.readFileSync(sessionStatePath, 'utf8');
        const lines = content.split('\n').length;
        const lastModified = fs.statSync(sessionStatePath).mtime;
        const hoursSinceUpdate = (Date.now() - lastModified.getTime()) / (1000 * 60 * 60);
        
        console.log(`   ✅ SESSION-STATE.md 存在 (${lines} 行)`);
        console.log(`   📅 最后更新: ${lastModified.toLocaleString('zh-CN')}`);
        
        if (hoursSinceUpdate > 24) {
            issues.push("SESSION-STATE.md超过24小时未更新");
            score -= 5;
        }
    } else {
        issues.push("SESSION-STATE.md不存在");
        score -= 10;
    }

    // 检查记忆目录结构
    const memoryDirs = ['episodic', 'semantic', 'procedural', 'snapshots'];
    let missingDirs = [];
    
    memoryDirs.forEach(dir => {
        const dirPath = path.join(workspaceRoot, 'memory', dir);
        if (!fs.existsSync(dirPath)) {
            missingDirs.push(dir);
        }
    });
    
    if (missingDirs.length > 0) {
        issues.push(`记忆目录缺失: ${missingDirs.join(', ')}`);
        score -= 5;
    } else {
        console.log(`   ✅ 记忆目录结构完整`);
    }

    // 检查今日情景记忆
    const today = new Date().toISOString().split('T')[0];
    const todayEpisodic = path.join(workspaceRoot, 'memory', 'episodic', `${today}.md`);
    if (fs.existsSync(todayEpisodic)) {
        const content = fs.readFileSync(todayEpisodic, 'utf8');
        const entries = (content.match(/## \d{2}:\d{2} -/g) || []).length;
        console.log(`   ✅ 今日情景记忆已记录 (${entries} 个条目)`);
    } else {
        issues.push("今日情景记忆未创建");
        score -= 5;
    }

    // 2. 检查研究报告
    console.log("\n2. 📊 研究报告检查");
    
    const reportsDir = path.join(workspaceRoot, 'research_reports');
    if (fs.existsSync(reportsDir)) {
        const reports = fs.readdirSync(reportsDir).filter(f => f.endsWith('.md'));
        console.log(`   ✅ 研究报告目录存在 (${reports.length} 个报告)`);
        
        if (reports.length === 0) {
            issues.push("研究报告目录为空");
            score -= 5;
        } else {
            // 检查最新报告
            const latestReport = reports.sort().reverse()[0];
            const reportPath = path.join(reportsDir, latestReport);
            const reportStats = fs.statSync(reportPath);
            const reportAge = (Date.now() - reportStats.mtime.getTime()) / (1000 * 60 * 60 * 24);
            
            console.log(`   📄 最新报告: ${latestReport}`);
            console.log(`   📅 报告年龄: ${reportAge.toFixed(1)} 天`);
            
            if (reportAge > 7) {
                recommendations.push("建议生成新的研究报告");
            }
        }
    } else {
        issues.push("研究报告目录不存在");
        score -= 5;
    }

    // 3. 检查API连接
    console.log("\n3. 🔌 API连接检查");
    
    const apiKeysPath = path.join(process.env.USERPROFILE, 'Desktop', 'OpenClaw', 'api-keys.json');
    if (fs.existsSync(apiKeysPath)) {
        console.log(`   ✅ API密钥文件存在`);
        
        try {
            const apiKeys = JSON.parse(fs.readFileSync(apiKeysPath, 'utf8'));
            if (apiKeys.mx_api_key) {
                console.log(`   🔑 MX_APIKEY: ${apiKeys.mx_api_key.substring(0, 15)}...`);
            } else {
                issues.push("API密钥文件中缺少mx_api_key");
                score -= 10;
            }
        } catch (e) {
            issues.push(`API密钥文件解析错误: ${e.message}`);
            score -= 10;
        }
    } else {
        issues.push("API密钥文件不存在");
        score -= 15;
    }

    // 4. 检查脚本文件
    console.log("\n4. 📜 脚本文件检查");
    
    const requiredScripts = [
        'smart_stock_analyzer.js',
        'stock_screener_fixed.js',
        'a_stock_research.js',
        'health_check.js'
    ];
    
    let missingScripts = [];
    requiredScripts.forEach(script => {
        const scriptPath = path.join(workspaceRoot, script);
        if (!fs.existsSync(scriptPath)) {
            missingScripts.push(script);
        }
    });
    
    if (missingScripts.length > 0) {
        issues.push(`缺失脚本文件: ${missingScripts.join(', ')}`);
        score -= missingScripts.length * 5;
    } else {
        console.log(`   ✅ 所有必需脚本文件存在`);
    }

    // 5. 检查输出目录
    console.log("\n5. 📁 输出目录检查");
    
    const outputDirs = [
        path.join(workspaceRoot, 'mx_data', 'output'),
        path.join(workspaceRoot, 'research_reports')
    ];
    
    outputDirs.forEach(dir => {
        if (fs.existsSync(dir)) {
            const files = fs.readdirSync(dir).length;
            console.log(`   ✅ ${path.basename(dir)}: ${files} 个文件`);
            
            // 检查磁盘空间
            try {
                const stats = fs.statSync(dir);
                // 这里可以添加磁盘空间检查
            } catch (e) {
                // 忽略权限错误
            }
        } else {
            issues.push(`输出目录不存在: ${dir}`);
            score -= 5;
        }
    });

    // 6. 检查上下文使用率（模拟）
    console.log("\n6. 🧮 上下文使用率检查");
    
    // 估算当前工作区文件大小
    let totalSize = 0;
    function getDirSize(dirPath) {
        let size = 0;
        try {
            const items = fs.readdirSync(dirPath);
            items.forEach(item => {
                const itemPath = path.join(dirPath, item);
                const stat = fs.statSync(itemPath);
                if (stat.isDirectory()) {
                    size += getDirSize(itemPath);
                } else {
                    size += stat.size;
                }
            });
        } catch (e) {
            // 忽略错误
        }
        return size;
    }
    
    totalSize = getDirSize(workspaceRoot);
    const sizeMB = (totalSize / (1024 * 1024)).toFixed(2);
    
    console.log(`   📏 工作区大小: ${sizeMB} MB`);
    
    // 假设上下文限制为10MB（实际值可能不同）
    const contextLimitMB = 10;
    const usagePercent = (totalSize / (contextLimitMB * 1024 * 1024)) * 100;
    
    console.log(`   📊 估算上下文使用率: ${usagePercent.toFixed(1)}%`);
    
    if (usagePercent > 60) {
        console.log(`   ⚠️  警告: 上下文使用率超过60%，建议启动工作缓冲区`);
        recommendations.push("上下文使用率较高，建议清理旧文件或启动工作缓冲区");
    }
    
    if (usagePercent > 85) {
        issues.push("上下文使用率超过85%，存在压缩风险");
        score -= 15;
    }

    // 计算最终分数
    score = Math.max(0, Math.min(100, score));
    
    // 确定等级
    let grade = 'F';
    let emoji = '❌';
    if (score >= 90) { grade = 'A+'; emoji = '🎉'; }
    else if (score >= 80) { grade = 'A'; emoji = '✅'; }
    else if (score >= 70) { grade = 'B'; emoji = '👍'; }
    else if (score >= 60) { grade = 'C'; emoji = '⚠️'; }
    else if (score >= 50) { grade = 'D'; emoji = '🔧'; }
    else { grade = 'F'; emoji = '🚨'; }

    // 生成报告
    console.log("\n" + "=".repeat(60));
    console.log("📋 健康检查报告");
    console.log("=".repeat(60));
    
    console.log(`\n${emoji} 健康分数: ${score}/100 (${grade})`);
    
    if (issues.length > 0) {
        console.log("\n🚨 发现的问题:");
        issues.forEach((issue, idx) => {
            console.log(`  ${idx + 1}. ${issue}`);
        });
    } else {
        console.log("\n✅ 未发现严重问题");
    }
    
    if (recommendations.length > 0) {
        console.log("\n💡 改进建议:");
        recommendations.forEach((rec, idx) => {
            console.log(`  ${idx + 1}. ${rec}`);
        });
    }

    // 保存检查结果
    const checkResult = {
        timestamp: new Date().toISOString(),
        score: score,
        grade: grade,
        issues: issues,
        recommendations: recommendations,
        metrics: {
            workspaceSizeMB: parseFloat(sizeMB),
            contextUsagePercent: parseFloat(usagePercent.toFixed(1)),
            sessionStateExists: fs.existsSync(sessionStatePath),
            memoryDirsComplete: missingDirs.length === 0,
            todayEpisodicExists: fs.existsSync(todayEpisodic),
            reportsCount: fs.existsSync(reportsDir) ? fs.readdirSync(reportsDir).filter(f => f.endsWith('.md')).length : 0,
            apiKeysExist: fs.existsSync(apiKeysPath),
            scriptsMissing: missingScripts.length
        }
    };

    // 保存到记忆目录
    const healthDir = path.join(workspaceRoot, 'memory', 'health');
    if (!fs.existsSync(healthDir)) {
        fs.mkdirSync(healthDir, { recursive: true });
    }
    
    const resultFile = path.join(healthDir, `health_check_${today}.json`);
    fs.writeFileSync(resultFile, JSON.stringify(checkResult, null, 2), 'utf8');
    
    console.log(`\n📁 检查结果已保存: ${resultFile}`);
    
    // 更新SESSION-STATE.md
    updateSessionState(checkResult);

    return checkResult;
}

// 更新SESSION-STATE.md
function updateSessionState(checkResult) {
    const sessionStatePath = path.join(workspaceRoot, 'SESSION-STATE.md');
    
    if (!fs.existsSync(sessionStatePath)) {
        console.log("⚠️  SESSION-STATE.md不存在，跳过更新");
        return;
    }
    
    let content = fs.readFileSync(sessionStatePath, 'utf8');
    
    // 添加或更新健康检查部分
    const healthSection = `## 🏥 健康检查结果 (${new Date().toLocaleString('zh-CN')})
- **分数:** ${checkResult.score}/100 (${checkResult.grade})
- **问题数量:** ${checkResult.issues.length}
- **建议数量:** ${checkResult.recommendations.length}
- **工作区大小:** ${checkResult.metrics.workspaceSizeMB} MB
- **上下文使用率:** ${checkResult.metrics.contextUsagePercent}%

### 发现的问题
${checkResult.issues.map((issue, idx) => `${idx + 1}. ${issue}`).join('\n') || '无'}

### 改进建议
${checkResult.recommendations.map((rec, idx) => `${idx + 1}. ${rec}`).join('\n') || '无'}`;

    // 替换或添加健康检查部分
    const regex = /## 🏥 健康检查结果[\s\S]*?(?=##|$)/;
    if (regex.test(content)) {
        content = content.replace(regex, healthSection);
    } else {
        // 在文件末尾添加
        content += '\n\n' + healthSection;
    }
    
    fs.writeFileSync(sessionStatePath, content, 'utf8');
    console.log("✅ 健康检查结果已更新到SESSION-STATE.md");
}

// 运行健康检查
try {
    const result = calculateHealthScore();
    
    // 根据分数决定后续行动
    if (result.score < 60) {
        console.log("\n🚨 健康分数低于60分，建议立即处理问题！");
        console.log("建议操作:");
        console.log("1. 检查并修复发现的问题");
        console.log("2. 运行 memory_auditor.py（如果可用）");
        console.log("3. 考虑运行 cron_optimizer.py --fix");
    } else if (result.score < 80) {
        console.log("\n⚠️  健康分数中等，建议本周内处理问题");
    } else {
        console.log("\n✅ 健康状态良好，继续保持！");
    }
    
    // 记录到今日情景记忆
    const today = new Date().toISOString().split('T')[0];
    const todayEpisodic = path.join(workspaceRoot, 'memory', 'episodic', `${today}.md`);
    
    if (fs.existsSync(todayEpisodic)) {
        let content = fs.readFileSync(todayEpisodic, 'utf8');
        const time = new Date().toLocaleTimeString('zh-CN', { hour12: false });
        
        const healthEntry = `\n## ${time} - 健康检查
- 分数: ${result.score}/100 (${result.grade})
- 发现问题: ${result.issues.length} 个
- 改进建议: ${result.recommendations.length} 个
- 工作区大小: ${result.metrics.workspaceSizeMB} MB
- 上下文使用率: ${result.metrics.contextUsagePercent}%`;
        
        content += healthEntry;
        fs.writeFileSync(todayEpisodic, content, 'utf8');
        console.log("📝 健康检查已记录到今日情景记忆");
    }
    
} catch (error) {
    console.error("❌ 健康检查失败:", error.message);
    console.error(error.stack);
}

// 导出函数供其他脚本使用
module.exports = { calculateHealthScore, updateSessionState };