const https = require('https');
const fs = require('fs');
const path = require('path');
const { execSync } = require('child_process');

// 使用环境变量中的API密钥
const MX_APIKEY = process.env.MX_APIKEY || "mkt_fgN0XtXWjMxR9zxtDS9EkHx9pz6-OzfHl06C1ywGdls";

// 增强的选股策略（结合数据分析技能）
const enhancedStrategies = [
    {
        name: "技术分析增强策略",
        query: "A股主板 今日涨幅大于3% 成交量大于5000万 换手率大于2%",
        desc: "结合技术指标和成交量分析",
        analysisType: "technical"
    },
    {
        name: "基本面增强策略",
        query: "A股主板 市盈率小于30 市净率小于2.5 净资产收益率大于8%",
        desc: "价值投资与基本面分析结合",
        analysisType: "fundamental"
    },
    {
        name: "资金流向增强策略",
        query: "A股主板 今日主力资金净流入 成交量大于1亿",
        desc: "追踪机构资金动向",
        analysisType: "moneyflow"
    }
];

// 调用妙想选股API
function callMXStockScreener(query) {
    return new Promise((resolve, reject) => {
        const postData = JSON.stringify({
            keyword: query
        });

        const options = {
            hostname: 'mkapi2.dfcfs.com',
            port: 443,
            path: '/finskillshub/api/claw/stock-screen',
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'apikey': MX_APIKEY,
                'Content-Length': Buffer.byteLength(postData)
            }
        };

        const req = https.request(options, (res) => {
            let data = '';
            
            res.on('data', (chunk) => {
                data += chunk;
            });
            
            res.on('end', () => {
                try {
                    const result = JSON.parse(data);
                    resolve(result);
                } catch (e) {
                    reject(new Error(`JSON解析错误: ${e.message}`));
                }
            });
        });

        req.on('error', (e) => {
            reject(new Error(`请求错误: ${e.message}`));
        });

        req.write(postData);
        req.end();
    });
}

// 使用data-analyst技能进行数据清洗
function cleanStockData(stocks, columns) {
    console.log("🧹 开始数据清洗...");
    
    // 创建字段映射
    const fieldMap = {};
    columns.forEach(col => {
        if (col.key && col.title) {
            fieldMap[col.key] = {
                title: col.title,
                unit: col.unit || '',
                dataType: col.dataType
            };
        }
    });
    
    const cleanedStocks = [];
    let missingDataCount = 0;
    let invalidDataCount = 0;
    
    stocks.forEach((stock, index) => {
        const cleanedStock = {
            id: index + 1,
            code: stock.SECURITY_CODE || '',
            name: stock.SECURITY_SHORT_NAME || '',
            market: stock.MARKET_SHORT_NAME || '',
            serial: stock.SERIAL || ''
        };
        
        // 提取数值字段
        const numericFields = {};
        const textFields = {};
        
        for (const [key, value] of Object.entries(stock)) {
            if (key === 'SECURITY_CODE' || key === 'SECURITY_SHORT_NAME' || 
                key === 'MARKET_SHORT_NAME' || key === 'SERIAL') {
                continue;
            }
            
            // 数据清洗：处理缺失值
            if (value === null || value === undefined || value === '') {
                missingDataCount++;
                continue;
            }
            
            const strValue = String(value);
            
            // 识别字段类型并清洗
            if (fieldMap[key]) {
                const fieldInfo = fieldMap[key];
                
                // 数值字段清洗
                if (fieldInfo.dataType === 'Double' || fieldInfo.dataType === 'Long' || 
                    key.includes('PRICE') || key.includes('CHG') || key.includes('RATE')) {
                    
                    const numValue = parseFloat(strValue);
                    if (isNaN(numValue)) {
                        invalidDataCount++;
                        continue;
                    }
                    
                    // 识别字段类别
                    if (key.includes('CHG') || key.includes('涨跌幅')) {
                        numericFields['涨跌幅'] = { value: numValue, unit: '%', rawKey: key };
                    } else if (key.includes('NEWEST_PRICE') || key.includes('最新价')) {
                        numericFields['最新价'] = { value: numValue, unit: '元', rawKey: key };
                    } else if (key.includes('TURNOVER_RATE') || key.includes('换手率')) {
                        numericFields['换手率'] = { value: numValue, unit: '%', rawKey: key };
                    } else if (key.includes('PE_') || key.includes('市盈率')) {
                        numericFields['市盈率'] = { value: numValue, unit: '倍', rawKey: key };
                    } else if (key.includes('VOLUME') || key.includes('成交量')) {
                        // 处理带单位的成交量（如"1543.40万"）
                        let volumeValue = numValue;
                        if (strValue.includes('万')) {
                            volumeValue = numValue * 10000;
                        } else if (strValue.includes('亿')) {
                            volumeValue = numValue * 100000000;
                        }
                        numericFields['成交量'] = { value: volumeValue, unit: '股', rawKey: key };
                    } else if (key.includes('MARKET_VALUE') || key.includes('市值')) {
                        let marketValue = numValue;
                        if (strValue.includes('亿')) {
                            marketValue = numValue * 100000000;
                        }
                        numericFields['市值'] = { value: marketValue, unit: '元', rawKey: key };
                    }
                } else {
                    // 文本字段
                    textFields[fieldInfo.title] = strValue;
                }
            }
        }
        
        cleanedStock.numericFields = numericFields;
        cleanedStock.textFields = textFields;
        cleanedStocks.push(cleanedStock);
    });
    
    console.log(`✅ 数据清洗完成:`);
    console.log(`   - 处理股票: ${cleanedStocks.length} 只`);
    console.log(`   - 缺失数据: ${missingDataCount} 处`);
    console.log(`   - 无效数据: ${invalidDataCount} 处`);
    
    return cleanedStocks;
}

// 使用data-analyst-cn技能进行统计分析
function performStatisticalAnalysis(stocks) {
    console.log("\n📊 开始统计分析...");
    
    if (stocks.length === 0) {
        console.log("⚠️  无数据可分析");
        return null;
    }
    
    // 提取所有数值字段
    const allNumericFields = {};
    stocks.forEach(stock => {
        Object.entries(stock.numericFields).forEach(([fieldName, fieldData]) => {
            if (!allNumericFields[fieldName]) {
                allNumericFields[fieldName] = [];
            }
            allNumericFields[fieldName].push(fieldData.value);
        });
    });
    
    // 计算统计指标
    const statistics = {};
    
    Object.entries(allNumericFields).forEach(([fieldName, values]) => {
        if (values.length === 0) return;
        
        const sortedValues = [...values].sort((a, b) => a - b);
        const n = sortedValues.length;
        
        // 基本统计
        const sum = sortedValues.reduce((a, b) => a + b, 0);
        const mean = sum / n;
        
        // 方差和标准差
        const variance = sortedValues.reduce((a, b) => a + Math.pow(b - mean, 2), 0) / n;
        const stdDev = Math.sqrt(variance);
        
        // 分位数
        const q1 = sortedValues[Math.floor(n * 0.25)];
        const median = sortedValues[Math.floor(n * 0.5)];
        const q3 = sortedValues[Math.floor(n * 0.75)];
        
        // 偏度和峰度
        const skewness = n > 2 ? sortedValues.reduce((a, b) => a + Math.pow((b - mean) / stdDev, 3), 0) / n : 0;
        const kurtosis = n > 3 ? sortedValues.reduce((a, b) => a + Math.pow((b - mean) / stdDev, 4), 0) / n - 3 : 0;
        
        statistics[fieldName] = {
            count: n,
            mean: parseFloat(mean.toFixed(4)),
            median: parseFloat(median.toFixed(4)),
            stdDev: parseFloat(stdDev.toFixed(4)),
            min: sortedValues[0],
            max: sortedValues[n - 1],
            q1: q1,
            q3: q3,
            iqr: parseFloat((q3 - q1).toFixed(4)),
            skewness: parseFloat(skewness.toFixed(4)),
            kurtosis: parseFloat(kurtosis.toFixed(4)),
            // 识别异常值（基于IQR）
            outliers: sortedValues.filter(v => v < q1 - 1.5 * (q3 - q1) || v > q3 + 1.5 * (q3 - q1)).length
        };
    });
    
    // 相关性分析（如果有多维数据）
    const correlationMatrix = {};
    const fieldNames = Object.keys(allNumericFields);
    
    for (let i = 0; i < fieldNames.length; i++) {
        for (let j = i; j < fieldNames.length; j++) {
            const field1 = fieldNames[i];
            const field2 = fieldNames[j];
            
            if (field1 === field2) {
                if (!correlationMatrix[field1]) correlationMatrix[field1] = {};
                correlationMatrix[field1][field2] = 1.0;
                continue;
            }
            
            const values1 = allNumericFields[field1];
            const values2 = allNumericFields[field2];
            
            // 确保两个字段有相同数量的数据点
            const minLength = Math.min(values1.length, values2.length);
            if (minLength < 2) continue;
            
            const sliced1 = values1.slice(0, minLength);
            const sliced2 = values2.slice(0, minLength);
            
            // 计算皮尔逊相关系数
            const mean1 = sliced1.reduce((a, b) => a + b, 0) / minLength;
            const mean2 = sliced2.reduce((a, b) => a + b, 0) / minLength;
            
            let numerator = 0;
            let denom1 = 0;
            let denom2 = 0;
            
            for (let k = 0; k < minLength; k++) {
                const diff1 = sliced1[k] - mean1;
                const diff2 = sliced2[k] - mean2;
                numerator += diff1 * diff2;
                denom1 += diff1 * diff1;
                denom2 += diff2 * diff2;
            }
            
            const correlation = denom1 === 0 || denom2 === 0 ? 0 : 
                numerator / Math.sqrt(denom1 * denom2);
            
            if (!correlationMatrix[field1]) correlationMatrix[field1] = {};
            if (!correlationMatrix[field2]) correlationMatrix[field2] = {};
            
            correlationMatrix[field1][field2] = parseFloat(correlation.toFixed(4));
            correlationMatrix[field2][field1] = parseFloat(correlation.toFixed(4));
        }
    }
    
    console.log("✅ 统计分析完成");
    
    return {
        statistics,
        correlationMatrix,
        fieldNames,
        totalStocks: stocks.length
    };
}

// 使用gi-summarize技能生成分析摘要
function generateAnalysisSummary(stocks, analysisResults, strategy) {
    console.log("\n📝 生成分析摘要...");
    
    let summary = `# ${strategy.name} 分析摘要\n`;
    summary += `## 策略描述\n${strategy.desc}\n\n`;
    summary += `## 数据概览\n`;
    summary += `- 分析股票数量: ${stocks.length} 只\n`;
    summary += `- 分析时间: ${new Date().toLocaleString('zh-CN')}\n`;
    summary += `- 查询条件: ${strategy.query}\n\n`;
    
    if (analysisResults) {
        summary += `## 统计摘要\n`;
        
        // 对每个字段生成摘要
        Object.entries(analysisResults.statistics).forEach(([fieldName, stats]) => {
            summary += `### ${fieldName}\n`;
            summary += `- **范围**: ${stats.min.toLocaleString()} ~ ${stats.max.toLocaleString()}\n`;
            summary += `- **均值**: ${stats.mean.toLocaleString()}\n`;
            summary += `- **中位数**: ${stats.median.toLocaleString()}\n`;
            summary += `- **标准差**: ${stats.stdDev.toLocaleString()}\n`;
            
            if (stats.outliers > 0) {
                summary += `- **异常值**: ${stats.outliers} 个 (基于IQR方法)\n`;
            }
            
            // 分布特征
            if (Math.abs(stats.skewness) > 0.5) {
                summary += `- **分布特征**: ${stats.skewness > 0 ? '右偏' : '左偏'} (偏度: ${stats.skewness})\n`;
            }
            
            summary += `\n`;
        });
        
        // 相关性摘要
        if (Object.keys(analysisResults.correlationMatrix).length > 1) {
            summary += `## 关键相关性\n`;
            
            const strongCorrelations = [];
            Object.entries(analysisResults.correlationMatrix).forEach(([field1, correlations]) => {
                Object.entries(correlations).forEach(([field2, corr]) => {
                    if (field1 !== field2 && Math.abs(corr) > 0.7) {
                        strongCorrelations.push({
                            field1, field2, corr,
                            strength: Math.abs(corr) > 0.9 ? '极强' : 
                                     Math.abs(corr) > 0.7 ? '强' : '中等'
                        });
                    }
                });
            });
            
            if (strongCorrelations.length > 0) {
                strongCorrelations.forEach(corr => {
                    const direction = corr.corr > 0 ? '正相关' : '负相关';
                    summary += `- **${corr.field1}** 与 **${corr.field2}** ${direction} (${corr.strength}, r=${corr.corr.toFixed(3)})\n`;
                });
            } else {
                summary += `- 未发现强相关性 (|r| > 0.7)\n`;
            }
            summary += `\n`;
        }
    }
    
    // 股票表现摘要
    if (stocks.length > 0) {
        summary += `## 股票表现摘要\n`;
        
        // 按涨跌幅排序
        const sortedByChange = [...stocks].sort((a, b) => {
            const changeA = a.numericFields['涨跌幅']?.value || 0;
            const changeB = b.numericFields['涨跌幅']?.value || 0;
            return changeB - changeA;
        });
        
        // 表现最佳
        if (sortedByChange.length >= 3) {
            summary += `### 涨幅前三\n`;
            sortedByChange.slice(0, 3).forEach((stock, idx) => {
                const change = stock.numericFields['涨跌幅']?.value || 0;
                const price = stock.numericFields['最新价']?.value || 0;
                summary += `${idx + 1}. **${stock.name}** (${stock.code}.${stock.market}): ${change.toFixed(2)}%, 价格: ${price.toFixed(2)}元\n`;
            });
            summary += `\n`;
        }
        
        // 风险提示
        const highRiskStocks = stocks.filter(stock => {
            const change = stock.numericFields['涨跌幅']?.value || 0;
            const turnover = stock.numericFields['换手率']?.value || 0;
            const pe = stock.numericFields['市盈率']?.value || 0;
            
            return change > 9.9 || turnover > 20 || pe > 100 || pe < 0;
        });
        
        if (highRiskStocks.length > 0) {
            summary += `### 风险提示\n