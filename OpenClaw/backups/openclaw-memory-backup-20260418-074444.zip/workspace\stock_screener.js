const https = require('https');
const fs = require('fs');
const path = require('path');

// 从环境变量获取API密钥
const MX_APIKEY = process.env.MX_APIKEY || "mkt_ie_8NFDcG8a9iGnRR9tLQlvE5I02HRbBQero8h80fh8";

// 选股条件
const query = "A股主板 今日涨幅大于2% 成交量大于1亿";

function callMXStockScreener(query) {
    return new Promise((resolve, reject) => {
        const postData = JSON.stringify({
            query: query,
            apikey: MX_APIKEY
        });

        const options = {
            hostname: 'mkapi2.dfcfs.com',
            port: 443,
            path: '/finskillshub/api/claw/stock-screen',
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'Content-Length': Buffer.byteLength(postData)
            }
        };

        const req = https.request(options, (res) => {
            let data = '';
            
            res.on('data', (chunk) => {
                data += chunk;
            });
            
            res.on('end', () => {
                try {
                    const result = JSON.parse(data);
                    resolve(result);
                } catch (e) {
                    reject(new Error(`JSON解析错误: ${e.message}`));
                }
            });
        });

        req.on('error', (e) => {
            reject(new Error(`请求错误: ${e.message}`));
        });

        req.write(postData);
        req.end();
    });
}

// 主函数
async function main() {
    console.log("开始A股主板短线选股研究...");
    console.log(`选股条件: ${query}`);
    console.log(`API密钥: ${MX_APIKEY.substring(0, 10)}...`);
    
    try {
        const result = await callMXStockScreener(query);
        
        // 创建输出目录
        const outputDir = path.join(process.env.HOME || process.env.USERPROFILE, '.openclaw', 'workspace', 'mx_data', 'output');
        if (!fs.existsSync(outputDir)) {
            fs.mkdirSync(outputDir, { recursive: true });
        }
        
        // 保存结果
        const timestamp = new Date().toISOString().replace(/[:.]/g, '-');
        const outputFile = path.join(outputDir, `stock_screener_${timestamp}.json`);
        
        fs.writeFileSync(outputFile, JSON.stringify(result, null, 2), 'utf8');
        console.log(`结果已保存到: ${outputFile}`);
        
        // 解析并显示关键信息
        if (result.status === 0 && result.data && result.data.code === 100) {
            const total = result.data.data.result?.total || 0;
            console.log(`\n筛选结果: 共 ${total} 只股票符合条件`);
            
            // 显示筛选条件
            if (result.data.data.responseConditionList) {
                console.log("\n筛选条件:");
                result.data.data.responseConditionList.forEach((cond, idx) => {
                    console.log(`  ${idx + 1}. ${cond.describe} (匹配: ${cond.stockCount}只)`);
                });
            }
            
            // 显示前10只股票
            if (result.data.data.result?.dataList && result.data.data.result.dataList.length > 0) {
                console.log("\n前10只符合条件的股票:");
                const stocks = result.data.data.result.dataList.slice(0, 10);
                
                stocks.forEach((stock, idx) => {
                    console.log(`  ${idx + 1}. ${stock.SECURITY_SHORT_NAME} (${stock.SECURITY_CODE}.${stock.MARKET_SHORT_NAME})`);
                    console.log(`     最新价: ${stock.NEWEST_PRICE}元, 涨跌幅: ${stock.CHG}%`);
                });
            }
        } else {
            console.log("API返回错误:", result.message || "未知错误");
            console.log("完整响应:", JSON.stringify(result, null, 2));
        }
        
    } catch (error) {
        console.error("选股失败:", error.message);
    }
}

// 运行
main();