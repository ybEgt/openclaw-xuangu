// 完整真实数据选股系统
console.log("🚀 完整真实数据选股系统 v1.0");
console.log("=".repeat(70));

const fs = require('fs');
const path = require('path');
const https = require('https');

// 系统配置
const SYSTEM_CONFIG = {
    api: {
        endpoint: "https://mkapi2.dfcfs.com/finskillshub/api/claw/stock-screen",
        apiKey: process.env.MX_APIKEY || "mkt_fgN0XtXWjMxR9zxtDS9EkHx9pz6-OzfHl06C1ywGdls",
        timeout: 20000
    },
    
    // 选股条件
    screening: {
        // 自然语言查询选项
        queries: [
            "A股主板今日上涨且成交量放大的股票",
            "上证主板涨幅大于5%的股票",
            "深证主板主力资金流入的股票",
            "60开头的股票今日上涨超过3%",
            "00开头的股票换手率大于1%"
        ],
        
        // 主板代码规则
        main_board_patterns: [
            /^60/,  // 上交所主板
            /^00/,  // 深交所主板（包括中小板）
            /^002/, // 深交所中小板
            /^000/  // 深交所主板
        ],
        
        // 排除规则
        exclude_patterns: [
            /^688/, // 科创板
            /^300/, // 创业板
            /^8/,   // 北交所
            /^900/  // B股
        ]
    },
    
    // 评分权重
    scoring_weights: {
        price_change: 0.30,    // 涨跌幅
        volume_ratio: 0.20,    // 量比
        turnover_rate: 0.15,   // 换手率
        market_cap: 0.10,      // 市值规模
        pe_ratio: 0.10,        // 市盈率
        pb_ratio: 0.10,        // 市净率
        capital_flow: 0.05     // 资金流向（模拟）
    }
};

// 1. API调用函数
async function callMxXuanguAPI(query) {
    return new Promise((resolve, reject) => {
        const postData = JSON.stringify({ keyword: query });
        
        const options = {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'apikey': SYSTEM_CONFIG.api.apiKey,
                'Content-Length': Buffer.byteLength(postData)
            },
            timeout: SYSTEM_CONFIG.api.timeout
        };
        
        console.log(`📤 发送API请求: "${query}"`);
        
        const req = https.request(SYSTEM_CONFIG.api.endpoint, options, (res) => {
            let data = '';
            res.on('data', (chunk) => {
                data += chunk;
            });
            
            res.on('end', () => {
                try {
                    const result = JSON.parse(data);
                    
                    if (res.statusCode === 200 && result.status === 0) {
                        console.log(`✅ API请求成功，收到数据`);
                        resolve(result);
                    } else {
                        console.error(`❌ API错误: ${result.message || '未知错误'}`);
                        reject(new Error(`API错误: ${result.message || '状态码 ' + res.statusCode}`));
                    }
                } catch (error) {
                    console.error(`❌ 响应解析失败: ${error.message}`);
                    reject(new Error(`响应解析失败: ${error.message}`));
                }
            });
        });
        
        req.on('error', reject);
        req.on('timeout', () => {
            req.destroy();
            reject(new Error('请求超时'));
        });
        
        req.write(postData);
        req.end();
    });
}

// 2. 数据提取函数
function extractStockData(apiResponse) {
    console.log("\n🔍 提取股票数据...");
    
    const stocks = [];
    
    try {
        // 从allResults获取数据
        const dataList = apiResponse.data?.data?.allResults?.result?.dataList;
        if (dataList && Array.isArray(dataList)) {
            console.log(`📊 从allResults获取 ${dataList.length} 条数据`);
            
            dataList.forEach((item, index) => {
                const stock = normalizeStockData(item, index + 1);
                if (stock.code) {
                    stocks.push(stock);
                }
            });
        }
        
        // 如果allResults没有数据，尝试partialResults
        if (stocks.length === 0) {
            const partialResults = apiResponse.data?.data?.partialResults;
            if (partialResults) {
                console.log(`📊 从partialResults解析数据`);
                const parsedStocks = parseMarkdownTable(partialResults);
                stocks.push(...parsedStocks);
            }
        }
        
    } catch (error) {
        console.error(`❌ 数据提取错误: ${error.message}`);
    }
    
    console.log(`✅ 成功提取 ${stocks.length} 只股票数据`);
    return stocks;
}

// 3. 数据标准化
function normalizeStockData(rawData, index) {
    const stock = {
        id: index,
        raw: rawData
    };
    
    // 提取关键字段（处理中文和英文字段名）
    const fieldMappings = {
        // 代码相关
        'code': ['代码', 'code', '证券代码', 'stock_code'],
        'name': ['名称', 'name', '证券名称', 'stock_name'],
        
        // 价格相关
        'price': ['最新价', 'price', '最新价(元)', 'close', 'last_price'],
        'change': ['涨跌幅', 'change', '涨跌幅(%)', 'pct_change'],
        'change_amount': ['涨跌额', 'change_amount', '涨跌额(元)'],
        'high': ['最高价', 'high', '最高价(元)'],
        'low': ['最低价', 'low', '最低价(元)'],
        
        // 成交量相关
        'volume': ['成交量', 'volume', '成交量(股)', 'turnover_volume'],
        'amount': ['成交额', 'amount', '成交额(元)', 'turnover_amount'],
        'turnover': ['换手率', 'turnover', '换手率(%)', 'turnover_rate'],
        'volume_ratio': ['量比', 'volume_ratio', '量比'],
        
        // 估值相关
        'pe': ['市盈率', 'pe', '市盈率(动)', 'pe_ratio'],
        'pb': ['市净率', 'pb', '市净率', 'pb_ratio'],
        'market_cap': ['总市值', 'market_cap', '总市值(元)', 'total_market_cap'],
        'circulating_market_cap': ['流通市值', 'circulating_market_cap', '流通市值(元)'],
        
        // 其他
        'sector': ['上市板块', 'sector', '板块', 'industry'],
        'type': ['证券类型', 'type', '类型']
    };
    
    // 遍历映射表提取字段
    Object.entries(fieldMappings).forEach(([targetField, sourceFields]) => {
        for (const sourceField of sourceFields) {
            if (rawData[sourceField] !== undefined) {
                stock[targetField] = rawData[sourceField];
                break;
            }
        }
    });
    
    // 特殊处理：确保代码是字符串且去除空格
    if (stock.code) {
        stock.code = stock.code.toString().trim();
    }
    
    // 数值转换
    ['price', 'change', 'volume', 'amount', 'turnover', 'pe', 'pb', 'market_cap'].forEach(field => {
        if (stock[field] !== undefined) {
            if (typeof stock[field] === 'string') {
                // 移除中文单位和逗号
                const cleaned = stock[field].replace(/[^\d.-]/g, '');
                const num = parseFloat(cleaned);
                if (!isNaN(num)) {
                    stock[field] = num;
                }
            }
        }
    });
    
    return stock;
}

// 4. 解析Markdown表格
function parseMarkdownTable(markdown) {
    const stocks = [];
    const lines = markdown.trim().split('\n');
    
    if (lines.length < 3) return stocks;
    
    // 解析表头
    const headers = lines[0].split('|').filter(h => h.trim()).map(h => h.trim());
    
    // 从第2行开始解析数据
    for (let i = 2; i < lines.length; i++) {
        const cells = lines[i].split('|').filter(c => c.trim()).map(c => c.trim());
        
        if (cells.length >= headers.length) {
            const stock = { id: i - 1 };
            
            headers.forEach((header, idx) => {
                if (idx < cells.length) {
                    stock[header] = cells[idx];
                }
            });
            
            // 标准化
            const normalized = normalizeStockData(stock, i - 1);
            if (normalized.code) {
                stocks.push(normalized);
            }
        }
    }
    
    return stocks;
}

// 5. 主板股票筛选
function filterMainBoardStocks(stocks) {
    return stocks.filter(stock => {
        if (!stock.code) return false;
        
        const code = stock.code.toString();
        
        // 检查排除规则
        for (const pattern of SYSTEM_CONFIG.screening.exclude_patterns) {
            if (pattern.test(code)) {
                return false;
            }
        }
        
        // 检查主板规则
        for (const pattern of SYSTEM_CONFIG.screening.main_board_patterns) {
            if (pattern.test(code)) {
                return true;
            }
        }
        
        return false;
    });
}

// 6. 股票评分系统
function scoreStocks(stocks) {
    return stocks.map(stock => {
        let score = 50; // 基础分
        
        const weights = SYSTEM_CONFIG.scoring_weights;
        
        // 1. 涨跌幅评分 (0-30分)
        if (stock.change > 0) {
            score += Math.min(30, stock.change * weights.price_change * 100);
        } else if (stock.change < 0) {
            score -= Math.min(15, Math.abs(stock.change) * weights.price_change * 50);
        }
        
        // 2. 量比评分 (0-20分)
        if (stock.volume_ratio > 1) {
            score += Math.min(20, (stock.volume_ratio - 1) * weights.volume_ratio * 100);
        }
        
        // 3. 换手率评分 (0-15分)
        if (stock.turnover > 0.5 && stock.turnover < 20) {
            score += Math.min(15, stock.turnover * weights.turnover_rate * 10);
        }
        
        // 4. 市值评分 (0-10分)
        if (stock.market_cap) {
            const capInBillions = stock.market_cap / 1000000000;
            if (capInBillions > 10 && capInBillions < 500) {
                score += 10 * weights.market_cap;
            }
        }
        
        // 5. 市盈率评分 (0-10分)
        if (stock.pe > 0 && stock.pe < 30) {
            score += 10 * weights.pe_ratio;
        } else if (stock.pe > 50) {
            score -= 5 * weights.pe_ratio;
        }
        
        // 6. 市净率评分 (0-10分)
        if (stock.pb > 0 && stock.pb < 3) {
            score += 10 * weights.pb_ratio;
        }
        
        // 7. 模拟资金流向评分 (0-5分)
        const flowScore = Math.random() * 5;
        score += flowScore * weights.capital_flow;
        
        // 确保分数在0-100之间
        stock.score = Math.max(0, Math.min(100, Math.round(score)));
        
        // 评分等级
        if (stock.score >= 80) stock.grade = 'A';
        else if (stock.score >= 70) stock.grade = 'B';
        else if (stock.score >= 60) stock.grade = 'C';
        else if (stock.score >= 50) stock.grade = 'D';
        else stock.grade = 'E';
        
        return stock;
    });
}

// 7. 生成标准输出
function generateStandardOutput(topStocks) {
    const now = new Date();
    
    return topStocks.map((stock, index) => {
        return {
            时间: now.toLocaleString('zh-CN'),
            股票名称: stock.name || `股票${index + 1}`,
            股票代码: stock.code || '000000',
            最新价格: stock.price ? `${stock.price.toFixed(2)}元` : 'N/A',
            推荐指数: `${stock.score}分(等级${stock.grade})`,
            推荐逻辑: generateRecommendationLogic(stock),
            预期收益: generateExpectedReturn(stock),
            建议持仓天数: generateHoldingDays(stock),
            压力位分析: generatePressureLevels(stock),
            操作建议: generateOperationAdvice(stock, index + 1)
        };
    });
}

// 生成推荐逻辑
function generateRecommendationLogic(stock) {
    const factors = [];
    
    if (stock.change > 5) factors.push(`大涨${stock.change.toFixed(1)}%`);
    if (stock.volume_ratio > 2) factors.push(`量比${stock.volume_ratio.toFixed(1)}倍`);
    if (stock.turnover > 2) factors.push(`换手率${stock.turnover.toFixed(1)}%`);
    if (stock.pe && stock.pe < 20) factors.push(`低市盈率${stock.pe.toFixed(1)}倍`);
    
    if (factors.length > 0) {
        return `技术面表现良好，${factors.join('，')}，具备上涨潜力`;
    }
    
    return `综合评分${stock.score}分，技术指标向好，建议关注`;
}

// 生成预期收益
function generateExpectedReturn(stock) {
    if (stock.score >= 80) return "8%-15%";
    if (stock.score >= 70) return "5%-12%";
    if (stock.score >= 60) return "3%-8%";
    return "0%-5%";
}

// 生成持仓天数
function generateHoldingDays(stock) {
    if (stock.score >= 80) return "3-7天";
    if (stock.score >= 70) return "5-10天";
    if (stock.score >= 60) return "7-14天";
    return "10-20天";
}

// 生成压力位分析
function generatePressureLevels(stock) {
    if (!stock.price) return "N/A";
    
    const price = stock.price;
    const levels = [
        (price * 1.05).toFixed(2),
        (price * 1.10).toFixed(2),
        (price * 1.15).toFixed(2)
    ];
    
    return `${levels[0]}元 / ${levels[1]}元 / ${levels[2]}元`;
}

// 生成操作建议
function generateOperationAdvice(stock, rank) {
    const baseAdvice = `评分${stock.score}分，等级${stock.grade}`;
    
    if (rank === 1) {
        return `${baseAdvice}，重点关注，可在当前价格附近分批买入，止损-5%`;
    } else if (rank === 2) {
        return `${baseAdvice}，适度关注，等待回调至支撑位介入，止损-6%`;
    } else {
        return `${baseAdvice}，观察为主，确认突破后再考虑介入，止损-7%`;
    }
}

// 8. 保存结果
function saveResults(stocks, output, query, allStocks) {
    const timestamp = new Date().toISOString().replace(/[:.]/g, '-');
    const resultsDir = path.join(__dirname, 'complete_results');
    
    if (!fs.existsSync(resultsDir)) {
        fs.mkdirSync(resultsDir, { recursive: true });
    }
    
    // 保存完整数据
    const completeFile = path.join(resultsDir, `complete_${timestamp}.json`);
    fs.writeFileSync(completeFile, JSON.stringify({
        metadata: {
            timestamp: new Date().toISOString(),
            query: query,
            total_stocks: allStocks.length,
            main_board_stocks: stocks.length,
            screening_time: new Date().toLocaleString('zh-CN')
        },
        all_stocks: allStocks,
        main_board_stocks: stocks,
        top_10_stocks: stocks.slice(0, 10),
        standard_output: output
    }, null, 2), 'utf8');
    
    // 保存标准输出
    const outputFile = path.join(resultsDir, `output_${timestamp}.json`);
    fs.writeFileSync(outputFile, JSON.stringify({
        timestamp: new Date().toISOString(),
        standard_output: output
    }, null, 2), 'utf8');
    
    // 保存文本报告
    const reportFile = path.join(resultsDir, `report_${timestamp}.txt`);
    const report = generateTextReport(output, stocks.length, allStocks.length);
    fs.writeFileSync(reportFile, report, 'utf8');
    
    console.log(`\n💾 结果已保存:`);
    console.log(`   完整数据: ${completeFile}`);
    console.log(`   标准输出: ${outputFile}`);
    console.log