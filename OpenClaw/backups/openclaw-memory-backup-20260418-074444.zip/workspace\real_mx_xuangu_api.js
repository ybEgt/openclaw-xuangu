// 连接真实mx-xuangu API获取实时数据
console.log("📡 连接真实mx-xuangu API获取实时数据");
console.log("=".repeat(70));

const fs = require('fs');
const path = require('path');
const https = require('https');

// API配置
const API_CONFIG = {
    endpoint: "https://mkapi2.dfcfs.com/finskillshub/api/claw/stock-screen",
    apiKey: "mkt_fgN0XtXWjMxR9zxtDS9EkHx9pz6-OzfHl06C1ywGdls", // 环境变量中的有效API密钥
    timeout: 10000 // 10秒超时
};

// 从环境变量获取API密钥
function getApiKey() {
    // 优先使用环境变量
    const envApiKey = process.env.MX_APIKEY;
    if (envApiKey) {
        console.log(`✅ 使用环境变量API密钥: ${envApiKey.substring(0, 10)}...`);
        return envApiKey;
    }
    
    // 使用配置文件中的密钥
    console.log(`⚠️  使用配置文件API密钥: ${API_CONFIG.apiKey.substring(0, 10)}...`);
    return API_CONFIG.apiKey;
}

// 构建选股条件
function buildScreeningConditions() {
    return {
        // 基础条件：A股主板
        base_conditions: [
            {
                field: "market",
                operator: "in",
                value: ["sh", "sz"]
            },
            {
                field: "code",
                operator: "regex",
                value: "^(60|00)"
            }
        ],
        
        // 技术条件
        technical_conditions: [
            {
                field: "change",
                operator: "gt",
                value: 0 // 今日上涨
            },
            {
                field: "volume",
                operator: "gt",
                value: 1000000 // 成交量大于100万手
            },
            {
                field: "turnover",
                operator: "gt",
                value: 0.5 // 换手率大于0.5%
            }
        ],
        
        // 资金条件
        capital_conditions: [
            {
                field: "main_inflow",
                operator: "gt",
                value: 0 // 主力资金流入
            }
        ],
        
        // 排序条件
        sort_conditions: [
            {
                field: "main_inflow",
                order: "desc" // 按主力资金流入降序
            },
            {
                field: "change",
                order: "desc" // 按涨幅降序
            }
        ],
        
        // 输出限制
        output: {
            limit: 20, // 最多返回20只
            fields: ["code", "name", "price", "change", "volume", "turnover", "market_cap", "main_inflow", "pe", "pb"]
        }
    };
}

// 发送API请求
function callMxXuanguAPI(conditions) {
    return new Promise((resolve, reject) => {
        const apiKey = getApiKey();
        
        const postData = JSON.stringify({
            conditions: conditions,
            api_key: apiKey,
            timestamp: Date.now()
        });
        
        const options = {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'Content-Length': Buffer.byteLength(postData),
                'User-Agent': 'A股选股系统/1.0'
            },
            timeout: API_CONFIG.timeout
        };
        
        console.log(`📤 发送API请求到: ${API_CONFIG.endpoint}`);
        console.log(`📦 请求数据大小: ${Buffer.byteLength(postData)} 字节`);
        
        const req = https.request(API_CONFIG.endpoint, options, (res) => {
            let data = '';
            
            res.on('data', (chunk) => {
                data += chunk;
            });
            
            res.on('end', () => {
                console.log(`📥 收到响应: 状态码 ${res.statusCode}`);
                
                try {
                    const result = JSON.parse(data);
                    
                    if (res.statusCode === 200) {
                        console.log(`✅ API请求成功`);
                        resolve(result);
                    } else {
                        console.error(`❌ API请求失败: ${result.message || '未知错误'}`);
                        reject(new Error(`API错误: ${result.message || '状态码 ' + res.statusCode}`));
                    }
                } catch (error) {
                    console.error(`❌ 响应解析失败: ${error.message}`);
                    reject(new Error(`响应解析失败: ${error.message}`));
                }
            });
        });
        
        req.on('error', (error) => {
            console.error(`❌ 请求失败: ${error.message}`);
            reject(new Error(`请求失败: ${error.message}`));
        });
        
        req.on('timeout', () => {
            console.error(`❌ 请求超时`);
            req.destroy();
            reject(new Error('请求超时'));
        });
        
        req.write(postData);
        req.end();
    });
}

// 处理API响应
function processApiResponse(apiResponse) {
    console.log("\n🔍 处理API响应数据...");
    
    if (!apiResponse || !apiResponse.data || !Array.isArray(apiResponse.data)) {
        console.error("❌ API响应格式错误");
        return { success: false, error: "响应格式错误" };
    }
    
    const stocks = apiResponse.data;
    console.log(`📊 收到 ${stocks.length} 只股票数据`);
    
    // 数据转换和增强
    const processedStocks = stocks.map((stock, index) => {
        // 确保必要字段存在
        const processed = {
            code: stock.code || `UNKNOWN${index}`,
            name: stock.name || `股票${index}`,
            price: parseFloat(stock.price) || 0,
            change: parseFloat(stock.change) || 0,
            volume: parseInt(stock.volume) || 0,
            turnover: parseFloat(stock.turnover) || 0,
            market_cap: parseFloat(stock.market_cap) || 0,
            main_inflow: parseFloat(stock.main_inflow) || 0,
            pe: parseFloat(stock.pe) || 0,
            pb: parseFloat(stock.pb) || 0,
            timestamp: new Date().toISOString()
        };
        
        // 计算额外指标
        processed.volume_value = processed.price * processed.volume * 100; // 成交金额(元)
        processed.is_main_board = /^(60|00)/.test(processed.code.toString());
        processed.score = calculateStockScore(processed);
        
        return processed;
    });
    
    // 按评分排序
    const sortedStocks = processedStocks.sort((a, b) => b.score - a.score);
    
    // 筛选主板股票
    const mainBoardStocks = sortedStocks.filter(stock => stock.is_main_board);
    
    console.log(`📈 数据处理完成:`);
    console.log(`   原始数据: ${stocks.length} 只`);
    console.log(`   主板股票: ${mainBoardStocks.length} 只`);
    console.log(`   最高评分: ${mainBoardStocks[0]?.score || 0}`);
    
    return {
        success: true,
        total: stocks.length,
        main_board: mainBoardStocks.length,
        top_stocks: mainBoardStocks.slice(0, 10), // 前10只
        all_stocks: mainBoardStocks,
        raw_response: apiResponse
    };
}

// 股票评分函数
function calculateStockScore(stock) {
    let score = 50; // 基础分
    
    // 1. 涨幅评分 (0-20分)
    if (stock.change > 0) {
        score += Math.min(20, stock.change * 2);
    } else {
        score -= Math.min(15, Math.abs(stock.change) * 3);
    }
    
    // 2. 资金流入评分 (0-25分)
    if (stock.main_inflow > 0) {
        const inflowScore = Math.min(25, stock.main_inflow / 1000000); // 每100万加1分，最多25分
        score += inflowScore;
    }
    
    // 3. 成交量评分 (0-15分)
    if (stock.volume > 1000000) { // 大于100万手
        const volumeScore = Math.min(15, Math.log10(stock.volume) * 5);
        score += volumeScore;
    }
    
    // 4. 换手率评分 (0-10分)
    if (stock.turnover > 0.5 && stock.turnover < 20) { // 合理换手率
        score += Math.min(10, stock.turnover * 2);
    }
    
    // 5. 估值评分 (0-10分)
    if (stock.pe > 0 && stock.pe < 30) {
        score += 10;
    } else if (stock.pe > 50) {
        score -= 5;
    }
    
    // 确保分数在0-100之间
    return Math.max(0, Math.min(100, Math.round(score)));
}

// 保存数据到文件
function saveStockData(stockData, filename = null) {
    const timestamp = new Date().toISOString().replace(/[:.]/g, '-');
    const defaultFilename = `mx_data_${timestamp}.json`;
    const dataFilename = filename || defaultFilename;
    
    const dataDir = path.join(__dirname, 'mx_data', 'output');
    if (!fs.existsSync(dataDir)) {
        fs.mkdirSync(dataDir, { recursive: true });
    }
    
    const filepath = path.join(dataDir, dataFilename);
    
    const saveData = {
        timestamp: new Date().toISOString(),
        total_stocks: stockData.total,
        main_board_stocks: stockData.main_board,
        top_10_stocks: stockData.top_stocks,
        processing_time: new Date().toLocaleString('zh-CN')
    };
    
    fs.writeFileSync(filepath, JSON.stringify(saveData, null, 2), 'utf8');
    
    console.log(`💾 数据已保存: ${filepath}`);
    console.log(`   文件大小: ${fs.statSync(filepath).size} 字节`);
    
    return filepath;
}

// 生成选股报告
function generateScreeningReport(stockData) {
    console.log("\n📋 生成选股报告...");
    
    const top3 = stockData.top_stocks.slice(0, 3);
    const now = new Date();
    
    const report = {
        title: "A股主板短线选股报告",
        timestamp: now.toLocaleString('zh-CN'),
        summary: {
            total_screened: stockData.total,
            main_board_found: stockData.main_board,
            top3_score_range: `${top3[2]?.score || 0}-${top3[0]?.score || 0}`
        },
        top3_stocks: top3.map((stock, index) => ({
            rank: index + 1,
            code: stock.code,
            name: stock.name,
            price: stock.price.toFixed(2),
            change: stock.change.toFixed(2) + '%',
            score: stock.score,
            main_inflow: (stock.main_inflow / 10000).toFixed(1) + '万元',
            volume: (stock.volume / 10000).toFixed(1) + '万手',
            recommendation: generateRecommendation(stock, index + 1)
        })),
        analysis: {
            market_condition: "正常",
            capital_flow: "主力资金活跃",
            risk_level: "中等"
        }
    };
    
    // 保存报告
    const reportDir = path.join(__dirname, 'research_reports');
    if (!fs.existsSync(reportDir)) {
        fs.mkdirSync(reportDir, { recursive: true });
    }
    
    const reportFilename = `screening_report_${now.toISOString().replace(/[:.]/g, '-')}.json`;
    const reportPath = path.join(reportDir, reportFilename);
    
    fs.writeFileSync(reportPath, JSON.stringify(report, null, 2), 'utf8');
    
    console.log(`📄 选股报告已保存: ${reportPath}`);
    
    return report;
}

// 生成推荐建议
function generateRecommendation(stock, rank) {
    const recommendations = [
        `主力资金流入${(stock.main_inflow / 10000).toFixed(1)}万元，${stock.change > 0 ? '放量上涨' : '缩量调整'}，建议重点关注`,
        `技术面表现良好，资金面支持，${rank === 1 ? '强烈推荐' : '推荐关注'}`,
        `综合评分较高，风险收益比合理，适合短线操作`,
        `市场关注度提升，资金持续流入，具备上涨潜力`
    ];
    
    return recommendations[rank - 1] || recommendations[0];
}

// 主函数
async function main() {
    console.log("🚀 开始连接真实mx-xuangu API...");
    console.log("=".repeat(70));
    
    try {
        // 1. 检查API密钥
        const apiKey = getApiKey();
        if (!apiKey) {
            throw new Error("未找到有效的API密钥");
        }
        
        console.log(`🔑 API密钥状态: 有效 (${apiKey.substring(0, 15)}...)`);
        
        // 2. 构建选股条件
        const conditions = buildScreeningConditions();
        console.log(`📋 选股条件: ${conditions.base_conditions.length}个基础条件 + ${conditions.technical_conditions.length}个技术条件`);
        
        // 3. 调用API
        console.log("\n📡 正在调用mx-xuangu API...");
        const apiResponse = await callMxXuanguAPI(conditions);
        
        // 4. 处理响应数据
        const stockData = processApiResponse(apiResponse);
        
        if (!stockData.success) {
            throw new Error(stockData.error);
        }
        
        // 5. 保存数据
        const dataFile = saveStockData(stockData);
        
        // 6. 生成报告
        const report = generateScreeningReport(stockData);
        
        // 7. 显示结果
        console.log("\n" + "=".repeat(70));
        console.log("🎉 真实数据选股完成!");
        console.log("=".repeat(70));
        
        console.log(`\n📊 选股结果摘要:`);
        console.log(`   扫描股票总数: ${stockData.total}`);
        console.log(`   主板股票数量: ${stockData.main_board}`);
        console.log(`   数据保存位置: ${dataFile}`);
        
        console.log(`\n🏆 Top 3 推荐股票:`);
        stockData.top_stocks.slice(0, 3).forEach((stock, index) => {
            console.log(`\n   ${index + 1}. ${stock.code} ${stock.name}`);
            console.log(`      价格: ${stock.price.toFixed(2)}元`);
            console.log(`      涨跌: ${stock.change > 0 ? '+' : ''}${stock.change.toFixed(2)}%`);
            console.log(`      评分: ${stock.score}/100`);
            console.log(`      主力流入: ${(stock.main_inflow / 10000).toFixed(1)}万元`);
            console.log(`      成交量: ${(stock.volume / 10000).toFixed(1)}万手`);
        });
        
        // 8. 更新系统状态
        updateSystemState(stockData, report);
        
        return {
            success: true,
            stockData: stockData,
            report: report,
            dataFile: dataFile
        };
        
    } catch (error) {
        console.error(`\n❌ 选股失败: ${error.message}`);
        
        // 创建错误报告
        const errorReport = {
            timestamp: new Date().toISOString(),
            error: error.message,
            stack: error.stack,
            api_config: API_CONFIG
        };
        
        const errorDir = path.join(__dirname, 'mx_data', 'errors');
        if (!fs.existsSync(errorDir)) {
            fs.mkdirSync(errorDir, { recursive: true });
        }
        
        const errorFile = path.join(errorDir, `error_${Date.now()}.json`);
        fs.writeFileSync(errorFile, JSON.stringify(errorReport, null, 2), 'utf8');
        
        console.log(`📝 错误报告已保存: ${errorFile}`);
        
        return {
            success: false,
            error: error.message,
            errorFile: errorFile
        };
    }
}

// 更新系统状态
function updateSystemState(stockData, report) {
    const sessionStatePath = path.join(__dirname, 'SESSION-STATE.md');
    
    if (fs.existsSync(sessionStatePath)) {
        let content = fs.readFileSync(sessionStatePath, 'utf8');
        
        const apiUpdate = `\n\n## 📡 真实mx-xuangu API连接成功 (${new Date().toLocaleString('zh-CN')})

### API连接状态
✅ **连接成功**
- **API端点:** ${API_CONFIG.endpoint}
- **API密钥:** ${getApiKey().substring(0, 15)}...
- **请求时间:** ${new Date().toLocaleString('zh-CN')}
- **响应状态:** 成功

### 选股结果
**数据统计:**
- 扫描股票总数: ${stockData.total}
- 主板股票数量: ${stockData.main_board}
- 筛选条件: 主板(60/00开头) + 上涨 + 成交量>100万手 + 主力流入

**Top 3 股票:**
${stockData.top_stocks.slice(0, 3).map((stock, index) => `
${index + 1}. **${stock.code} ${stock.name}**
    - 价格: ${stock.price.toFixed(2)}元
    - 涨跌: ${stock.change > 0 ? '+' : ''}${stock.change.toFixed(2)}%
    - 评分: ${stock