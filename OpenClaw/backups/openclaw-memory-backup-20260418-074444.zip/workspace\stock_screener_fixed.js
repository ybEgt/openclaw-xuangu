const https = require('https');
const fs = require('fs');
const path = require('path');

// 使用环境变量中的API密钥
const MX_APIKEY = process.env.MX_APIKEY || "mkt_fgN0XtXWjMxR9zxtDS9EkHx9pz6-OzfHl06C1ywGdls";

// 选股条件 - 简化查询
const query = "今日涨幅大于2%";

function callMXStockScreener(query) {
    return new Promise((resolve, reject) => {
        const postData = JSON.stringify({
            keyword: query
        });

        const options = {
            hostname: 'mkapi2.dfcfs.com',
            port: 443,
            path: '/finskillshub/api/claw/stock-screen',
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'apikey': MX_APIKEY,
                'Content-Length': Buffer.byteLength(postData)
            }
        };

        console.log("发送请求到:", options.hostname + options.path);
        console.log("API密钥:", MX_APIKEY.substring(0, 15) + "...");

        const req = https.request(options, (res) => {
            console.log("状态码:", res.statusCode);
            console.log("响应头:", res.headers);
            
            let data = '';
            
            res.on('data', (chunk) => {
                data += chunk;
            });
            
            res.on('end', () => {
                console.log("收到响应长度:", data.length);
                try {
                    const result = JSON.parse(data);
                    resolve(result);
                } catch (e) {
                    console.error("原始响应:", data.substring(0, 500));
                    reject(new Error(`JSON解析错误: ${e.message}`));
                }
            });
        });

        req.on('error', (e) => {
            reject(new Error(`请求错误: ${e.message}`));
        });

        req.write(postData);
        req.end();
    });
}

// 主函数
async function main() {
    console.log("开始A股主板短线选股研究...");
    console.log(`选股条件: ${query}`);
    
    try {
        const result = await callMXStockScreener(query);
        
        // 创建输出目录
        const outputDir = path.join(process.env.HOME || process.env.USERPROFILE, '.openclaw', 'workspace', 'mx_data', 'output');
        if (!fs.existsSync(outputDir)) {
            fs.mkdirSync(outputDir, { recursive: true });
        }
        
        // 保存结果
        const timestamp = new Date().toISOString().replace(/[:.]/g, '-');
        const outputFile = path.join(outputDir, `stock_screener_${timestamp}.json`);
        
        fs.writeFileSync(outputFile, JSON.stringify(result, null, 2), 'utf8');
        console.log(`\n结果已保存到: ${outputFile}`);
        
        // 解析并显示关键信息
        if (result.status === 0 && result.data && result.data.code === 100) {
            const total = result.data.data?.result?.total || 0;
            console.log(`\n筛选结果: 共 ${total} 只股票符合条件`);
            
            // 显示筛选条件
            if (result.data.data?.responseConditionList) {
                console.log("\n筛选条件:");
                result.data.data.responseConditionList.forEach((cond, idx) => {
                    console.log(`  ${idx + 1}. ${cond.describe} (匹配: ${cond.stockCount}只)`);
                });
            }
            
            // 显示前10只股票
            const dataList = result.data.data?.result?.dataList || [];
            if (dataList.length > 0) {
                console.log(`\n前${Math.min(10, dataList.length)}只符合条件的股票:`);
                const stocks = dataList.slice(0, 10);
                
                stocks.forEach((stock, idx) => {
                    console.log(`  ${idx + 1}. ${stock.SECURITY_SHORT_NAME || stock.SECURITY_CODE} (${stock.SECURITY_CODE}.${stock.MARKET_SHORT_NAME || 'SH'})`);
                    console.log(`     最新价: ${stock.NEWEST_PRICE || 'N/A'}元, 涨跌幅: ${stock.CHG || 'N/A'}%`);
                });
            }
        } else {
            console.log("\nAPI返回错误:");
            console.log("状态码:", result.status);
            console.log("消息:", result.message);
            console.log("代码:", result.code);
        }
        
    } catch (error) {
        console.error("\n选股失败:", error.message);
    }
}

// 运行
main();