// 严格约束的A股主板短线选股系统
const fs = require('fs');
const path = require('path');

console.log("🎯 严格约束A股主板短线选股系统");
console.log("=".repeat(70));

// 选股约束配置
const STOCK_CONSTRAINTS = {
    // 市场范围
    market: {
        allowed: ["A股"],
        excluded: ["港股", "美股", "B股", "其他市场"]
    },
    
    // 板块范围 (仅主板)
    board: {
        allowed: ["主板"],
        code_patterns: {
            shanghai: /^60\d{4}$/,    // 沪市主板: 60xxxx
            shenzhen: /^00\d{4}$/     // 深市主板: 00xxxx
        },
        excluded: {
            star_market: /^688\d{3}$/,  // 科创板: 688xxx
            gem: /^300\d{3}$/,          // 创业板: 300xxx
            beijing: /^8\d{5}$/,        // 北交所: 8xxxxx
            others: /^(002|003|200|900|730|780|580|150|159|510|511|512|513|515|518|588|1599)\d+/ // 其他排除
        }
    },
    
    // 强制剔除规则
    exclusion_rules: {
        st_stocks: {
            patterns: [
                /ST/,           // ST股票
                /\*ST/,         // *ST股票
                /S\s*T/,        // S T (带空格)
                /退市/,          // 退市股票
                /风险警示/       // 风险警示
            ],
            action: "强制排除"
        },
        
        suspended: {
            conditions: [
                "停牌",
                "暂停上市",
                "终止上市",
                "退市整理"
            ],
            action: "强制排除"
        },
        
        abnormal_data: {
            indicators: {
                price_change: { min: -20, max: 20 },      // 涨跌幅限制
                turnover_rate: { max: 50 },               // 换手率上限
                pe_ratio: { min: 0, max: 500 },           // 市盈率范围
                pb_ratio: { min: 0, max: 20 },            // 市净率范围
                market_cap: { min: 100000000 }            // 市值下限1亿
            },
            action: "标记并排除"
        }
    },
    
    // 主力资金分析框架
    main_force_analysis: {
        // 1. 寻找主力资金在哪里
        capital_flow_indicators: [
            "主力净流入",
            "超大单净流入",
            "大单净流入",
            "中单净流入",
            "小单净流入",
            "资金流向强度",
            "资金集中度"
        ],
        
        // 2. 识别主力真实意图
        intention_patterns: {
            "一日游": {
                characteristics: ["早盘急拉", "尾盘回落", "成交量脉冲"],
                detection: "短期资金快进快出"
            },
            "骗炮": {
                characteristics: ["假突破", "量价背离", "技术指标诱多"],
                detection: "制造假象吸引跟风盘"
            },
            "建仓": {
                characteristics: ["温和放量", "价格震荡", "筹码集中"],
                detection: "长期资金逐步买入"
            },
            "准备拉升": {
                characteristics: ["缩量整理", "突破前高", "均线多头"],
                detection: "蓄势待发阶段"
            },
            "已经拉升": {
                characteristics: ["连续放量", "快速上涨", "技术指标强势"],
                detection: "主力正在拉升"
            }
        },
        
        // 3. 综合维度分析
        comprehensive_dimensions: {
            "暗盘行为": ["大宗交易", "盘后交易", "机构席位"],
            "资金流": ["主力流向", "散户流向", "北向资金"],
            "量价结构": ["量价配合", "成交量分布", "价格形态"],
            "技术指标": ["MACD", "KDJ", "RSI", "BOLL", "均线系统"],
            "综合行情": ["板块轮动", "市场情绪", "政策影响"],
            "情绪题材": ["热点概念", "消息面", "市场关注度"]
        }
    },
    
    // 评分体系
    scoring_system: {
        weights: {
            capital_flow: 0.25,      // 资金流权重
            intention_confidence: 0.20, // 意图置信度
            technical_indicators: 0.20, // 技术指标
            market_sentiment: 0.15,    // 市场情绪
            risk_adjustment: 0.10,     // 风险调整
            consistency: 0.10          // 一致性
        },
        
        thresholds: {
            minimum_score: 60,        // 最低入选分数
            risk_cutoff: 40,          // 风险 cutoff
            confidence_threshold: 0.7  // 置信度阈值
        }
    },
    
    // 邮件同步配置
    email_sync: {
        enabled: true,
        recipient: "zhangyuru999@qq.com",
        triggers: [
            "manual_screening",      // 手动筛选结果
            "scheduled_task",        // 定时任务结果
            "risk_alert",            // 风险预警
            "opportunity_discovery"  // 机会发现
        ],
        formats: ["text", "html"],
        priority: "high"
    }
};

// 显示约束配置
function displayConstraints() {
    console.log("\n📋 选股约束配置:");
    console.log("=".repeat(70));
    
    console.log("\n1. 市场范围:");
    console.log(`   允许: ${STOCK_CONSTRAINTS.market.allowed.join(', ')}`);
    console.log(`   排除: ${STOCK_CONSTRAINTS.market.excluded.join(', ')}`);
    
    console.log("\n2. 板块范围 (仅主板):");
    console.log(`   沪市主板: 60xxxx`);
    console.log(`   深市主板: 00xxxx`);
    console.log(`   明确排除:`);
    console.log(`     - 科创板: 688xxx`);
    console.log(`     - 创业板: 300xxx`);
    console.log(`     - 北交所: 8xxxxx`);
    console.log(`     - B股、可转债、ETF等`);
    
    console.log("\n3. 强制剔除规则:");
    console.log(`   ST/*ST: 代码或名称触发ST规则的一律排除`);
    console.log(`   停牌标的: 交易状态非正常的排除`);
    console.log(`   异常数据: 明显异常数据的排除`);
    
    console.log("\n4. 邮件同步:");
    console.log(`   收件人: ${STOCK_CONSTRAINTS.email_sync.recipient}`);
    console.log(`   触发条件: ${STOCK_CONSTRAINTS.email_sync.triggers.join(', ')}`);
    console.log(`   优先级: ${STOCK_CONSTRAINTS.email_sync.priority}`);
}

// 股票代码验证函数
function validateStockCode(code, name = "") {
    const constraints = STOCK_CONSTRAINTS;
    
    // 检查代码格式
    if (!code || typeof code !== 'string') {
        return { valid: false, reason: "代码格式错误" };
    }
    
    // 1. 检查是否为主板代码
    const isShanghaiMain = constraints.board.code_patterns.shanghai.test(code);
    const isShenzhenMain = constraints.board.code_patterns.shenzhen.test(code);
    
    if (!isShanghaiMain && !isShenzhenMain) {
        // 检查是否为排除的代码
        for (const [type, pattern] of Object.entries(constraints.board.excluded)) {
            if (pattern.test(code)) {
                return { 
                    valid: false, 
                    reason: `代码属于排除类型: ${type}`,
                    details: `代码 ${code} 匹配排除模式 ${pattern}`
                };
            }
        }
        return { valid: false, reason: "非主板代码" };
    }
    
    // 2. 检查ST/*ST规则
    if (name) {
        for (const pattern of constraints.exclusion_rules.st_stocks.patterns) {
            if (pattern.test(name)) {
                return { 
                    valid: false, 
                    reason: "触发ST规则",
                    details: `名称 "${name}" 匹配ST模式 ${pattern}`
                };
            }
        }
    }
    
    // 3. 检查代码本身是否包含ST (如600***ST)
    if (/ST/i.test(code)) {
        return { valid: false, reason: "代码包含ST标识" };
    }
    
    return { 
        valid: true, 
        market: isShanghaiMain ? "沪市主板" : "深市主板",
        code: code,
        name: name || "未知"
    };
}

// 主力资金分析函数
function analyzeMainForce(stockData) {
    console.log("\n💰 主力资金分析:");
    console.log("=".repeat(70));
    
    const analysis = {
        capital_location: null,
        intention: null,
        confidence: 0,
        dimensions: {},
        score: 0
    };
    
    // 1. 寻找主力资金在哪里
    const capitalIndicators = STOCK_CONSTRAINTS.main_force_analysis.capital_flow_indicators;
    const capitalData = {};
    
    capitalIndicators.forEach(indicator => {
        if (stockData[indicator] !== undefined) {
            capitalData[indicator] = stockData[indicator];
        }
    });
    
    if (Object.keys(capitalData).length > 0) {
        analysis.capital_location = "检测到主力资金活动";
        console.log(`   🔍 资金流向:`);
        Object.entries(capitalData).forEach(([key, value]) => {
            console.log(`      ${key}: ${value}`);
        });
    } else {
        analysis.capital_location = "资金流向数据不足";
        console.log(`   ⚠️  资金流向数据不足`);
    }
    
    // 2. 识别主力真实意图
    const intentionPatterns = STOCK_CONSTRAINTS.main_force_analysis.intention_patterns;
    let detectedIntentions = [];
    
    Object.entries(intentionPatterns).forEach(([intention, pattern]) => {
        // 简化的意图检测逻辑
        const matchScore = Math.random() * 100; // 实际应基于数据分析
        if (matchScore > 50) {
            detectedIntentions.push({
                intention,
                score: matchScore,
                characteristics: pattern.characteristics
            });
        }
    });
    
    if (detectedIntentions.length > 0) {
        // 选择置信度最高的意图
        detectedIntentions.sort((a, b) => b.score - a.score);
        analysis.intention = detectedIntentions[0].intention;
        analysis.confidence = detectedIntentions[0].score;
        
        console.log(`   🎯 主力意图: ${analysis.intention} (置信度: ${analysis.confidence.toFixed(1)}%)`);
        console.log(`      特征: ${detectedIntentions[0].characteristics.join(', ')}`);
    } else {
        analysis.intention = "意图不明";
        console.log(`   ❓ 主力意图: 不明`);
    }
    
    // 3. 综合维度分析
    const dimensions = STOCK_CONSTRAINTS.main_force_analysis.comprehensive_dimensions;
    analysis.dimensions = {};
    
    console.log(`   📊 综合维度分析:`);
    Object.entries(dimensions).forEach(([dimension, indicators]) => {
        const dimensionScore = Math.random() * 100;
        analysis.dimensions[dimension] = {
            indicators: indicators,
            score: dimensionScore,
            status: dimensionScore > 60 ? "良好" : dimensionScore > 40 ? "一般" : "较差"
        };
        
        console.log(`      ${dimension}: ${analysis.dimensions[dimension].status} (${dimensionScore.toFixed(1)}%)`);
    });
    
    // 4. 综合打分
    analysis.score = calculateComprehensiveScore(analysis);
    
    console.log(`   📈 综合评分: ${analysis.score.toFixed(1)}/100`);
    
    return analysis;
}

// 综合评分计算
function calculateComprehensiveScore(analysis) {
    const weights = STOCK_CONSTRAINTS.scoring_system.weights;
    
    let score = 0;
    
    // 资金流评分 (基于检测到的资金活动)
    const capitalFlowScore = analysis.capital_location === "检测到主力资金活动" ? 80 : 40;
    score += capitalFlowScore * weights.capital_flow;
    
    // 意图置信度评分
    score += analysis.confidence * weights.intention_confidence;
    
    // 技术指标评分 (取各维度平均)
    const dimensionScores = Object.values(analysis.dimensions).map(d => d.score);
    const avgDimensionScore = dimensionScores.length > 0 ? 
        dimensionScores.reduce((a, b) => a + b) / dimensionScores.length : 50;
    score += avgDimensionScore * weights.technical_indicators;
    
    // 市场情绪评分 (模拟)
    const sentimentScore = 70; // 实际应从市场数据获取
    score += sentimentScore * weights.market_sentiment;
    
    // 风险调整 (基于意图类型)
    const riskAdjustment = {
        "一日游": -20,
        "骗炮": -30,
        "建仓": 10,
        "准备拉升": 20,
        "已经拉升": 15,
        "意图不明": -10
    };
    const riskScore = riskAdjustment[analysis.intention] || 0;
    score += riskScore * weights.risk_adjustment;
    
    // 一致性评分 (各维度一致性)
    const consistencyScore = calculateConsistency(analysis.dimensions);
    score += consistencyScore * weights.consistency;
    
    // 确保分数在合理范围内
    return Math.max(0, Math.min(100, score));
}

// 计算一致性评分
function calculateConsistency(dimensions) {
    if (Object.keys(dimensions).length === 0) return 50;
    
    const scores = Object.values(dimensions).map(d => d.score);
    const avgScore = scores.reduce((a, b) => a + b) / scores.length;
    
    // 计算方差 (一致性)
    const variance = scores.reduce((sum, score) => sum + Math.pow(score - avgScore, 2), 0) / scores.length;
    
    // 方差越小，一致性越高
    const consistency = 100 - (variance / 100);
    return Math.max(0, Math.min(100, consistency));
}

// 测试股票验证
function testStockValidation() {
    console.log("\n🧪 股票代码验证测试:");
    console.log("=".repeat(70));
    
    const testCases = [
        { code: "600519", name: "贵州茅台" },
        { code: "000858", name: "五粮液" },
        { code: "688981", name: "中芯国际" },
        { code: "300750", name: "宁德时代" },
        { code: "000725", name: "京东方A" },
        { code: "600***ST", name: "ST测试股" },
        { code: "000001", name: "平安银行" },
        { code: "830000", name: "北交所测试" },
        { code: "900901", name: "B股测试" },
        { code: "123456", name: "无效代码" }
    ];
    
    testCases.forEach(testCase => {
        const result = validateStockCode(testCase.code, testCase