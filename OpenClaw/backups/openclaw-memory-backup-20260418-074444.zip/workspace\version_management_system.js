// 版本管理和归档系统 v1.0
const fs = require('fs');
const path = require('path');

console.log("🏷️ 版本管理和归档系统 v1.0");
console.log("=".repeat(70));

// 系统配置
const SYSTEM_CONFIG = {
    // 版本管理
    versioning: {
        major_increment: "策略架构重大改变",
        minor_increment: "因子权重显著优化", 
        patch_increment: "参数微调或bug修复",
        archive_threshold: 0.05 // 性能提升5%以上才归档新版本
    },
    
    // 归档目录结构
    archive_structure: {
        root: "strategy_archive",
        subdirs: [
            "v1_0_0", "v1_1_0", "v2_0_0", // 版本目录
            "evolution_logs",              // 进化日志
            "performance_reports",         // 性能报告
            "key_conclusions"              // 关键结论
        ]
    },
    
    // 稳定策略标准
    stability_criteria: {
        min_backtest_days: 20,     // 最少回测天数
        min_hit_rate: 0.4,         // 最低命中率40%
        max_hit_rate_std: 0.15,    // 命中率标准差<15%
        min_improvement: 0.02      // 相比前一版本至少提升2%
    }
};

// 当前策略状态
let currentStrategy = {
    version: "1.0.0",
    weights: {
        capital: 0.35,
        trend: 0.25,
        volume: 0.20,
        sentiment: 0.10,
        technical: 0.10
    },
    performance: {
        backtest_days: 20,
        avg_hit_rate: 0.333,
        hit_rate_std: 0.0,
        improvement: 0.0
    },
    created: new Date().toISOString(),
    status: "active"
};

// 创建归档目录
function createArchiveStructure() {
    const archiveRoot = path.join(__dirname, SYSTEM_CONFIG.archive_structure.root);
    
    if (!fs.existsSync(archiveRoot)) {
        fs.mkdirSync(archiveRoot, { recursive: true });
        console.log(`✅ 创建归档根目录: ${archiveRoot}`);
    }
    
    // 创建子目录
    SYSTEM_CONFIG.archive_structure.subdirs.forEach(subdir => {
        const dirPath = path.join(archiveRoot, subdir);
        if (!fs.existsSync(dirPath)) {
            fs.mkdirSync(dirPath, { recursive: true });
            console.log(`  📁 创建子目录: ${subdir}`);
        }
    });
    
    return archiveRoot;
}

// 评估策略稳定性
function evaluateStrategyStability(strategy) {
    const criteria = SYSTEM_CONFIG.stability_criteria;
    const evaluation = {
        meets_criteria: true,
        failed_criteria: [],
        stability_score: 0
    };
    
    // 检查回测天数
    if (strategy.performance.backtest_days < criteria.min_backtest_days) {
        evaluation.meets_criteria = false;
        evaluation.failed_criteria.push(`回测天数不足: ${strategy.performance.backtest_days}/${criteria.min_backtest_days}`);
    }
    
    // 检查命中率
    if (strategy.performance.avg_hit_rate < criteria.min_hit_rate) {
        evaluation.meets_criteria = false;
        evaluation.failed_criteria.push(`命中率过低: ${(strategy.performance.avg_hit_rate*100).toFixed(1)}%/${criteria.min_hit_rate*100}%`);
    }
    
    // 检查命中率稳定性
    if (strategy.performance.hit_rate_std > criteria.max_hit_rate_std) {
        evaluation.meets_criteria = false;
        evaluation.failed_criteria.push(`命中率波动过大: ${strategy.performance.hit_rate_std.toFixed(3)}/${criteria.max_hit_rate_std}`);
    }
    
    // 计算稳定性分数 (0-100)
    let score = 0;
    score += Math.min(40, (strategy.performance.avg_hit_rate / criteria.min_hit_rate) * 40);
    score += Math.min(30, (criteria.min_backtest_days / Math.max(1, strategy.performance.backtest_days)) * 30);
    score += Math.min(30, (1 - Math.min(1, strategy.performance.hit_rate_std / criteria.max_hit_rate_std)) * 30);
    
    evaluation.stability_score = Math.round(score);
    
    return evaluation;
}

// 比较两个版本
function compareVersions(oldVersion, newVersion) {
    const comparison = {
        improved: false,
        improvements: [],
        regressions: [],
        overall_change: 0
    };
    
    // 比较命中率
    const hitRateChange = newVersion.performance.avg_hit_rate - oldVersion.performance.avg_hit_rate;
    if (hitRateChange > SYSTEM_CONFIG.versioning.archive_threshold) {
        comparison.improved = true;
        comparison.improvements.push(`命中率提升: +${(hitRateChange*100).toFixed(1)}%`);
    } else if (hitRateChange < -SYSTEM_CONFIG.versioning.archive_threshold) {
        comparison.regressions.push(`命中率下降: ${(hitRateChange*100).toFixed(1)}%`);
    }
    
    // 比较权重变化
    for (const factor in newVersion.weights) {
        if (oldVersion.weights[factor]) {
            const change = newVersion.weights[factor] - oldVersion.weights[factor];
            if (Math.abs(change) > 0.1) {
                comparison.improvements.push(`${factor}权重变化: ${change > 0 ? '+' : ''}${(change*100).toFixed(1)}%`);
            }
        }
    }
    
    // 计算总体变化
    comparison.overall_change = hitRateChange * 100; // 转换为百分比
    
    return comparison;
}

// 决定版本号
function determineVersionNumber(oldVersion, comparison) {
    let major = 1, minor = 0, patch = 0;
    
    if (oldVersion) {
        const [oldMajor, oldMinor, oldPatch] = oldVersion.version.split('.').map(Number);
        major = oldMajor;
        minor = oldMinor;
        patch = oldPatch;
        
        if (comparison.improvements.some(imp => imp.includes("架构"))) {
            major += 1;
            minor = 0;
            patch = 0;
        } else if (comparison.overall_change > 10) { // 提升超过10%
            minor += 1;
            patch = 0;
        } else if (comparison.overall_change > 2 || comparison.improvements.length > 0) {
            patch += 1;
        }
    }
    
    return `${major}.${minor}.${patch}`;
}

// 归档策略版本
function archiveStrategyVersion(strategy, comparison, stabilityEvaluation) {
    const archiveRoot = createArchiveStructure();
    const versionDir = path.join(archiveRoot, `v${strategy.version.replace(/\./g, '_')}`);
    
    if (!fs.existsSync(versionDir)) {
        fs.mkdirSync(versionDir, { recursive: true });
    }
    
    // 保存策略文件
    const strategyFile = path.join(versionDir, 'strategy.json');
    fs.writeFileSync(strategyFile, JSON.stringify(strategy, null, 2), 'utf8');
    
    // 保存评估报告
    const evaluationFile = path.join(versionDir, 'evaluation.json');
    const evaluationReport = {
        archived_at: new Date().toISOString(),
        strategy_version: strategy.version,
        stability_evaluation: stabilityEvaluation,
        version_comparison: comparison,
        archive_reason: stabilityEvaluation.meets_criteria ? "达到稳定标准" : "重要更新"
    };
    fs.writeFileSync(evaluationFile, JSON.stringify(evaluationReport, null, 2), 'utf8');
    
    // 保存关键结论
    const conclusionsFile = path.join(versionDir, 'conclusions.md');
    const conclusions = generateKeyConclusions(strategy, comparison, stabilityEvaluation);
    fs.writeFileSync(conclusionsFile, conclusions, 'utf8');
    
    console.log(`✅ 策略版本 v${strategy.version} 已归档`);
    console.log(`  位置: ${versionDir}`);
    console.log(`  稳定性分数: ${stabilityEvaluation.stability_score}/100`);
    console.log(`  改进项: ${comparison.improvements.length}个`);
    
    return versionDir;
}

// 生成关键结论
function generateKeyConclusions(strategy, comparison, stabilityEvaluation) {
    const now = new Date();
    const dateStr = now.toISOString().split('T')[0];
    
    return `# 策略版本 v${strategy.version} - 关键结论

## 归档信息
- **归档时间:** ${now.toLocaleString('zh-CN')}
- **策略版本:** v${strategy.version}
- **状态:** ${strategy.status}

## 性能指标
- **回测天数:** ${strategy.performance.backtest_days}天
- **平均命中率:** ${(strategy.performance.avg_hit_rate * 100).toFixed(1)}%
- **命中率标准差:** ${strategy.performance.hit_rate_std.toFixed(3)}
- **相比前一版本:** ${comparison.overall_change > 0 ? '+' : ''}${comparison.overall_change.toFixed(1)}%

## 因子权重配置
${Object.entries(strategy.weights).map(([factor, weight]) => 
`- **${factor}:** ${weight.toFixed(3)} (${(weight*100).toFixed(1)}%)`
).join('\n')}

## 稳定性评估
- **稳定性分数:** ${stabilityEvaluation.stability_score}/100
- **符合稳定标准:** ${stabilityEvaluation.meets_criteria ? '✅ 是' : '❌ 否'}
${stabilityEvaluation.failed_criteria.length > 0 ? `
### 未达标项
${stabilityEvaluation.failed_criteria.map(c => `- ${c}`).join('\n')}
` : ''}

## 版本改进
${comparison.improvements.length > 0 ? `
### 改进项
${comparison.improvements.map(imp => `- ${imp}`).join('\n')}
` : '无显著改进'}

${comparison.regressions.length > 0 ? `
### 退步项
${comparison.regressions.map(reg => `- ${reg}`).join('\n')}
` : ''}

## 关键发现
1. **有效因子:** ${Object.entries(strategy.weights)
    .sort((a, b) => b[1] - a[1])
    .slice(0, 2)
    .map(([f]) => f)
    .join('、')} 权重最高，对选股贡献最大

2. **稳定性:** ${stabilityEvaluation.stability_score >= 70 ? '策略表现相对稳定' : '策略波动较大，需继续优化'}

3. **进化方向:** ${comparison.overall_change > 0 ? '持续正向进化中' : '需要调整进化策略'}

## 使用建议
${generateUsageRecommendations(strategy, stabilityEvaluation)}

## 后续优化方向
1. ${comparison.overall_change <= 0 ? '重新评估因子权重配置' : '继续当前进化方向'}
2. ${stabilityEvaluation.stability_score < 70 ? '增加回测数据量，提高稳定性' : '探索新的有效因子'}
3. 集成更多市场数据源
4. 优化反推进化算法参数

---
*归档于 ${dateStr}*
*系统: A股主板短线选股系统*`;
}

// 生成使用建议
function generateUsageRecommendations(strategy, stabilityEvaluation) {
    const recommendations = [];
    
    if (stabilityEvaluation.stability_score >= 80) {
        recommendations.push("✅ **推荐在生产环境使用** - 策略稳定，表现可靠");
    } else if (stabilityEvaluation.stability_score >= 60) {
        recommendations.push("⚠️ **可在模拟环境测试** - 策略基本稳定，建议进一步验证");
    } else {
        recommendations.push("❌ **仅用于研究分析** - 策略波动较大，不建议实际使用");
    }
    
    if (strategy.performance.avg_hit_rate >= 0.5) {
        recommendations.push("🎯 **高命中率策略** - 适合追求稳定收益");
    } else if (strategy.performance.avg_hit_rate >= 0.4) {
        recommendations.push("📊 **中等命中率策略** - 平衡收益和风险");
    } else {
        recommendations.push("🔍 **需优化策略** - 命中率有待提升");
    }
    
    // 根据权重给出建议
    const topFactor = Object.entries(strategy.weights)
        .sort((a, b) => b[1] - a[1])[0];
    
    recommendations.push(`📈 **重点关注${topFactor[0]}因子** - 权重${(topFactor[1]*100).toFixed(1)}%，对选股影响最大`);
    
    return recommendations.join('\n\n');
}

// 加载历史版本
function loadHistoricalVersions() {
    const archiveRoot = path.join(__dirname, SYSTEM_CONFIG.archive_structure.root);
    const versions = [];
    
    if (fs.existsSync(archiveRoot)) {
        const items = fs.readdirSync(archiveRoot);
        
        items.forEach(item => {
            if (item.startsWith('v') && item.includes('_')) {
                const versionStr = item.replace(/_/g, '.');
                const strategyFile = path.join(archiveRoot, item, 'strategy.json');
                
                if (fs.existsSync(strategyFile)) {
                    try {
                        const strategy = JSON.parse(fs.readFileSync(strategyFile, 'utf8'));
                        versions.push({
                            version: versionStr,
                            strategy: strategy,
                            path: path.join(archiveRoot, item)
                        });
                    } catch (e) {
                        console.log(`⚠️  无法加载版本 ${versionStr}: ${e.message}`);
                    }
                }
            }
        });
        
        // 按版本号排序
        versions.sort((a, b) => {
            const aParts = a.version.split('.').map(Number);
            const bParts = b.version.split('.').map(Number);
            
            for (let i = 0; i < 3; i++) {
                if (aParts[i] !== bParts[i]) {
                    return bParts[i] - aParts[i]; // 降序
                }
            }
            return 0;
        });
    }
    
    return versions;
}

// 主函数：管理策略版本
function manageStrategyVersions(newStrategyData) {
    console.log("🏷️ 策略版本管理流程");
    console.log("=".repeat(70));
    
    // 加载历史版本
    const historicalVersions = loadHistoricalVersions();
    console.log(`📚 找到 ${historicalVersions.length} 个历史版本`);
    
    // 获取最新版本
    const latestVersion = historicalVersions.length > 0 ? historicalVersions[0] : null;
    
    if (latestVersion) {
        console.log(`📊 最新版本: v${latestVersion.strategy.version}`);
        console.log(`   命中率: ${(latestVersion.strategy.performance.avg_hit_rate * 100).toFixed(1)}%`);
    }
    
    // 评估新策略
    console.log("\n🔍 评估新策略...");
    const stabilityEvaluation = evaluateStrategyStability(newStrategyData);
    
    console.log(`📈 稳定性分数: ${stabilityEvaluation.stability_score}/100`);
    console.log(`✅ 符合稳定标准: ${stabilityEvaluation.meets_criteria ? '是' : '否'}`);
    
    if (stabilityEvaluation.failed_criteria.length > 0) {
        console.log(`⚠️  未达标项:`);
        stabilityEvaluation.failed_criteria.forEach(criteria => {
            console.log(`   - ${criteria}`);
        });
    }
    
    // 与前一版本比较
    let versionComparison = { improved: false, improvements: [], regressions: [], overall_change: 0 };
    
    if (latestVersion) {
        versionComparison = compareVersions(latestVersion.strategy, newStrategyData);
        console.log(`\n🔄 版本比较:`);
        console.log(`   总体变化: ${versionComparison.overall_change > 0 ? '+' : ''}${versionComparison.overall_change.toFixed(1)}%`);
        console.log(`   改进项数: ${versionComparison.improvements.length}`);
        console.log(`   退步项数: ${versionComparison.regressions.length}`);
    }
    
    // 决定是否归档
    const shouldArchive = stabilityEvaluation.meets_criteria || 
                         versionComparison.improved ||
                         versionComparison.overall_change > SYSTEM_CONFIG.versioning.archive_threshold * 100;
    
    if (shouldArchive) {
        // 确定版本号
        const newVersion = determineVersionNumber(latestVersion?.strategy, versionComparison);
        newStrategyData.version = newVersion;
        newStrategyData.updated = new Date().toISOString();
        
        console.log(`\n🎯 确定新版本号: v${newVersion}`);
        
        // 归档新版本
        const archivePath = archiveStrategyVersion(newStrategyData, versionComparison, stabilityEvaluation);
        
        // 更新当前策略
        currentStrategy = newStrategyData;
        
        console.log(`\n✅ 新策略已归档为 v${newVersion}`);
        console.log(`   归档路径: ${archivePath}`);
        
        return {
            action: "archived",
            new_version: newVersion,
            archive_path: archivePath,
            evaluation: stabilityEvaluation,
            comparison: versionComparison
        };
    } else {
        console.log("\n⏸️  策略未达到归档标准，跳过归档");
        console.log(`   原因: ${!stabilityEvaluation.meets_criteria ? '未达到稳定标准'