// 反推进化机制系统 v1.0
console.log("🔄 反推进化机制系统 v1.0");
console.log("=".repeat(70));

// 进化配置
const EVOLUTION_CONFIG = {
    // 进化目标
    objectives: {
        win_rate: { target: "尽可能最大", weight: 0.4 },
        return: { target: "尽可能最大", weight: 0.4 },
        drawdown: { target: "尽可能最小", weight: 0.2 }
    },
    
    // 回测参数
    backtest: {
        lookback_days: 30,      // 回看30个交易日
        validation_window: 1,   // 用下一交易日验证
        top_n: 3,               // 输出Top3
        min_hits: 1             // 至少命中1只
    },
    
    // 因子权重初始配置
    factor_weights: {
        capital_flow: 0.35,     // 资金流因子
        price_trend: 0.25,      // 价格趋势因子
        volume_momentum: 0.20,  // 成交量动量因子
        market_sentiment: 0.10, // 市场情绪因子
        technical_indicator: 0.10 // 技术指标因子
    },
    
    // 进化参数
    evolution: {
        learning_rate: 0.1,     // 学习率
        max_iterations: 100,    // 最大迭代次数
        convergence_threshold: 0.01, // 收敛阈值
        penalty_factor: 0.2     // 失败因子惩罚系数
    }
};

// 模拟历史数据 (30个交易日)
function generateHistoricalData() {
    console.log("📊 生成30个交易日历史数据...");
    
    const stocks = [
        { code: "600519", name: "贵州茅台", sector: "白酒" },
        { code: "000858", name: "五粮液", sector: "白酒" },
        { code: "000002", name: "万科A", sector: "房地产" },
        { code: "000001", name: "平安银行", sector: "银行" },
        { code: "600036", name: "招商银行", sector: "银行" },
        { code: "000333", name: "美的集团", sector: "家电" },
        { code: "600276", name: "恒瑞医药", sector: "医药" },
        { code: "600887", name: "伊利股份", sector: "食品饮料" },
        { code: "000651", name: "格力电器", sector: "家电" },
        { code: "600030", name: "中信证券", sector: "券商" }
    ];
    
    const days = 30;
    const historicalData = [];
    
    for (let day = 0; day < days; day++) {
        const date = new Date();
        date.setDate(date.getDate() - day);
        const dateStr = date.toISOString().split('T')[0];
        
        const dayData = {
            date: dateStr,
            stocks: stocks.map(stock => {
                // 模拟每日数据
                const change = (Math.random() * 10 - 5).toFixed(2); // -5% 到 +5%
                const turnover = (Math.random() * 5).toFixed(2);    // 0-5%换手率
                const volume = Math.floor(Math.random() * 20000000) + 1000000;
                const capitalFlow = Math.floor(Math.random() * 20000) - 5000; // -5000到+15000万
                
                return {
                    ...stock,
                    price: 100 + Math.random() * 100, // 模拟价格
                    change: parseFloat(change),
                    turnover: parseFloat(turnover),
                    volume: volume,
                    capital_flow: capitalFlow,
                    // 因子值
                    factors: {
                        capital_flow: Math.max(0, capitalFlow / 10000), // 标准化
                        price_trend: Math.random(), // 价格趋势
                        volume_momentum: Math.random(), // 成交量动量
                        market_sentiment: Math.random(), // 市场情绪
                        technical_indicator: Math.random() // 技术指标
                    }
                };
            })
        };
        
        historicalData.push(dayData);
    }
    
    console.log(`✅ 生成 ${historicalData.length} 个交易日数据，共 ${stocks.length} 只股票`);
    return historicalData;
}

// 计算综合得分
function calculateScore(stock, weights) {
    let score = 0;
    const factors = stock.factors;
    
    // 加权求和
    for (const [factor, weight] of Object.entries(weights)) {
        if (factors[factor] !== undefined) {
            score += factors[factor] * weight * 100; // 放大到0-100分
        }
    }
    
    // 添加随机噪声（模拟其他因素）
    score += Math.random() * 10 - 5;
    
    return Math.max(0, Math.min(100, Math.round(score)));
}

// 选股策略（输出Top3）
function selectTopStocks(dayData, weights) {
    const scoredStocks = dayData.stocks.map(stock => ({
        ...stock,
        score: calculateScore(stock, weights)
    }));
    
    // 按分数排序，取Top3
    return scoredStocks
        .sort((a, b) => b.score - a.score)
        .slice(0, EVOLUTION_CONFIG.backtest.top_n);
}

// 验证命中情况
function validateHits(predictedTop3, nextDayData) {
    const predictedCodes = predictedTop3.map(s => s.code);
    const nextDayStocks = nextDayData.stocks;
    
    // 计算下一交易日的真实Top3（按涨幅）
    const nextDayTop3 = [...nextDayStocks]
        .sort((a, b) => b.change - a.change)
        .slice(0, EVOLUTION_CONFIG.backtest.top_n);
    
    const nextDayTop3Codes = nextDayTop3.map(s => s.code);
    
    // 计算命中数
    const hits = predictedCodes.filter(code => 
        nextDayTop3Codes.includes(code)
    ).length;
    
    return {
        hits: hits,
        total: EVOLUTION_CONFIG.backtest.top_n,
        hit_rate: hits / EVOLUTION_CONFIG.backtest.top_n,
        predicted_codes: predictedCodes,
        actual_codes: nextDayTop3Codes,
        predicted_stocks: predictedTop3.map(s => ({ code: s.code, name: s.name, score: s.score })),
        actual_stocks: nextDayTop3.map(s => ({ code: s.code, name: s.name, change: s.change }))
    };
}

// 分析失败因子
function analyzeFailureFactors(predictedTop3, validationResult, currentWeights) {
    const failedCodes = predictedTop3
        .filter(stock => !validationResult.actual_codes.includes(stock.code))
        .map(stock => stock.code);
    
    const successCodes = predictedTop3
        .filter(stock => validationResult.actual_codes.includes(stock.code))
        .map(stock => stock.code);
    
    // 分析失败股票的因子特征
    const failureAnalysis = {
        failed_count: failedCodes.length,
        success_count: successCodes.length,
        factor_contributions: {},
        recommendations: []
    };
    
    // 计算各因子在失败股票中的平均贡献
    const factors = Object.keys(currentWeights);
    
    factors.forEach(factor => {
        // 失败股票的平均因子值
        const failedAvg = predictedTop3
            .filter(s => failedCodes.includes(s.code))
            .reduce((sum, s) => sum + (s.factors[factor] || 0), 0) / Math.max(1, failedCodes.length);
        
        // 成功股票的平均因子值
        const successAvg = predictedTop3
            .filter(s => successCodes.includes(s.code))
            .reduce((sum, s) => sum + (s.factors[factor] || 0), 0) / Math.max(1, successCodes.length);
        
        failureAnalysis.factor_contributions[factor] = {
            current_weight: currentWeights[factor],
            failed_avg: failedAvg,
            success_avg: successAvg,
            difference: successAvg - failedAvg
        };
        
        // 生成调整建议
        if (failedCodes.length > 0) {
            if (successAvg > failedAvg && successAvg - failedAvg > 0.1) {
                failureAnalysis.recommendations.push({
                    factor: factor,
                    action: "增强",
                    reason: `成功股票的平均${factor}因子值(${successAvg.toFixed(3)})显著高于失败股票(${failedAvg.toFixed(3)})`,
                    suggested_change: "+" + (currentWeights[factor] * EVOLUTION_CONFIG.evolution.learning_rate).toFixed(3)
                });
            } else if (failedAvg > successAvg && failedAvg - successAvg > 0.1) {
                failureAnalysis.recommendations.push({
                    factor: factor,
                    action: "减弱",
                    reason: `失败股票的平均${factor}因子值(${failedAvg.toFixed(3)})显著高于成功股票(${successAvg.toFixed(3)})`,
                    suggested_change: "-" + (currentWeights[factor] * EVOLUTION_CONFIG.evolution.penalty_factor).toFixed(3)
                });
            }
        }
    });
    
    return failureAnalysis;
}

// 调整因子权重
function adjustWeights(currentWeights, failureAnalysis) {
    const newWeights = { ...currentWeights };
    let totalAdjustment = 0;
    
    // 应用调整建议
    failureAnalysis.recommendations.forEach(rec => {
        const change = parseFloat(rec.suggested_change);
        newWeights[rec.factor] += change;
        totalAdjustment += Math.abs(change);
    });
    
    // 归一化权重（确保总和为1）
    const weightSum = Object.values(newWeights).reduce((a, b) => a + b, 0);
    for (const factor in newWeights) {
        newWeights[factor] /= weightSum;
    }
    
    return {
        new_weights: newWeights,
        adjustments_made: failureAnalysis.recommendations.length,
        total_adjustment: totalAdjustment
    };
}

// 单次反推进化
function singleReverseEvolution(historicalData, currentWeights, startDay) {
    if (startDay >= historicalData.length - 1) {
        return null; // 没有足够数据
    }
    
    const currentDayData = historicalData[startDay];
    const nextDayData = historicalData[startDay + 1];
    
    console.log(`\n📅 交易日 ${startDay + 1}/${historicalData.length}: ${currentDayData.date}`);
    console.log(`🔍 用当前策略选股...`);
    
    // 1. 用当前策略选股
    const predictedTop3 = selectTopStocks(currentDayData, currentWeights);
    
    console.log(`📊 预测Top3:`);
    predictedTop3.forEach((stock, i) => {
        console.log(`  ${i+1}. ${stock.code} ${stock.name} (${stock.score}分)`);
    });
    
    // 2. 用下一交易日验证
    const validationResult = validateHits(predictedTop3, nextDayData);
    
    console.log(`✅ 验证结果: 命中 ${validationResult.hits}/${validationResult.total}`);
    console.log(`🎯 实际Top3: ${validationResult.actual_codes.join(', ')}`);
    
    // 3. 分析失败因子
    const failureAnalysis = analyzeFailureFactors(predictedTop3, validationResult, currentWeights);
    
    // 4. 调整权重
    const weightAdjustment = adjustWeights(currentWeights, failureAnalysis);
    
    console.log(`🔄 权重调整: ${weightAdjustment.adjustments_made} 个因子调整`);
    
    return {
        day: startDay,
        date: currentDayData.date,
        validation_date: nextDayData.date,
        validation_result: validationResult,
        failure_analysis: failureAnalysis,
        weight_adjustment: weightAdjustment,
        new_weights: weightAdjustment.new_weights
    };
}

// 完整反推进化流程
function completeReverseEvolution() {
    console.log("🔄 开始完整反推进化流程");
    console.log("=".repeat(70));
    
    // 生成历史数据
    const historicalData = generateHistoricalData();
    
    // 初始权重
    let currentWeights = { ...EVOLUTION_CONFIG.factor_weights };
    const evolutionHistory = [];
    const performanceHistory = [];
    
    console.log(`\n🎯 初始因子权重:`);
    Object.entries(currentWeights).forEach(([factor, weight]) => {
        console.log(`  ${factor}: ${weight.toFixed(3)}`);
    });
    
    // 从最新交易日向前滚动
    const totalDays = historicalData.length;
    const lookbackDays = Math.min(EVOLUTION_CONFIG.backtest.lookback_days, totalDays - 1);
    
    console.log(`\n📈 执行 ${lookbackDays} 个交易日的反推进化:`);
    
    for (let i = 0; i < lookbackDays; i++) {
        const evolutionResult = singleReverseEvolution(historicalData, currentWeights, i);
        
        if (evolutionResult) {
            evolutionHistory.push(evolutionResult);
            currentWeights = evolutionResult.new_weights;
            
            // 记录性能
            performanceHistory.push({
                day: i + 1,
                hit_rate: evolutionResult.validation_result.hit_rate,
                weights: { ...currentWeights }
            });
            
            // 显示调整后的权重
            if (evolutionResult.weight_adjustment.adjustments_made > 0) {
                console.log(`📊 调整后权重:`);
                Object.entries(currentWeights).forEach(([factor, weight]) => {
                    console.log(`  ${factor}: ${weight.toFixed(3)}`);
                });
            }
            
            console.log(`\n${"=".repeat(50)}\n`);
        }
    }
    
    // 进化结果分析
    console.log("📊 进化结果分析:");
    console.log("=".repeat(70));
    
    const finalWeights = currentWeights;
    const initialWeights = EVOLUTION_CONFIG.factor_weights;
    
    console.log(`\n🎯 权重变化对比:`);
    Object.keys(finalWeights).forEach(factor => {
        const initial = initialWeights[factor];
        const final = finalWeights[factor];
        const change = ((final - initial) / initial * 100).toFixed(1);
        console.log(`  ${factor}: ${initial.toFixed(3)} → ${final.toFixed(3)} (${change}%)`);
    });
    
    // 计算平均命中率
    const avgHitRate = performanceHistory.reduce((sum, p) => sum + p.hit_rate, 0) / performanceHistory.length;
    console.log(`\n📈 平均命中率: ${(avgHitRate * 100).toFixed(1)}%`);
    
    // 进化趋势分析
    const hitRateTrend = performanceHistory.map(p => p.hit_rate);
    const improvement = hitRateTrend[hitRateTrend.length - 1] - hitRateTrend[0];
    console.log(`📊 命中率变化: ${(hitRateTrend[0] * 100).toFixed(1)}% → ${(hitRateTrend[hitRateTrend.length - 1] * 100).toFixed(1)}% (${improvement > 0 ? '+' : ''}${(improvement * 100).toFixed(1)}%)`);
    
    // 保存进化结果
    const fs = require('fs');
    const path = require('path');
    
    const evolutionResult = {
        timestamp: new Date().toISOString(),
        config: EVOLUTION_CONFIG,
        initial_weights: initialWeights,
        final_weights: finalWeights,
        performance_history: performanceHistory,
        evolution_history: evolutionHistory.map(h => ({
            day: h.day,
            date: h.date,
            validation_date: h.validation_date,
            hit_rate: h.validation_result.hit_rate,
            adjustments: h.weight_adjustment.adjustments_made
        })),
        summary: {
            total_iterations: lookbackDays,
            avg_hit_rate: avgHitRate,
            hit_rate_improvement: improvement,
            most_enhanced_factor: Object.entries(finalWeights).reduce((a, b) => 
                (b[1] - initialWeights[b[0]]) > (a[1] - initialWeights[a[0]]) ? b : a
            )[0],
            most_reduced_factor: Object.entries(finalWeights).reduce((a, b) => 
                (b[1] - initialWeights[b[0]]) < (a[1] - initialWeights[a[0]]) ? b : a
            )[0]
        }
    };
    
    const resultPath = path.join(__dirname, 'evolution_result.json');
    fs.writeFileSync(resultPath, JSON.stringify(evolutionResult, null, 2), 'utf8');
    console.log(`\n✅ 进化结果已保存: ${resultPath}`);
    
    // 更新系统状态
    updateSystemState(evolutionResult);
    
    return evolutionResult;
}

// 更新系统状态
function updateSystemState(evolutionResult) {
    const sessionStatePath = path.join(__dirname, 'SESSION-STATE.md');
    
    if (fs.existsSync(sessionStatePath)) {
        const fs = require('fs');
        let content = fs.readFileSync(sessionStatePath, 'utf8');
        
        const update = `\n\n## 🔄 反推进化机制完成 (${new Date().toLocaleString('zh-CN')})

### 进化配置
- **回看天数:** ${EVOLUTION_CONFIG.backtest.lookback_days}个交易日
- **验证窗口:** 下一交易日验证
- **输出数量:**