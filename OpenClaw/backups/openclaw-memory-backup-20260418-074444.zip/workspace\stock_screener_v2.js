// A股主板短线选股系统 v2.0 - 标准输出格式
console.log("🎯 A股主板短线选股系统 v2.0");
console.log("=".repeat(70));

// 1. 严格约束验证系统
function validateStock(stock) {
    const { code, name, price_change, turnover_rate, status } = stock;
    
    // 主板代码验证
    const isShanghai = /^60\d{4}$/.test(code);
    const isShenzhen = /^00\d{4}$/.test(code);
    
    if (!isShanghai && !isShenzhen) {
        if (/^688\d{3}$/.test(code)) return { valid: false, reason: "科创板" };
        if (/^300\d{3}$/.test(code)) return { valid: false, reason: "创业板" };
        if (/^8\d{5}$/.test(code)) return { valid: false, reason: "北交所" };
        if (/^900\d{3}$/.test(code)) return { valid: false, reason: "B股" };
        return { valid: false, reason: "非主板代码" };
    }
    
    // ST检测
    if (name && (/ST/i.test(name) || /\*ST/.test(name))) {
        return { valid: false, reason: "ST股票" };
    }
    
    // 代码ST检测
    if (/ST/i.test(code)) {
        return { valid: false, reason: "代码含ST" };
    }
    
    // 停牌检测
    if (status && status.includes("停牌")) {
        return { valid: false, reason: "停牌" };
    }
    
    // 异常数据检测
    if (price_change && (price_change < -20 || price_change > 20)) {
        return { valid: false, reason: "涨跌幅异常" };
    }
    
    if (turnover_rate && turnover_rate > 50) {
        return { valid: false, reason: "换手率异常" };
    }
    
    return {
        valid: true,
        market: isShanghai ? "沪市主板" : "深市主板"
    };
}

// 2. 主力资金分析系统
function analyzeCapitalFlow(stock) {
    const { code, name, price, volume, change } = stock;
    
    // 模拟主力资金分析
    const capitalFlow = Math.random() * 5000 - 1000; // 主力净流入(万元)
    const flowIntensity = Math.random() * 100; // 资金强度
    
    // 主力意图识别
    const intentions = [
        { type: "建仓", pattern: "温和放量，价格震荡" },
        { type: "准备拉升", pattern: "缩量整理，突破前高" },
        { type: "已经拉升", pattern: "连续放量，快速上涨" },
        { type: "一日游", pattern: "早盘急拉，尾盘回落" },
        { type: "骗炮", pattern: "假突破，量价背离" }
    ];
    
    const intention = intentions[Math.floor(Math.random() * intentions.length)];
    
    return {
        capital_flow: capitalFlow.toFixed(0),
        flow_intensity: flowIntensity.toFixed(1),
        intention: intention.type,
        pattern: intention.pattern
    };
}

// 3. 综合评分系统 (0-100分)
function calculateScore(stock, capitalAnalysis) {
    let score = 50; // 基础分
    
    // 资金流评分 (0-30分)
    const capitalFlow = parseFloat(capitalAnalysis.capital_flow);
    if (capitalFlow > 0) {
        score += Math.min(30, capitalFlow / 100); // 每100万元加1分，最多30分
    } else {
        score -= Math.min(20, Math.abs(capitalFlow) / 50); // 每50万元减1分，最多减20分
    }
    
    // 资金强度评分 (0-20分)
    const flowIntensity = parseFloat(capitalAnalysis.flow_intensity);
    score += flowIntensity * 0.2; // 每1%强度加0.2分
    
    // 主力意图评分 (0-25分)
    const intentionScores = {
        "建仓": 20,
        "准备拉升": 25,
        "已经拉升": 15,
        "一日游": 5,
        "骗炮": -10
    };
    score += intentionScores[capitalAnalysis.intention] || 0;
    
    // 技术面评分 (0-15分)
    if (stock.change > 0) {
        score += Math.min(15, stock.change * 0.5); // 每1%涨幅加0.5分
    }
    
    if (stock.turnover_rate > 0) {
        score += Math.min(10, stock.turnover_rate * 0.2); // 每1%换手率加0.2分
    }
    
    // 确保分数在0-100之间
    score = Math.max(0, Math.min(100, Math.round(score)));
    
    return score;
}

// 4. 压力位分析系统
function analyzePressureLevels(stock) {
    const { price } = stock;
    const basePrice = price || 50;
    
    // 3档压力位
    return {
        level1: (basePrice * 1.05).toFixed(2), // 第一压力位: +5%
        level2: (basePrice * 1.10).toFixed(2), // 第二压力位: +10%
        level3: (basePrice * 1.15).toFixed(2)  // 第三压力位: +15%
    };
}

// 5. 推荐逻辑生成
function generateRecommendationLogic(stock, capitalAnalysis, score) {
    const { code, name, change, turnover_rate } = stock;
    
    const logics = [];
    
    // 资金逻辑
    const capitalFlow = parseFloat(capitalAnalysis.capital_flow);
    if (capitalFlow > 1000) {
        logics.push(`主力资金大幅流入${Math.abs(capitalFlow).toFixed(0)}万元`);
    } else if (capitalFlow > 0) {
        logics.push(`主力资金净流入${capitalFlow.toFixed(0)}万元`);
    } else if (capitalFlow < -500) {
        logics.push(`主力资金流出${Math.abs(capitalFlow).toFixed(0)}万元需谨慎`);
    }
    
    // 量价逻辑
    if (change > 5) {
        logics.push(`放量上涨${change.toFixed(1)}%`);
    } else if (change > 0) {
        logics.push(`温和上涨${change.toFixed(1)}%`);
    }
    
    if (turnover_rate > 10) {
        logics.push(`换手活跃${turnover_rate.toFixed(1)}%`);
    }
    
    // 题材逻辑 (模拟)
    const themes = ["新能源", "人工智能", "消费电子", "医药医疗", "大金融"];
    const theme = themes[Math.floor(Math.random() * themes.length)];
    logics.push(`${theme}题材受关注`);
    
    // 合并为一句
    if (logics.length > 0) {
        return logics.join('，');
    }
    return "技术面改善，资金关注度提升";
}

// 6. 预期收益和建议持仓天数
function generateExpectations(score, capitalAnalysis) {
    let expectedReturn, holdingDays;
    
    if (score >= 85) {
        expectedReturn = "8%-15%";
        holdingDays = "3-7天";
    } else if (score >= 75) {
        expectedReturn = "5%-10%";
        holdingDays = "5-10天";
    } else if (score >= 65) {
        expectedReturn = "3%-8%";
        holdingDays = "7-14天";
    } else {
        expectedReturn = "2%-5%";
        holdingDays = "10-20天";
    }
    
    // 根据主力意图调整
    if (capitalAnalysis.intention === "准备拉升") {
        expectedReturn = `${expectedReturn.split('-')[0]}-${parseInt(expectedReturn.split('-')[1]) + 3}%`;
        holdingDays = "3-7天";
    } else if (capitalAnalysis.intention === "一日游") {
        expectedReturn = "2%-5%";
        holdingDays = "1-3天";
    }
    
    return { expectedReturn, holdingDays };
}

// 7. 操作建议生成
function generateOperationAdvice(score, capitalAnalysis, pressureLevels) {
    if (score >= 85) {
        return `重点关注，可在${pressureLevels.level1}元以下分批买入，止损设在-5%`;
    } else if (score >= 75) {
        return `积极关注，回调至${pressureLevels.level1}元附近可考虑介入，止损-7%`;
    } else if (score >= 65) {
        return `观察为主，等待突破${pressureLevels.level1}元确认信号，严格止损-8%`;
    } else {
        return `谨慎观望，需等待更明确信号，不建议追高`;
    }
}

// 8. 标准输出格式
function formatStockOutput(stock, index) {
    const validation = validateStock(stock);
    if (!validation.valid) return null;
    
    const capitalAnalysis = analyzeCapitalFlow(stock);
    const score = calculateScore(stock, capitalAnalysis);
    const pressureLevels = analyzePressureLevels(stock);
    const recommendationLogic = generateRecommendationLogic(stock, capitalAnalysis, score);
    const expectations = generateExpectations(score, capitalAnalysis);
    const operationAdvice = generateOperationAdvice(score, capitalAnalysis, pressureLevels);
    
    const now = new Date();
    const reportTime = `${now.getFullYear()}-${(now.getMonth()+1).toString().padStart(2,'0')}-${now.getDate().toString().padStart(2,'0')} ${now.getHours().toString().padStart(2,'0')}:${now.getMinutes().toString().padStart(2,'0')} (${['日','一','二','三','四','五','六'][now.getDay()]})`;
    
    return {
        index: index + 1,
        output: `时间：${reportTime}。
股票名称：${stock.name}
股票代码：${stock.code}
最新价格：${stock.price || "未知"}元
推荐指数：${score}分(0到100整数，表示观察优先级)
推荐逻辑：${recommendationLogic}
预期收益：${expectations.expectedReturn}
建议持仓天数：${expectations.holdingDays}
3档压力位分析：${pressureLevels.level1}元 / ${pressureLevels.level2}元 / ${pressureLevels.level3}元
操作建议：${operationAdvice}`,
        score: score,
        details: {
            validation,
            capitalAnalysis,
            pressureLevels,
            expectations,
            operationAdvice
        }
    };
}

// 9. 模拟股票数据
const mockStocks = [
    { code: "600519", name: "贵州茅台", price: 1799.00, change: 2.5, turnover_rate: 0.8, volume: 5000000, status: "正常" },
    { code: "000858", name: "五粮液", price: 158.50, change: 1.8, turnover_rate: 1.2, volume: 8000000, status: "正常" },
    { code: "000002", name: "万科A", price: 9.85, change: 0.5, turnover_rate: 0.9, volume: 12000000, status: "正常" },
    { code: "000001", name: "平安银行", price: 10.32, change: 1.2, turnover_rate: 0.7, volume: 15000000, status: "正常" },
    { code: "600036", name: "招商银行", price: 32.45, change: 0.8, turnover_rate: 0.6, volume: 10000000, status: "正常" },
    { code: "000333", name: "美的集团", price: 68.90, change: 1.5, turnover_rate: 0.9, volume: 7000000, status: "正常" },
    { code: "600276", name: "恒瑞医药", price: 45.60, change: -0.5, turnover_rate: 1.1, volume: 9000000, status: "正常" },
    { code: "600887", name: "伊利股份", price: 28.75, change: 1.0, turnover_rate: 0.8, volume: 6000000, status: "正常" },
    { code: "000651", name: "格力电器", price: 38.20, change: 0.7, turnover_rate: 0.7, volume: 5000000, status: "正常" },
    { code: "600030", name: "中信证券", price: 22.15, change: 1.5, turnover_rate: 1.3, volume: 20000000, status: "正常" }
];

// 10. 主函数
function main() {
    console.log("🔍 执行A股主板选股筛选...");
    console.log("=".repeat(70));
    
    // 筛选和评分
    const screenedStocks = [];
    
    mockStocks.forEach((stock, index) => {
        const output = formatStockOutput(stock, index);
        if (output) {
            screenedStocks.push(output);
        }
    });
    
    // 按评分排序
    screenedStocks.sort((a, b) => b.score - a.score);
    
    // 输出前3只股票
    console.log(`📊 筛选结果: ${screenedStocks.length}只通过验证`);
    console.log(`🎯 输出前3只得分最高的股票:`);
    console.log("=".repeat(70));
    
    const top3Stocks = screenedStocks.slice(0, 3);
    
    top3Stocks.forEach((stock, index) => {
        console.log(`\n${stock.output}`);
        if (index < 2) {
            console.log("\n" + "-".repeat(70));
        }
    });
    
    // 显示筛选统计
    console.log("\n" + "=".repeat(70));
    console.log("📈 筛选统计:");
    console.log("=".repeat(70));
    
    console.log(`总股票数: ${mockStocks.length}`);
    console.log(`通过验证: ${screenedStocks.length}`);
    console.log(`排除股票: ${mockStocks.length - screenedStocks.length}`);
    console.log(`输出数量: ${Math.min(3, screenedStocks.length)}`);
    
    if (top3Stocks.length > 0) {
        console.log(`\n🏆 最高分: ${top3Stocks[0].score}分 (${top3Stocks[0].details.capitalAnalysis.intention})`);
        console.log(`📊 平均分: ${(top3Stocks.reduce((sum, s) => sum + s.score, 0) / top3Stocks.length).toFixed(1)}分`);
    }
    
    // 保存结果
    const fs = require('fs');
    const path = require('path');
    
    const result = {
        timestamp: new Date().toISOString(),
        total_stocks: mockStocks.length,
        passed_stocks: screenedStocks.length,
        top_3_stocks: top3Stocks.map(s => ({
            code: s.details.validation.market === "沪市主板" ? s.details.validation.code : s.details.validation.code,
            name: s.details.validation.name,
            score: s.score,
            capital_flow: s.details.capitalAnalysis.capital_flow,
            intention: s.details.capitalAnalysis.intention
        })),
        output_format: "标准3只股票输出"
    };
    
    const resultPath = path.join(__dirname, 'screening_result.json');
    fs.writeFileSync(resultPath, JSON.stringify(result, null, 2), 'utf8');
    console.log(`\n✅ 筛选结果已保存: ${resultPath}`);
    
    // 更新系统状态
    const sessionStatePath = path.join(__dirname, 'SESSION-STATE.md');
    if (fs.existsSync(sessionStatePath)) {
        let content = fs.readFileSync(sessionStatePath, 'utf8');
        
        const update = `\n\n## 📊 标准选股输出测试 (${new Date().toLocaleString('zh-CN')})

### 输出格式确认
**默认输出:** 3只得分最高的股票
**输出结构:**
\`\`\`
时间：YYYY-MM-DD HH:MM (星期X)。
股票名称：XXX
股票代码：XXXXXX
最新价格：XX元
推荐指数：XX分(0到100整数，表示观察优先级)
推荐逻辑：资金、量价、题材主因合并为一句
预期收益：X%-X%
建议持仓天数：X-X天
3档压力位分析：XX元 / XX元 / XX元
操作建议：XXX
\`\`\`

### 本次测试结果
- **测试股票:** ${mockStocks.length} 只
- **通过筛选:** ${screenedStocks.length} 只
- **输出数量:** ${Math.min(3, screenedStocks.length)} 只 (前3名)

### 前3名股票概览
${top3Stocks.map((s, i) => `
**第${i+1}名: ${s.details.validation.name} (${s.details.validation.code})**
- 推荐指数: ${s.score}分
- 主力意图: ${s.details.capitalAnalysis.intention}
- 资金流向