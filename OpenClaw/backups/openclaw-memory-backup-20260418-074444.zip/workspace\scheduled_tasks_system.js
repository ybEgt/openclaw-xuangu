// 定时任务系统 - 完整实现
console.log("⏰ 定时任务系统 v1.0");
console.log("=".repeat(70));

const fs = require('fs');
const path = require('path');
const nodemailer = require('nodemailer');

// 系统配置
const SYSTEM_CONFIG = {
    // 邮箱配置
    email: {
        user: "zhangyuru999@qq.com",
        password: "yjhatgqnbailcahb",
        recipient: "zhangyuru999@qq.com"
    },
    
    // 任务配置
    tasks: {
        // 任务1: 盘前扫雷 (8:30~9:15，每15分钟)
        pre_market_scan: {
            name: "盘前扫雷",
            schedule: "30-45/15 8 * * 1-5", // 8:30, 8:45, 9:00
            description: "交易日开盘前，排查上一交易日存档股票的新闻",
            action: "scan_previous_day_stocks"
        },
        
        // 任务2: 盘中频筛 (开盘后~14:00，每30分钟)
        intraday_screening: {
            name: "盘中频筛", 
            schedule: "0,30 9-13 * * 1-5", // 9:00-13:30 每30分钟
            description: "交易时间段内，按照最新策略筛选股票",
            action: "screen_stocks"
        },
        
        // 任务3: 尾盘终筛 (14:00~14:50，每10分钟)
        final_screening: {
            name: "尾盘终筛",
            schedule: "0-50/10 14 * * 1-5", // 14:00-14:50 每10分钟
            description: "收盘前密集筛选，最后一组数据存档",
            action: "final_screen_and_archive"
        },
        
        // 任务4: 盘后复盘 (15:10后)
        post_market_review: {
            name: "盘后复盘",
            schedule: "10 15 * * 1-5", // 15:10
            description: "验证策略并触发反推进化",
            action: "review_and_evolve"
        }
    },
    
    // 数据存档目录
    archive_dirs: {
        intraday: "archive/intraday",      // 盘中筛选存档
        pre_market: "archive/pre_market",  // 盘前扫雷存档
        final: "archive/final",            // 尾盘终筛存档
        evolution: "archive/evolution"     // 进化记录
    }
};

// 1. 交易日检查函数
function isTradingDay(date = new Date()) {
    const dayOfWeek = date.getDay(); // 0=周日, 1=周一, ..., 6=周六
    return dayOfWeek >= 1 && dayOfWeek <= 5; // 周一至周五
}

// 2. 邮件发送函数
async function sendEmail(subject, content, isHtml = false) {
    try {
        const transporter = nodemailer.createTransport({
            host: "smtp.qq.com",
            port: 465,
            secure: true,
            auth: {
                user: SYSTEM_CONFIG.email.user,
                pass: SYSTEM_CONFIG.email.password
            }
        });
        
        const mailOptions = {
            from: `"A股选股系统" <${SYSTEM_CONFIG.email.user}>`,
            to: SYSTEM_CONFIG.email.recipient,
            subject: subject,
            text: isHtml ? undefined : content,
            html: isHtml ? content : undefined
        };
        
        const info = await transporter.sendMail(mailOptions);
        console.log(`✅ 邮件发送成功: ${info.messageId}`);
        return true;
    } catch (error) {
        console.error(`❌ 邮件发送失败: ${error.message}`);
        return false;
    }
}

// 3. 模拟股票数据获取
function getMockStockData(count = 10) {
    const stocks = [];
    const sectors = ["科技", "消费", "金融", "医药", "能源", "制造"];
    
    for (let i = 1; i <= count; i++) {
        const code = i <= 5 ? `600${100 + i}`.slice(0, 6) : `000${100 + i}`.slice(0, 6);
        
        stocks.push({
            code: code,
            name: `股票${i}`,
            price: (10 + Math.random() * 100).toFixed(2),
            change: (Math.random() * 10 - 5).toFixed(2),
            turnover: (Math.random() * 5).toFixed(2),
            sector: sectors[i % sectors.length],
            capital_flow: (Math.random() * 20000 - 5000).toFixed(0)
        });
    }
    
    return stocks;
}

// 4. 模拟新闻检查
function checkStockNews(stocks) {
    const results = {
        total_checked: stocks.length,
        has_bad_news: 0,
        bad_news_stocks: []
    };
    
    // 模拟10%的股票有负面新闻
    stocks.forEach(stock => {
        if (Math.random() < 0.1) { // 10%概率有负面新闻
            const newsTypes = [
                "业绩预告不及预期",
                "大股东减持公告", 
                "监管问询函",
                "重大诉讼风险",
                "行业政策变化"
            ];
            
            const newsType = newsTypes[Math.floor(Math.random() * newsTypes.length)];
            
            results.has_bad_news++;
            results.bad_news_stocks.push({
                ...stock,
                news_type: newsType,
                risk_level: Math.random() > 0.5 ? "高风险" : "中风险"
            });
        }
    });
    
    return results;
}

// 5. 选股策略
function screenStocks(stocks, topN = 3) {
    // 简单评分策略
    const scoredStocks = stocks.map(stock => {
        let score = 50; // 基础分
        
        // 涨幅加分
        if (parseFloat(stock.change) > 0) {
            score += Math.min(20, parseFloat(stock.change) * 2);
        }
        
        // 资金流加分
        if (parseFloat(stock.capital_flow) > 0) {
            score += Math.min(20, parseFloat(stock.capital_flow) / 500);
        }
        
        // 换手率加分
        if (parseFloat(stock.turnover) > 0.5) {
            score += Math.min(10, parseFloat(stock.turnover) * 2);
        }
        
        // 随机因素
        score += Math.random() * 10 - 5;
        
        return {
            ...stock,
            score: Math.max(0, Math.min(100, Math.round(score)))
        };
    });
    
    // 排序并取前N名
    return scoredStocks
        .sort((a, b) => b.score - a.score)
        .slice(0, topN);
}

// 6. 数据存档
function archiveData(taskName, data, timestamp = new Date()) {
    const dateStr = timestamp.toISOString().split('T')[0];
    const timeStr = timestamp.toTimeString().split(' ')[0].replace(/:/g, '-');
    
    // 确定存档目录
    let archiveDir;
    switch(taskName) {
        case "intraday_screening":
            archiveDir = SYSTEM_CONFIG.archive_dirs.intraday;
            break;
        case "final_screening":
            archiveDir = SYSTEM_CONFIG.archive_dirs.final;
            break;
        case "pre_market_scan":
            archiveDir = SYSTEM_CONFIG.archive_dirs.pre_market;
            break;
        default:
            archiveDir = "archive/other";
    }
    
    // 创建目录
    const fullDir = path.join(__dirname, archiveDir, dateStr);
    if (!fs.existsSync(fullDir)) {
        fs.mkdirSync(fullDir, { recursive: true });
    }
    
    // 保存文件
    const filename = `${timeStr}_${taskName}.json`;
    const filepath = path.join(fullDir, filename);
    
    const archiveData = {
        task: taskName,
        timestamp: timestamp.toISOString(),
        data: data
    };
    
    fs.writeFileSync(filepath, JSON.stringify(archiveData, null, 2), 'utf8');
    console.log(`📁 数据已存档: ${filepath}`);
    
    return filepath;
}

// 7. 加载上一交易日存档
function loadPreviousDayArchive(taskName) {
    const now = new Date();
    let prevDay = new Date(now);
    
    // 向前查找交易日
    for (let i = 1; i <= 7; i++) {
        prevDay.setDate(prevDay.getDate() - 1);
        if (isTradingDay(prevDay)) {
            const dateStr = prevDay.toISOString().split('T')[0];
            
            // 确定存档目录
            let archiveDir;
            if (taskName === "pre_market_scan") {
                archiveDir = SYSTEM_CONFIG.archive_dirs.intraday; // 检查盘中筛选存档
            } else if (taskName === "post_market_review") {
                archiveDir = SYSTEM_CONFIG.archive_dirs.final; // 检查尾盘终筛存档
            } else {
                archiveDir = SYSTEM_CONFIG.archive_dirs.intraday;
            }
            
            const archivePath = path.join(__dirname, archiveDir, dateStr);
            
            if (fs.existsSync(archivePath)) {
                // 查找最新的存档文件
                const files = fs.readdirSync(archivePath)
                    .filter(f => f.includes(taskName === "pre_market_scan" ? "intraday_screening" : "final_screening"))
                    .sort()
                    .reverse();
                
                if (files.length > 0) {
                    const latestFile = files[0];
                    const filepath = path.join(archivePath, latestFile);
                    
                    try {
                        const data = JSON.parse(fs.readFileSync(filepath, 'utf8'));
                        console.log(`📂 加载上一交易日存档: ${filepath}`);
                        return data;
                    } catch (e) {
                        console.log(`⚠️  无法读取存档文件: ${e.message}`);
                    }
                }
            }
            
            console.log(`📭 未找到 ${dateStr} 的存档数据`);
            return null;
        }
    }
    
    console.log("📭 未找到上一交易日的存档数据");
    return null;
}

// 8. 任务1: 盘前扫雷
async function taskPreMarketScan() {
    console.log("🔍 执行任务1: 盘前扫雷");
    
    // 检查是否为交易日
    if (!isTradingDay()) {
        console.log("⏸️  非交易日，跳过盘前扫雷");
        return { executed: false, reason: "非交易日" };
    }
    
    // 加载上一交易日存档
    const previousArchive = loadPreviousDayArchive("pre_market_scan");
    
    if (!previousArchive || !previousArchive.data || !previousArchive.data.top_stocks) {
        console.log("📭 无上一交易日存档数据，跳过扫雷");
        return { executed: false, reason: "无存档数据" };
    }
    
    const previousStocks = previousArchive.data.top_stocks;
    console.log(`📊 检查 ${previousStocks.length} 只上一交易日股票`);
    
    // 检查新闻
    const newsCheck = checkStockNews(previousStocks);
    
    if (newsCheck.has_bad_news > 0) {
        console.log(`⚠️  发现 ${newsCheck.has_bad_news} 只股票有负面新闻`);
        
        // 生成邮件内容
        const emailContent = `盘前扫雷发现 ${newsCheck.has_bad_news} 只股票有负面新闻：

${newsCheck.bad_news_stocks.map((stock, i) => `
${i+1}. ${stock.code} ${stock.name}
   价格: ${stock.price}元
   涨跌: ${stock.change}%
   负面新闻: ${stock.news_type}
   风险等级: ${stock.risk_level}
`).join('\n')}

建议今日交易时注意回避这些股票。

扫描时间: ${new Date().toLocaleString('zh-CN')}`;
        
        // 发送邮件
        const emailSent = await sendEmail(
            `⚠️ 盘前扫雷发现 ${newsCheck.has_bad_news} 只风险股票`,
            emailContent
        );
        
        // 存档扫雷结果
        archiveData("pre_market_scan", {
            previous_day: previousArchive.timestamp,
            news_check: newsCheck,
            email_sent: emailSent
        });
        
        return {
            executed: true,
            news_check: newsCheck,
            email_sent: emailSent
        };
    } else {
        console.log("✅ 未发现负面新闻，不发送邮件");
        
        // 存档结果（即使没有负面新闻也存档）
        archiveData("pre_market_scan", {
            previous_day: previousArchive.timestamp,
            news_check: newsCheck,
            email_sent: false,
            reason: "无负面新闻"
        });
        
        return {
            executed: true,
            news_check: newsCheck,
            email_sent: false,
            reason: "无负面新闻"
        };
    }
}

// 9. 任务2: 盘中频筛
async function taskIntradayScreening() {
    console.log("📊 执行任务2: 盘中频筛");
    
    // 检查是否为交易日
    if (!isTradingDay()) {
        console.log("⏸️  非交易日，跳过盘中筛选");
        return { executed: false, reason: "非交易日" };
    }
    
    // 获取股票数据
    const allStocks = getMockStockData(20);
    console.log(`📈 获取 ${allStocks.length} 只股票数据`);
    
    // 筛选Top3
    const topStocks = screenStocks(allStocks, 3);
    
    console.log("🎯 筛选结果Top3:");
    topStocks.forEach((stock, i) => {
        console.log(`  ${i+1}. ${stock.code} ${stock.name} - ${stock.score}分`);
    });
    
    // 生成邮件内容
    const now = new Date();
    const emailContent = `盘中筛选结果 (${now.toLocaleTimeString('zh-CN', {hour12: false})})：

${topStocks.map((stock, i) => `
${i+1}. ${stock.code} ${stock.name}
   价格: ${stock.price}元
   涨跌: ${stock.change}%
   资金流: ${stock.capital_flow}万元
   换手率: ${stock.turnover}%
   评分: ${stock.score}/100
`).join('\n')}

筛选时间: ${now.toLocaleString('zh-CN')}
策略版本: 最新策略`;

    // 发送邮件
    const emailSent = await sendEmail(
        `📈 盘中筛选结果 - ${now.toLocaleTimeString('zh-CN', {hour12: false}).slice(0,5)}`,
        emailContent
    );
    
    // 存档数据
    const archivePath = archiveData("intraday_screening", {
        timestamp: now.toISOString(),
        top_stocks: topStocks,
        total_stocks: allStocks.length,
        email_sent: emailSent
    });
    
    return {
        executed: true,
        top_stocks: topStocks,
        email_sent: emailSent,
        archive_path: archivePath
    };
}

// 10. 任务3: 尾盘终筛
async function taskFinalScreening() {
    console.log("🎯 执行任务3: 尾盘终筛");
    
    // 检查是否为交易日
    if (!isTradingDay()) {
        console.log("⏸️  非交易日，跳过尾盘筛选");
        return { executed: false, reason: "非交易日" };
    }
    
    // 获取股票数据
    const allStocks = getMockStockData(25);
    console.log(`📈 获取 ${allStocks.length} 只股票数据`);
    
    // 筛选Top3
    const topStocks = screenStocks(allStocks, 3);
    
    console.log("🎯 尾盘筛选结果Top3:");
    topStocks.forEach((stock, i) => {
        console.log(`  ${i+1}. ${stock.code} ${stock.name} - ${stock.score}分`);
    });
    
    // 生成邮件内容
    const now = new Date();
    const emailContent = `尾盘终筛结果 (${now.toLocaleTimeString('zh-CN', {hour12: false})})：

${topStocks.map((stock, i) => `
${i+1}. ${stock.code} ${stock.name}
   价格: ${stock.price}元
   涨跌: ${stock.change}%
   资金流: ${stock.capital_flow}万元
   换手率: ${stock.turnover}%
   评分: ${stock.score}/100
`).join('\n')}

⚠️ 注意：此数据将存档用于次日盘前扫雷和盘后复盘

筛选时间: ${now.toLocaleString('zh-CN')}
策略版本: 最新策略`;

    // 发送邮件
    const emailSent = await sendEmail(
        `🎯 尾盘终筛结果 - ${now.toLocaleTimeString('zh-CN', {hour12: false}).slice(0,5)}`,
        emailContent
    );
    
    // 存档数据（用于次日）
    const archivePath = archiveData("final_screening", {
        timestamp: now.toISOString(),
        top_stocks: topStocks,
        total_stocks: allStocks.length,
        email_sent: emailSent,
        purpose: "用于次日盘前扫雷和盘后复盘"
    });
    
    return {
        executed: true,
        top_stocks: topStocks,
        email_sent