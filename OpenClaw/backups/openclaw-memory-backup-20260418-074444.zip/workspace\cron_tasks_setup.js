// 定时任务配置和设置
console.log("⏰ 定时任务配置系统");
console.log("=".repeat(70));

const fs = require('fs');
const path = require('path');

// 系统配置
const SYSTEM_CONFIG = {
    // 任务定义
    tasks: [
        {
            id: "pre_market_scan",
            name: "盘前扫雷",
            description: "交易日开盘前(8:30~9:15)，每隔15分钟查询上一交易日存档股票的新闻",
            schedule: {
                cron: "30-45/15 8 * * 1-5", // 8:30, 8:45, 9:00, 周一至周五
                timezone: "Asia/Shanghai"
            },
            script: "task_pre_market.js",
            conditions: ["is_trading_day", "time_between_08:30_09:15"],
            email_on_success: false, // 只有发现负面新闻才发邮件
            email_on_failure: true
        },
        {
            id: "intraday_screening",
            name: "盘中频筛",
            description: "交易日开盘后~14:00，按照最新策略每隔30分钟筛选一组股票数据",
            schedule: {
                cron: "0,30 9-13 * * 1-5", // 9:00-13:30 每30分钟, 周一至周五
                timezone: "Asia/Shanghai"
            },
            script: "task_intraday.js",
            conditions: ["is_trading_day", "time_between_09:30_14:00"],
            email_on_success: true,
            email_on_failure: true
        },
        {
            id: "final_screening",
            name: "尾盘终筛",
            description: "交易日14:00~14:50，按照最新策略每隔10分钟筛选一组股票数据，最后一组数据存档",
            schedule: {
                cron: "0-50/10 14 * * 1-5", // 14:00-14:50 每10分钟, 周一至周五
                timezone: "Asia/Shanghai"
            },
            script: "task_final.js",
            conditions: ["is_trading_day", "time_between_14:00_14:50"],
            email_on_success: true,
            email_on_failure: true,
            archive: true // 需要存档
        },
        {
            id: "post_market_review",
            name: "盘后复盘",
            description: "15:10后按照最新策略筛选数据，并读取上一交易日存档股票做验证，未通过则触发反推进化",
            schedule: {
                cron: "10 15 * * 1-5", // 15:10, 周一至周五
                timezone: "Asia/Shanghai"
            },
            script: "task_review.js",
            conditions: ["is_trading_day", "time_after_15:10"],
            email_on_success: true,
            email_on_failure: true,
            trigger_evolution: true // 可能触发反推进化
        }
    ],
    
    // 邮箱配置
    email: {
        recipient: "zhangyuru999@qq.com",
        from: "zhangyuru999@qq.com"
    },
    
    // 存档配置
    archive: {
        intraday: "archive/intraday",
        final: "archive/final",
        evolution: "archive/evolution"
    }
};

// 创建任务脚本
function createTaskScripts() {
    console.log("📝 创建任务脚本...");
    
    const scriptsDir = path.join(__dirname, 'task_scripts');
    if (!fs.existsSync(scriptsDir)) {
        fs.mkdirSync(scriptsDir, { recursive: true });
        console.log(`✅ 创建脚本目录: ${scriptsDir}`);
    }
    
    // 1. 盘前扫雷脚本
    const preMarketScript = `// 盘前扫雷任务脚本
const { taskPreMarketScan } = require('../scheduled_tasks_system.js');

async function main() {
    console.log("🔍 盘前扫雷任务启动");
    console.log("=".repeat(50));
    
    try {
        const result = await taskPreMarketScan();
        
        if (result.executed) {
            if (result.news_check.has_bad_news > 0) {
                console.log(\`✅ 任务完成，发现 \${result.news_check.has_bad_news} 只风险股票\`);
                process.exit(0);
            } else {
                console.log("✅ 任务完成，未发现风险股票");
                process.exit(0);
            }
        } else {
            console.log(\`⏸️  任务跳过: \${result.reason}\`);
            process.exit(0);
        }
    } catch (error) {
        console.error(\`❌ 任务执行失败: \${error.message}\`);
        process.exit(1);
    }
}

main();`;

    // 2. 盘中频筛脚本
    const intradayScript = `// 盘中频筛任务脚本
const { taskIntradayScreening } = require('../scheduled_tasks_system.js');

async function main() {
    console.log("📊 盘中频筛任务启动");
    console.log("=".repeat(50));
    
    try {
        const result = await taskIntradayScreening();
        
        if (result.executed) {
            console.log(\`✅ 任务完成，筛选 \${result.top_stocks.length} 只股票\`);
            console.log(\`📧 邮件发送: \${result.email_sent ? '成功' : '失败'}\`);
            process.exit(0);
        } else {
            console.log(\`⏸️  任务跳过: \${result.reason}\`);
            process.exit(0);
        }
    } catch (error) {
        console.error(\`❌ 任务执行失败: \${error.message}\`);
        process.exit(1);
    }
}

main();`;

    // 3. 尾盘终筛脚本
    const finalScript = `// 尾盘终筛任务脚本
const { taskFinalScreening } = require('../scheduled_tasks_system.js');

async function main() {
    console.log("🎯 尾盘终筛任务启动");
    console.log("=".repeat(50));
    
    try {
        const result = await taskFinalScreening();
        
        if (result.executed) {
            console.log(\`✅ 任务完成，筛选 \${result.top_stocks.length} 只股票\`);
            console.log(\`📧 邮件发送: \${result.email_sent ? '成功' : '失败'}\`);
            console.log(\`📁 数据已存档\`);
            process.exit(0);
        } else {
            console.log(\`⏸️  任务跳过: \${result.reason}\`);
            process.exit(0);
        }
    } catch (error) {
        console.error(\`❌ 任务执行失败: \${error.message}\`);
        process.exit(1);
    }
}

main();`;

    // 4. 盘后复盘脚本
    const reviewScript = `// 盘后复盘任务脚本
const { taskPostMarketReview } = require('../scheduled_tasks_system.js');

async function main() {
    console.log("🔄 盘后复盘任务启动");
    console.log("=".repeat(50));
    
    try {
        const result = await taskPostMarketReview();
        
        if (result.executed) {
            console.log(\`✅ 任务完成，验证 \${result.validation_result ? result.validation_result.hits : 0} 只股票命中\`);
            console.log(\`📧 邮件发送: \${result.email_sent ? '成功' : '失败'}\`);
            
            if (result.evolution_triggered) {
                console.log(\`🔄 触发反推进化，回测 \${result.evolution_days} 天\`);
            }
            
            process.exit(0);
        } else {
            console.log(\`⏸️  任务跳过: \${result.reason}\`);
            process.exit(0);
        }
    } catch (error) {
        console.error(\`❌ 任务执行失败: \${error.message}\`);
        process.exit(1);
    }
}

main();`;

    // 保存脚本
    const scripts = [
        { name: "task_pre_market.js", content: preMarketScript },
        { name: "task_intraday.js", content: intradayScript },
        { name: "task_final.js", content: finalScript },
        { name: "task_review.js", content: reviewScript }
    ];

    scripts.forEach(script => {
        const filepath = path.join(scriptsDir, script.name);
        fs.writeFileSync(filepath, script.content, 'utf8');
        console.log(`✅ 创建脚本: ${script.name}`);
    });

    return scriptsDir;
}

// 创建cron配置文件
function createCronConfig() {
    console.log("\n⏱️  创建cron配置...");
    
    const cronConfig = {
        version: "1.0",
        created: new Date().toISOString(),
        timezone: "Asia/Shanghai",
        tasks: SYSTEM_CONFIG.tasks.map(task => ({
            id: task.id,
            name: task.name,
            schedule: task.schedule.cron,
            command: `cd "${__dirname}" && node "task_scripts/${task.script}"`,
            description: task.description,
            conditions: task.conditions,
            email_notification: {
                on_success: task.email_on_success,
                on_failure: task.email_on_failure
            }
        }))
    };
    
    const configPath = path.join(__dirname, 'cron_config.json');
    fs.writeFileSync(configPath, JSON.stringify(cronConfig, null, 2), 'utf8');
    console.log(`✅ 创建cron配置: ${configPath}`);
    
    // 创建crontab文件（Linux/Mac）
    const crontabContent = `# A股选股系统定时任务
# 时区: Asia/Shanghai
# 创建时间: ${new Date().toLocaleString('zh-CN')}

# 任务1: 盘前扫雷 (8:30~9:15，每15分钟)
30-45/15 8 * * 1-5 cd "${__dirname}" && node "task_scripts/task_pre_market.js" >> "${__dirname}/logs/pre_market.log" 2>&1

# 任务2: 盘中频筛 (9:00~13:30，每30分钟)
0,30 9-13 * * 1-5 cd "${__dirname}" && node "task_scripts/task_intraday.js" >> "${__dirname}/logs/intraday.log" 2>&1

# 任务3: 尾盘终筛 (14:00~14:50，每10分钟)
0-50/10 14 * * 1-5 cd "${__dirname}" && node "task_scripts/task_final.js" >> "${__dirname}/logs/final.log" 2>&1

# 任务4: 盘后复盘 (15:10)
10 15 * * 1-5 cd "${__dirname}" && node "task_scripts/task_review.js" >> "${__dirname}/logs/review.log" 2>&1

# 系统维护: 每日清理旧日志 (凌晨2点)
0 2 * * * find "${__dirname}/logs" -name "*.log" -mtime +7 -delete`;
    
    const crontabPath = path.join(__dirname, 'crontab.txt');
    fs.writeFileSync(crontabPath, crontabContent, 'utf8');
    console.log(`✅ 创建crontab文件: ${crontabPath}`);
    
    return { configPath, crontabPath };
}

// 创建日志目录
function createLogDirectories() {
    console.log("\n📁 创建日志和存档目录...");
    
    const directories = [
        'logs',
        'archive/intraday',
        'archive/final',
        'archive/evolution',
        'archive/pre_market',
        'task_scripts'
    ];
    
    directories.forEach(dir => {
        const dirPath = path.join(__dirname, dir);
        if (!fs.existsSync(dirPath)) {
            fs.mkdirSync(dirPath, { recursive: true });
            console.log(`✅ 创建目录: ${dir}`);
        }
    });
}

// 创建系统状态检查脚本
function createSystemCheckScript() {
    console.log("\n🔧 创建系统检查脚本...");
    
    const checkScript = `// 系统状态检查脚本
const fs = require('fs');
const path = require('path');

console.log("🔍 A股选股系统状态检查");
console.log("=".repeat(50));

const now = new Date();
console.log(\`检查时间: \${now.toLocaleString('zh-CN')}\`);
console.log(\`北京时间: \${now.getHours().toString().padStart(2, '0')}:\${now.getMinutes().toString().padStart(2, '0')}\`);

// 检查是否为交易日
function isTradingDay(date) {
    const dayOfWeek = date.getDay();
    return dayOfWeek >= 1 && dayOfWeek <= 5;
}

console.log(\`\\n📅 交易日检查:\`);
console.log(\`  今天: \${now.toLocaleDateString('zh-CN')} (\${['日','一','二','三','四','五','六'][now.getDay()]})\`);
console.log(\`  是否交易日: \${isTradingDay(now) ? '✅ 是' : '❌ 否'}\`);

// 检查目录结构
console.log(\`\\n📁 目录结构检查:\`);

const requiredDirs = [
    'logs',
    'archive/intraday',
    'archive/final', 
    'archive/evolution',
    'archive/pre_market',
    'task_scripts'
];

let allDirsExist = true;
requiredDirs.forEach(dir => {
    const dirPath = path.join(__dirname, dir);
    const exists = fs.existsSync(dirPath);
    console.log(\`  \${dir}: \${exists ? '✅ 存在' : '❌ 缺失'}\`);
    if (!exists) allDirsExist = false;
});

// 检查脚本文件
console.log(\`\\n📝 脚本文件检查:\`);

const requiredScripts = [
    'task_scripts/task_pre_market.js',
    'task_scripts/task_intraday.js',
    'task_scripts/task_final.js',
    'task_scripts/task_review.js'
];

let allScriptsExist = true;
requiredScripts.forEach(script => {
    const scriptPath = path.join(__dirname, script);
    const exists = fs.existsSync(scriptPath);
    console.log(\`  \${script}: \${exists ? '✅ 存在' : '❌ 缺失'}\`);
    if (!exists) allScriptsExist = false;
});

// 检查日志文件
console.log(\`\\n📊 日志文件检查:\`);

const logDir = path.join(__dirname, 'logs');
if (fs.existsSync(logDir)) {
    const logs = fs.readdirSync(logDir);
    if (logs.length > 0) {
        console.log(\`  找到 \${logs.length} 个日志文件:\`);
        logs.slice(0, 5).forEach(log => {
            const logPath = path.join(logDir, log);
            const stats = fs.statSync(logPath);
            console.log(\`    • \${log} (\${(stats.size/1024).toFixed(1)}KB)\`);
        });
        if (logs.length > 5) console.log(\`    ... 还有 \${logs.length - 5} 个文件\`);
    } else {
        console.log(\`  暂无日志文件\`);
    }
} else {
    console.log(\`  ❌ 日志目录不存在\`);
}

// 检查存档数据
console.log(\`\\n📁 存档数据检查:\`);

const archiveTypes = ['intraday', 'final', 'evolution', 'pre_market'];
archiveTypes.forEach(type => {
    const archiveDir = path.join(__dirname, 'archive', type);
    if (fs.existsSync(archiveDir)) {
        const dates = fs.readdirSync(archiveDir);
        console.log(\`  \${type}: \${dates.length} 个交易日存档\`);
    } else {
        console.log(\`  \${type}: ❌ 目录不存在\`);
    }
});

// 总结
console.log(\`\\n" + "=".repeat(50));
console.log(\`📋 系统状态总结:\`);

const systemStatus = {
    trading_day: isTradingDay(now),
    directories: allDirsExist,
    scripts: allScriptsExist,
    overall: allDirsExist && allScriptsExist
};

console.log(\`  交易日状态: \${systemStatus.trading_day ? '✅ 交易日' : '❌ 非交易日'}\`);
console.log(\`  目录结构: \${systemStatus.directories ? '✅ 完整' : '❌ 不完整'}\`);
console.log(\`  脚本文件: \${systemStatus.scripts ? '✅ 完整' : '❌ 不完整'}\`);
console.log(\`  总体状态: \${systemStatus.overall ? '✅ 正常' : '❌ 异常'}\`);

if (!systemStatus.overall) {
    console.log(\`\\n⚠️  系统配置不完整，请运行 cron_tasks_setup.js 重新配置\`);
    process.exit(1);
} else {
    console.log(\`\\n✅ 系统状态正常，可以运行定时任务\`);
    process.exit(0);
}`;
    
    const checkScriptPath = path.join(__dirname, 'system_check.js');
    fs.writeFileSync(checkScriptPath, checkScript, 'utf8');
    console.log(`✅ 创建系统检查脚本: ${checkScriptPath}`);
    
    return checkScriptPath;
}

// 创建安装说明
function createInstallationGuide() {
    console.log("\n📖 创建安装说明...");
    
    const guide = `# A股