#!/usr/bin/env python3
"""
测试QQ邮箱连接
"""

import smtplib
import imaplib
import ssl
import json

# QQ邮箱配置
QQ_EMAIL = "zhangyuru999@qq.com"
QQ_PASSWORD = "yjhatgqnbailcahb"  # 授权码
SMTP_SERVER = "smtp.qq.com"
SMTP_PORT = 465
IMAP_SERVER = "imap.qq.com"
IMAP_PORT = 993

def test_imap_connection():
    """测试IMAP连接"""
    print("🔍 测试IMAP连接...")
    try:
        # 创建SSL上下文
        context = ssl.create_default_context()
        
        # 连接到IMAP服务器
        imap = imaplib.IMAP4_SSL(IMAP_SERVER, IMAP_PORT, ssl_context=context)
        print(f"✅ 已连接到 {IMAP_SERVER}:{IMAP_PORT}")
        
        # 登录
        imap.login(QQ_EMAIL, QQ_PASSWORD)
        print("✅ IMAP登录成功")
        
        # 列出邮箱文件夹
        status, folders = imap.list()
        if status == 'OK':
            print("✅ 邮箱文件夹列表:")
            for folder in folders:
                print(f"  - {folder.decode('utf-8', errors='ignore')}")
        else:
            print("❌ 无法获取文件夹列表")
        
        # 选择收件箱
        status, messages = imap.select('INBOX')
        if status == 'OK':
            print(f"✅ 收件箱中有 {messages[0].decode()} 封邮件")
        else:
            print("❌ 无法选择收件箱")
        
        # 退出
        imap.logout()
        print("✅ IMAP连接测试完成")
        return True
        
    except Exception as e:
        print(f"❌ IMAP连接失败: {e}")
        return False

def test_smtp_connection():
    """测试SMTP连接"""
    print("\n📨 测试SMTP连接...")
    try:
        # 创建SSL上下文
        context = ssl.create_default_context()
        
        # 连接到SMTP服务器
        smtp = smtplib.SMTP_SSL(SMTP_SERVER, SMTP_PORT, context=context)
        print(f"✅ 已连接到 {SMTP_SERVER}:{SMTP_PORT}")
        
        # 登录
        smtp.login(QQ_EMAIL, QQ_PASSWORD)
        print("✅ SMTP登录成功")
        
        # 测试发送简单邮件
        from email.message import EmailMessage
        import email.utils
        
        msg = EmailMessage()
        msg['From'] = QQ_EMAIL
        msg['To'] = QQ_EMAIL  # 发送给自己测试
        msg['Subject'] = "测试邮件 - OpenClaw邮箱连接测试"
        msg['Date'] = email.utils.formatdate(localtime=True)
        msg.set_content("""这是一封测试邮件，用于验证OpenClaw的email-manager技能是否能正常工作。

测试时间: 2026-04-18 01:45 GMT+8
测试系统: A股主板短线选股研究助手
测试目的: 验证QQ邮箱配置和发送功能

如果收到此邮件，说明email-manager技能配置成功！

祝好，
OpenClaw AI助手""")
        
        smtp.send_message(msg)
        print("✅ 测试邮件发送成功")
        
        # 退出
        smtp.quit()
        print("✅ SMTP连接测试完成")
        return True
        
    except Exception as e:
        print(f"❌ SMTP连接失败: {e}")
        return False

def main():
    print("🚀 QQ邮箱连接测试")
    print("=" * 50)
    
    # 读取配置文件
    config_path = r"C:\Users\kevin\.openclaw\workspace\skills\email-manager\config.json"
    try:
        with open(config_path, 'r', encoding='utf-8') as f:
            config = json.load(f)
        print(f"✅ 已读取配置文件: {config_path}")
        print(f"   邮箱地址: {config.get('email_address')}")
        print(f"   SMTP服务器: {config.get('smtp_server')}:{config.get('smtp_port')}")
        print(f"   IMAP服务器: {config.get('imap_server')}:{config.get('imap_port')}")
    except Exception as e:
        print(f"❌ 无法读取配置文件: {e}")
        config = None
    
    print("\n" + "=" * 50)
    
    # 测试连接
    imap_success = test_imap_connection()
    smtp_success = test_smtp_connection()
    
    print("\n" + "=" * 50)
    print("📊 测试结果汇总:")
    print(f"  IMAP连接: {'✅ 成功' if imap_success else '❌ 失败'}")
    print(f"  SMTP连接: {'✅ 成功' if smtp_success else '❌ 失败'}")
    
    if imap_success and smtp_success:
        print("\n🎉 所有连接测试成功！email-manager技能可以正常工作。")
        print("\n📧 接下来可以:")
        print("  1. 使用email-manager技能发送邮件")
        print("  2. 管理收件箱和文件夹")
        print("  3. 设置自动邮件通知")
        print("  4. 集成到A股选股研究报告中")
    else:
        print("\n⚠️  部分连接测试失败，请检查:")
        print("  - QQ邮箱授权码是否正确")
        print("  - 网络连接是否正常")
        print("  - QQ邮箱的SMTP/IMAP服务是否已开启")
        print("  - 防火墙或安全软件是否阻止连接")

if __name__ == '__main__':
    main()