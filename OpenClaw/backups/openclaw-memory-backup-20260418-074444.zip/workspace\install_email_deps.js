// 安装email测试所需的Node.js模块
const { execSync } = require('child_process');
const fs = require('fs');
const path = require('path');

console.log("📦 安装email测试所需的Node.js模块...");
console.log("=".repeat(50));

const modules = ['nodemailer', 'imap'];

try {
    // 检查是否已安装
    const packageJsonPath = path.join(__dirname, 'package.json');
    let packageJson = { dependencies: {} };
    
    if (fs.existsSync(packageJsonPath)) {
        packageJson = JSON.parse(fs.readFileSync(packageJsonPath, 'utf8'));
    }
    
    // 安装缺失的模块
    modules.forEach(module => {
        if (!packageJson.dependencies || !packageJson.dependencies[module]) {
            console.log(`📥 安装 ${module}...`);
            try {
                execSync(`npm install ${module} --save`, { 
                    cwd: __dirname,
                    stdio: 'inherit'
                });
                console.log(`✅ ${module} 安装成功`);
            } catch (error) {
                console.log(`❌ ${module} 安装失败: ${error.message}`);
            }
        } else {
            console.log(`✅ ${module} 已安装`);
        }
    });
    
    console.log("\n" + "=".repeat(50));
    console.log("🎉 模块安装完成！");
    console.log("\n🚀 接下来可以:");
    console.log("  1. 运行 test_email_node.js 测试邮箱连接");
    console.log("  2. 配置email-manager技能");
    console.log("  3. 发送测试邮件");
    
} catch (error) {
    console.log(`❌ 安装过程中出错: ${error.message}`);
}