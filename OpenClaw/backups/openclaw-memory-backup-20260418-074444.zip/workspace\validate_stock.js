// 严格约束验证系统 - 阶段1任务1.1
const fs = require('fs');
const path = require('path');

console.log("🎯 严格约束验证系统 v1.0");
console.log("=".repeat(70));

// 约束规则配置
const CONSTRAINT_RULES = {
    // 主板代码模式
    MAIN_BOARD: {
        SHANGHAI: /^60\d{4}$/,    // 沪市主板: 60xxxx
        SHENZHEN: /^00\d{4}$/     // 深市主板: 00xxxx
    },
    
    // 排除代码模式
    EXCLUDED: {
        STAR_MARKET: /^688\d{3}$/,   // 科创板: 688xxx
        GEM: /^300\d{3}$/,           // 创业板: 300xxx
        BEIJING: /^8\d{5}$/,         // 北交所: 8xxxxx
        B_SHARES: /^900\d{3}$/,      // B股: 900xxx
        OTHER_EXCLUDED: /^(002|003|200|730|780|580|150|159|510|511|512|513|515|518|588|1599)\d+/
    },
    
    // ST规则模式
    ST_RULES: [
        /ST/,           // ST
        /\*ST/,         // *ST
        /S\s*T/,        // S T (带空格)
        /退市/,          // 退市
        /风险警示/,      // 风险警示
        /暂停上市/,      // 暂停上市
        /终止上市/       // 终止上市
    ],
    
    // 异常数据阈值
    ABNORMAL_THRESHOLDS: {
        PRICE_CHANGE: { min: -20, max: 20 },    // 涨跌幅限制
        TURNOVER_RATE: { max: 50 },             // 换手率上限
        PE_RATIO: { min: 0, max: 500 },         // 市盈率范围
        PB_RATIO: { min: 0, max: 20 },          // 市净率范围
        MARKET_CAP: { min: 100000000 }          // 市值下限1亿
    },
    
    // 交易状态
    TRADING_STATUS: {
        NORMAL: ["正常", "交易", "上市"],
        SUSPENDED: ["停牌", "暂停", "终止", "退市"]
    }
};

// 保存约束规则到文件
function saveConstraintRules() {
    const rulesPath = path.join(__dirname, 'constraint_rules.json');
    fs.writeFileSync(rulesPath, JSON.stringify(CONSTRAINT_RULES, null, 2), 'utf8');
    console.log(`✅ 约束规则已保存: ${rulesPath}`);
    return rulesPath;
}

// 股票验证函数
function validateStock(stock) {
    const { code, name, price_change, turnover_rate, pe_ratio, pb_ratio, market_cap, status } = stock;
    
    const validation = {
        code,
        name: name || "未知",
        valid: true,
        reasons: [],
        details: {},
        market: null,
        warnings: []
    };
    
    // 1. 检查代码格式
    if (!code || typeof code !== 'string') {
        validation.valid = false;
        validation.reasons.push("代码格式错误");
        return validation;
    }
    
    // 2. 检查主板代码
    const isShanghai = CONSTRAINT_RULES.MAIN_BOARD.SHANGHAI.test(code);
    const isShenzhen = CONSTRAINT_RULES.MAIN_BOARD.SHENZHEN.test(code);
    
    if (isShanghai) {
        validation.market = "沪市主板";
        validation.details.market = "沪市主板 (60xxxx)";
    } else if (isShenzhen) {
        validation.market = "深市主板";
        validation.details.market = "深市主板 (00xxxx)";
    } else {
        // 检查排除代码
        let excludedReason = null;
        for (const [type, pattern] of Object.entries(CONSTRAINT_RULES.EXCLUDED)) {
            if (pattern.test(code)) {
                excludedReason = type;
                break;
            }
        }
        
        if (excludedReason) {
            validation.valid = false;
            validation.reasons.push(`排除类型: ${excludedReason}`);
            validation.details.excluded_type = excludedReason;
        } else {
            validation.valid = false;
            validation.reasons.push("非主板代码");
            validation.details.code_type = "非标准主板代码";
        }
        return validation;
    }
    
    // 3. 检查ST规则
    if (name) {
        let stDetected = false;
        for (const pattern of CONSTRAINT_RULES.ST_RULES) {
            if (pattern.test(name)) {
                stDetected = true;
                validation.details.st_pattern = pattern.toString();
                break;
            }
        }
        
        if (stDetected) {
            validation.valid = false;
            validation.reasons.push("ST股票");
            return validation;
        }
    }
    
    // 4. 检查代码中的ST
    if (/ST/i.test(code)) {
        validation.valid = false;
        validation.reasons.push("代码包含ST标识");
        return validation;
    }
    
    // 5. 检查交易状态
    if (status) {
        const isSuspended = CONSTRAINT_RULES.TRADING_STATUS.SUSPENDED.some(
            s => status.includes(s)
        );
        
        if (isSuspended) {
            validation.valid = false;
            validation.reasons.push("停牌或异常状态");
            validation.details.status = status;
            return validation;
        }
    }
    
    // 6. 检查异常数据
    const thresholds = CONSTRAINT_RULES.ABNORMAL_THRESHOLDS;
    
    if (price_change !== undefined) {
        if (price_change < thresholds.PRICE_CHANGE.min || price_change > thresholds.PRICE_CHANGE.max) {
            validation.valid = false;
            validation.reasons.push("涨跌幅异常");
            validation.details.price_change = price_change;
            validation.details.threshold = `${thresholds.PRICE_CHANGE.min}% 至 ${thresholds.PRICE_CHANGE.max}%`;
        }
    }
    
    if (turnover_rate !== undefined) {
        if (turnover_rate > thresholds.TURNOVER_RATE.max) {
            validation.valid = false;
            validation.reasons.push("换手率异常");
            validation.details.turnover_rate = turnover_rate;
            validation.details.threshold = `> ${thresholds.TURNOVER_RATE.max}%`;
        }
    }
    
    if (pe_ratio !== undefined) {
        if (pe_ratio < thresholds.PE_RATIO.min || pe_ratio > thresholds.PE_RATIO.max) {
            validation.warnings.push("市盈率异常");
            validation.details.pe_ratio = pe_ratio;
            validation.details.pe_threshold = `${thresholds.PE_RATIO.min} 至 ${thresholds.PE_RATIO.max}`;
        }
    }
    
    if (pb_ratio !== undefined) {
        if (pb_ratio < thresholds.PB_RATIO.min || pb_ratio > thresholds.PB_RATIO.max) {
            validation.warnings.push("市净率异常");
            validation.details.pb_ratio = pb_ratio;
            validation.details.pb_threshold = `${thresholds.PB_RATIO.min} 至 ${thresholds.PB_RATIO.max}`;
        }
    }
    
    if (market_cap !== undefined) {
        if (market_cap < thresholds.MARKET_CAP.min) {
            validation.warnings.push("市值过小");
            validation.details.market_cap = market_cap;
            validation.details.min_market_cap = thresholds.MARKET_CAP.min;
        }
    }
    
    return validation;
}

// 批量验证函数
function validateStocks(stocks) {
    console.log(`\n🔍 批量验证 ${stocks.length} 只股票:`);
    console.log("=".repeat(70));
    
    const results = {
        total: stocks.length,
        passed: 0,
        failed: 0,
        warnings: 0,
        details: []
    };
    
    stocks.forEach((stock, index) => {
        const validation = validateStock(stock);
        results.details.push(validation);
        
        if (validation.valid) {
            results.passed++;
            const warningText = validation.warnings.length > 0 ? ` (警告: ${validation.warnings.length})` : '';
            console.log(`✅ ${index+1}. ${stock.code} ${stock.name}: 通过${warningText}`);
        } else {
            results.failed++;
            console.log(`❌ ${index+1}. ${stock.code} ${stock.name}: ${validation.reasons.join(', ')}`);
        }
        
        if (validation.warnings.length > 0) {
            results.warnings++;
        }
    });
    
    return results;
}

// 生成验证报告
function generateValidationReport(results) {
    const report = {
        timestamp: new Date().toISOString(),
        summary: {
            total_stocks: results.total,
            passed_stocks: results.passed,
            failed_stocks: results.failed,
            warning_stocks: results.warnings,
            pass_rate: ((results.passed / results.total) * 100).toFixed(1) + '%',
            failure_reasons: {}
        },
        details: results.details.map(v => ({
            code: v.code,
            name: v.name,
            valid: v.valid,
            reasons: v.reasons,
            warnings: v.warnings,
            market: v.market
        }))
    };
    
    // 统计失败原因
    results.details.forEach(v => {
        if (!v.valid) {
            v.reasons.forEach(reason => {
                report.summary.failure_reasons[reason] = (report.summary.failure_reasons[reason] || 0) + 1;
            });
        }
    });
    
    return report;
}

// 测试数据
const testStocks = [
    { code: "600519", name: "贵州茅台", price_change: 2.5, turnover_rate: 0.8, status: "正常" },
    { code: "000858", name: "五粮液", price_change: 1.8, turnover_rate: 1.2, status: "正常" },
    { code: "688981", name: "中芯国际", price_change: 3.2, turnover_rate: 2.5, status: "正常" },
    { code: "300750", name: "宁德时代", price_change: -1.5, turnover_rate: 1.8, status: "正常" },
    { code: "000002", name: "万科A", price_change: 0.5, turnover_rate: 0.9, status: "正常" },
    { code: "600123", name: "ST兰花", price_change: 5.2, turnover_rate: 3.5, status: "正常" },
    { code: "000001", name: "平安银行", price_change: 1.2, turnover_rate: 0.7, status: "正常" },
    { code: "600036", name: "招商银行", price_change: 0.8, turnover_rate: 0.6, status: "正常" },
    { code: "000333", name: "美的集团", price_change: 1.5, turnover_rate: 0.9, status: "正常" },
    { code: "600276", name: "恒瑞医药", price_change: -0.5, turnover_rate: 1.1, status: "正常" },
    { code: "830000", name: "北交所测试", price_change: 10.5, turnover_rate: 15.2, status: "正常" },
    { code: "900901", name: "B股测试", price_change: 2.1, turnover_rate: 1.8, status: "正常" },
    { code: "002415", name: "海康威视", price_change: 1.8, turnover_rate: 1.5, status: "正常" },
    { code: "600***ST", name: "代码ST测试", price_change: 8.5, turnover_rate: 12.3, status: "正常" },
    { code: "000858", name: "*ST测试股", price_change: -5.2, turnover_rate: 8.7, status: "停牌" },
    { code: "600999", name: "招商证券", price_change: 25.5, turnover_rate: 3.2, status: "正常" },
    { code: "000001", name: "平安银行", price_change: 1.2, turnover_rate: 55.8, status: "正常" },
    { code: "600000", name: "浦发银行", price_change: 0.3, turnover_rate: 0.4, pe_ratio: -5, status: "正常" },
    { code: "000063", name: "中兴通讯", price_change: 1.8, turnover_rate: 2.1, market_cap: 50000000, status: "正常" }
];

// 主函数
function main() {
    console.log("🚀 严格约束验证系统启动");
    console.log("=".repeat(70));
    
    // 1. 保存约束规则
    const rulesPath = saveConstraintRules();
    
    // 2. 显示约束规则
    console.log("\n📋 约束规则配置:");
    console.log("=".repeat(70));
    console.log(`主板代码: 60xxxx (沪市), 00xxxx (深市)`);
    console.log(`排除代码: 科创板688, 创业板300, 北交所8, B股900等`);
    console.log(`ST规则: ${CONSTRAINT_RULES.ST_RULES.length} 个检测模式`);
    console.log(`异常阈值: 涨跌幅±20%, 换手率<50%, 市值>1亿`);
    
    // 3. 执行批量验证
    const results = validateStocks(testStocks);
    
    // 4. 生成报告
    const report = generateValidationReport(results);
    
    console.log("\n" + "=".repeat(70));
    console.log("📊 验证结果汇总:");
    console.log("=".repeat(70));
    
    console.log(`总股票数: ${report.summary.total_stocks}`);
    console.log(`通过数: ${report.summary.passed_stocks}`);
    console.log(`失败数: ${report.summary.failed_stocks}`);
    console.log(`警告数: ${report.summary.warning_stocks}`);
    console.log(`通过率: ${report.summary.pass_rate}`);
    
    if (Object.keys(report.summary.failure_reasons).length > 0) {
        console.log(`\n❌ 失败原因分布:`);
        Object.entries(report.summary.failure_reasons).forEach(([reason, count]) => {
            console.log(`  ${reason}: ${count} 次`);
        });
    }
    
    // 5. 保存验证报告
    const reportPath = path.join(__dirname, 'validation_report.json');
    fs.writeFileSync(reportPath, JSON.stringify(report, null, 2), 'utf8');
    console.log(`\n✅ 验证报告已保存: ${reportPath}`);
    
    // 6. 更新系统状态
    updateSystemState(results, reportPath);
    
    console.log("\n" + "=".repeat(70));
    console.log("🎉 严格约束验证系统测试完成!");
    console.log("=".repeat(70));
    
    console.log("\n📈 系统性能:");
    console.log(`  ✅ 规则配置: ${Object.keys(CONSTRAINT_RULES).length} 类约束规则`);
    console.log(`  ✅ 检测能力: ${CONSTRAINT_RULES.ST_RULES.length} 个ST检测模式`);
    console.log(`  ✅ 验证速度: 批量验证 ${testStocks.length} 只股票`);
    console.log(`  ✅ 准确率: ${report.summary.pass_rate} 通过率`);
    
    console.log("\n🚀 下一步:");
    console.log("  1. 集成到选股工作流中");
    console.log("  2. 连接实时数据源验证");
    console.log("  3. 优化验证性能和准确性");
    console.log("  4. 建立异常数据监控");
    
    return {
        success: true,
        rules_path: rulesPath,
        report_path: reportPath,
        results: report.summary
    };
}

// 更新系统状态
function updateSystemState(results, reportPath) {
    const sessionStatePath = path.join(__dirname, 'SESSION-STATE.md');
    
    if (fs.existsSync(sessionStatePath)) {
        let content = fs.readFileSync(sessionStatePath, 'utf8');
        
        const validationUpdate = `\n\n## ✅ 阶段1任务1.1完成: 严格约束验证系统 (${new Date().toLocaleString('zh-CN')})

### 系统功能
- **主板验证:** 60xxxx (沪市), 00xxxx (深市)
- **排除检测:** 科创板688、创业板300、北交所8、B股900等
- **ST检测:** ${CONSTRAINT_RULES.ST_RULES.length} 个检测模式
- **异常过滤:** 涨跌幅、换手率、市值等阈值控制
- **状态检查:** 停牌、退市等异常状态识别

### 测试结果
- **测试股票:** ${results.total} 只
- **通过验证:** ${results.passed} 只 (${((results.passed/results.total)*100).toFixed(1)}%)
- **失败排除:** ${results.failed} 只
- **警告提示:** ${results.warnings} 只

### 失败原因分布
${Object.entries(report.summary.failure_reasons).map(([reason, count]) => `