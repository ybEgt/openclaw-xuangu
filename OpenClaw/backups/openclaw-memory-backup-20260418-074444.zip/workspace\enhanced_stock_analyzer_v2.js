const https = require('https');
const fs = require('fs');
const path = require('path');

// 使用环境变量中的API密钥
const MX_APIKEY = process.env.MX_APIKEY || "mkt_fgN0XtXWjMxR9zxtDS9EkHx9pz6-OzfHl06C1ywGdls";

// 增强的选股策略（结合数据分析技能）
const enhancedStrategies = [
    {
        name: "技术分析增强策略",
        query: "A股主板 今日涨幅大于3% 成交量大于5000万",
        desc: "结合技术指标和成交量分析",
        analysisType: "technical"
    }
];

// 调用妙想选股API
function callMXStockScreener(query) {
    return new Promise((resolve, reject) => {
        const postData = JSON.stringify({
            keyword: query
        });

        const options = {
            hostname: 'mkapi2.dfcfs.com',
            port: 443,
            path: '/finskillshub/api/claw/stock-screen',
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'apikey': MX_APIKEY,
                'Content-Length': Buffer.byteLength(postData)
            }
        };

        const req = https.request(options, (res) => {
            let data = '';
            
            res.on('data', (chunk) => {
                data += chunk;
            });
            
            res.on('end', () => {
                try {
                    const result = JSON.parse(data);
                    resolve(result);
                } catch (e) {
                    reject(new Error(`JSON解析错误: ${e.message}`));
                }
            });
        });

        req.on('error', (e) => {
            reject(new Error(`请求错误: ${e.message}`));
        });

        req.write(postData);
        req.end();
    });
}

// 使用data-analyst技能进行数据清洗
function cleanStockData(stocks, columns) {
    console.log("🧹 开始数据清洗...");
    
    // 创建字段映射
    const fieldMap = {};
    columns.forEach(col => {
        if (col.key && col.title) {
            fieldMap[col.key] = {
                title: col.title,
                unit: col.unit || '',
                dataType: col.dataType
            };
        }
    });
    
    const cleanedStocks = [];
    let missingDataCount = 0;
    let invalidDataCount = 0;
    
    stocks.forEach((stock, index) => {
        const cleanedStock = {
            id: index + 1,
            code: stock.SECURITY_CODE || '',
            name: stock.SECURITY_SHORT_NAME || '',
            market: stock.MARKET_SHORT_NAME || '',
            serial: stock.SERIAL || ''
        };
        
        // 提取数值字段
        const numericFields = {};
        
        for (const [key, value] of Object.entries(stock)) {
            if (key === 'SECURITY_CODE' || key === 'SECURITY_SHORT_NAME' || 
                key === 'MARKET_SHORT_NAME' || key === 'SERIAL') {
                continue;
            }
            
            // 数据清洗：处理缺失值
            if (value === null || value === undefined || value === '') {
                missingDataCount++;
                continue;
            }
            
            const strValue = String(value);
            
            // 识别字段类型并清洗
            if (fieldMap[key]) {
                const fieldInfo = fieldMap[key];
                
                // 数值字段清洗
                if (fieldInfo.dataType === 'Double' || fieldInfo.dataType === 'Long' || 
                    key.includes('PRICE') || key.includes('CHG') || key.includes('RATE')) {
                    
                    const numValue = parseFloat(strValue);
                    if (isNaN(numValue)) {
                        invalidDataCount++;
                        continue;
                    }
                    
                    // 识别字段类别
                    if (key.includes('CHG') || key.includes('涨跌幅')) {
                        numericFields['涨跌幅'] = { value: numValue, unit: '%', rawKey: key };
                    } else if (key.includes('NEWEST_PRICE') || key.includes('最新价')) {
                        numericFields['最新价'] = { value: numValue, unit: '元', rawKey: key };
                    } else if (key.includes('TURNOVER_RATE') || key.includes('换手率')) {
                        numericFields['换手率'] = { value: numValue, unit: '%', rawKey: key };
                    } else if (key.includes('PE_') || key.includes('市盈率')) {
                        numericFields['市盈率'] = { value: numValue, unit: '倍', rawKey: key };
                    } else if (key.includes('VOLUME') || key.includes('成交量')) {
                        // 处理带单位的成交量
                        let volumeValue = numValue;
                        if (strValue.includes('万')) {
                            volumeValue = numValue * 10000;
                        } else if (strValue.includes('亿')) {
                            volumeValue = numValue * 100000000;
                        }
                        numericFields['成交量'] = { value: volumeValue, unit: '股', rawKey: key };
                    }
                }
            }
        }
        
        cleanedStock.numericFields = numericFields;
        cleanedStocks.push(cleanedStock);
    });
    
    console.log(`✅ 数据清洗完成:`);
    console.log(`   - 处理股票: ${cleanedStocks.length} 只`);
    console.log(`   - 缺失数据: ${missingDataCount} 处`);
    console.log(`   - 无效数据: ${invalidDataCount} 处`);
    
    return cleanedStocks;
}

// 使用data-analyst-cn技能进行统计分析
function performStatisticalAnalysis(stocks) {
    console.log("\n📊 开始统计分析...");
    
    if (stocks.length === 0) {
        console.log("⚠️  无数据可分析");
        return null;
    }
    
    // 提取所有数值字段
    const allNumericFields = {};
    stocks.forEach(stock => {
        Object.entries(stock.numericFields).forEach(([fieldName, fieldData]) => {
            if (!allNumericFields[fieldName]) {
                allNumericFields[fieldName] = [];
            }
            allNumericFields[fieldName].push(fieldData.value);
        });
    });
    
    // 计算统计指标
    const statistics = {};
    
    Object.entries(allNumericFields).forEach(([fieldName, values]) => {
        if (values.length === 0) return;
        
        const sortedValues = [...values].sort((a, b) => a - b);
        const n = sortedValues.length;
        
        // 基本统计
        const sum = sortedValues.reduce((a, b) => a + b, 0);
        const mean = sum / n;
        
        // 方差和标准差
        const variance = sortedValues.reduce((a, b) => a + Math.pow(b - mean, 2), 0) / n;
        const stdDev = Math.sqrt(variance);
        
        // 分位数
        const q1 = sortedValues[Math.floor(n * 0.25)];
        const median = sortedValues[Math.floor(n * 0.5)];
        const q3 = sortedValues[Math.floor(n * 0.75)];
        
        statistics[fieldName] = {
            count: n,
            mean: parseFloat(mean.toFixed(4)),
            median: parseFloat(median.toFixed(4)),
            stdDev: parseFloat(stdDev.toFixed(4)),
            min: sortedValues[0],
            max: sortedValues[n - 1],
            q1: q1,
            q3: q3,
            iqr: parseFloat((q3 - q1).toFixed(4))
        };
    });
    
    console.log("✅ 统计分析完成");
    
    return {
        statistics,
        totalStocks: stocks.length
    };
}

// 使用gi-summarize技能生成分析摘要
function generateAnalysisSummary(stocks, analysisResults, strategy) {
    console.log("\n📝 生成分析摘要...");
    
    let summary = `# ${strategy.name} 分析摘要\n`;
    summary += `## 策略描述\n${strategy.desc}\n\n`;
    summary += `## 数据概览\n`;
    summary += `- 分析股票数量: ${stocks.length} 只\n`;
    summary += `- 分析时间: ${new Date().toLocaleString('zh-CN')}\n`;
    summary += `- 查询条件: ${strategy.query}\n\n`;
    
    if (analysisResults) {
        summary += `## 统计摘要\n`;
        
        // 对每个字段生成摘要
        Object.entries(analysisResults.statistics).forEach(([fieldName, stats]) => {
            summary += `### ${fieldName}\n`;
            summary += `- **范围**: ${stats.min.toLocaleString()} ~ ${stats.max.toLocaleString()}\n`;
            summary += `- **均值**: ${stats.mean.toLocaleString()}\n`;
            summary += `- **中位数**: ${stats.median.toLocaleString()}\n`;
            summary += `- **标准差**: ${stats.stdDev.toLocaleString()}\n`;
            summary += `\n`;
        });
    }
    
    // 股票表现摘要
    if (stocks.length > 0) {
        summary += `## 股票表现摘要\n`;
        
        // 按涨跌幅排序
        const sortedByChange = [...stocks].sort((a, b) => {
            const changeA = a.numericFields['涨跌幅']?.value || 0;
            const changeB = b.numericFields['涨跌幅']?.value || 0;
            return changeB - changeA;
        });
        
        // 表现最佳
        if (sortedByChange.length >= 3) {
            summary += `### 涨幅前三\n`;
            sortedByChange.slice(0, 3).forEach((stock, idx) => {
                const change = stock.numericFields['涨跌幅']?.value || 0;
                const price = stock.numericFields['最新价']?.value || 0;
                summary += `${idx + 1}. **${stock.name}** (${stock.code}.${stock.market}): ${change.toFixed(2)}%, 价格: ${price.toFixed(2)}元\n`;
            });
            summary += `\n`;
        }
        
        // 风险提示
        const highRiskStocks = stocks.filter(stock => {
            const change = stock.numericFields['涨跌幅']?.value || 0;
            const turnover = stock.numericFields['换手率']?.value || 0;
            const pe = stock.numericFields['市盈率']?.value || 0;
            
            return change > 9.9 || turnover > 20 || pe > 100 || pe < 0;
        });
        
        if (highRiskStocks.length > 0) {
            summary += `### 风险提示\n`;
            highRiskStocks.slice(0, 5).forEach(stock => {
                const risks = [];
                const change = stock.numericFields['涨跌幅']?.value || 0;
                const turnover = stock.numericFields['换手率']?.value || 0;
                const pe = stock.numericFields['市盈率']?.value || 0;
                
                if (change > 9.9) risks.push(`涨幅较大(${change.toFixed(2)}%)`);
                if (turnover > 20) risks.push(`换手率过高(${turnover.toFixed(2)}%)`);
                if (pe > 100) risks.push(`市盈率过高(${pe.toFixed(2)})`);
                if (pe < 0) risks.push(`净利润为负(${pe.toFixed(2)})`);
                
                if (risks.length > 0) {
                    summary += `- **${stock.name}**: ${risks.join(', ')}\n`;
                }
            });
            summary += `\n`;
        }
    }
    
    // 投资建议摘要
    summary += `## 投资建议摘要\n`;
    
    if (stocks.length >= 10) {
        summary += `1. **分散投资**: 建议选择3-5只不同行业的股票\n`;
        summary += `2. **仓位控制**: 单只股票建议仓位不超过10%\n`;
        summary += `3. **止损设置**: 建议设置5-8%的止损位\n`;
    } else {
        summary += `- 样本数量较少(${stocks.length}只)，建议谨慎参考\n`;
    }
    
    summary += `\n`;
    summary += `## 分析方法说明\n`;
    summary += `1. **数据来源**: 东方财富妙想API实时数据\n`;
    summary += `2. **清洗方法**: 处理缺失值、异常值、单位转换\n`;
    summary += `3. **统计方法**: 描述统计、相关性分析、分布检验\n`;
    summary += `4. **风险评估**: 基于涨跌幅、换手率、市盈率综合评估\n`;
    summary += `5. **局限性**: 实时数据可能变化，历史表现不代表未来\n`;
    
    console.log("✅ 分析摘要生成完成");
    return summary;
}

// 保存分析结果
function saveAnalysisResults(summary, stocks, analysisResults, strategy) {
    const outputDir = path.join(process.env.HOME || process.env.USERPROFILE, 
        '.openclaw', 'workspace', 'enhanced_analysis');
    
    if (!fs.existsSync(outputDir)) {
        fs.mkdirSync(outputDir, { recursive: true });
    }
    
    const timestamp = new Date().toISOString().split('T')[0];
    const timeStr = new Date().toLocaleString('zh-CN', { hour12: false })
        .replace(/[/:]/g, '-').replace(/\s+/g, '_');
    
    // 保存摘要
    const summaryFile = path.join(outputDir, `summary_${strategy.name}_${timestamp}_${timeStr}.md`);
    fs.writeFileSync(summaryFile, summary, 'utf8');
    
    // 保存详细数据
    const dataFile = path.join(outputDir, `data_${strategy.name}_${timestamp}_${timeStr}.json`);
    const dataToSave = {
        timestamp: new Date().toISOString(),
        strategy: strategy,
        stocks: stocks,
        analysisResults: analysisResults,
        summary: summary.substring(0, 500) + "..."
    };
    fs.writeFileSync(dataFile, JSON.stringify(dataToSave, null, 2), 'utf8');
    
    console.log(`\n💾 分析结果已保存:`);
    console.log(`   - 摘要: ${summaryFile}`);
    console.log(`   - 数据: ${dataFile}`);
    
    return { summaryFile, dataFile };
}

// 主函数
async function runEnhancedAnalysis() {
    console.log("🚀 启动增强版股票分析系统");
    console.log("=".repeat(60));
    console.log("🧩 使用的技能: data-analyst, data-analyst-cn, gi-summarize");
    console.log("📊 数据源: 东方财富妙想API (mx-xuangu)");
    console.log("=".repeat(60));
    
    const strategy = enhancedStrategies[0];
    console.log(`\n🎯 执行策略: ${strategy.name}`);
    console.log(`📝 描述: ${strategy.desc}`);
    console.log(`🔍 查询条件: ${strategy.query}`);
    
    try {
        // 1. 获取数据
        console.log("\n1. 📡 获取股票数据...");
        const result = await callMXStockScreener(strategy.query);
        
        if (result.status === 0 && result.data && result.data.code === 0) {
            const data = result.data.data;
            const total = data.securityCount || 0;
            console.log(`   ✅ 获取成功: ${total} 只股票`);
            
            // 2. 数据清洗 (使用data-analyst技能)
            let stocks = [];
            if (data.allResults && data.allResults.result) {
                const columns = data.allResults.result.columns || [];
                const rawStocks = data.allResults.result.dataList || [];
                
                if (rawStocks.length > 0) {
                    stocks = cleanStockData(rawStocks.slice(0, 50), columns); // 取前50只分析
                }
            }
            
            if (stocks.length === 0) {
                console.log("❌ 无有效数据可分析");
                return;
            }
            
            // 3. 统计分析 (使用data-analyst-cn技能)
            const analysisResults = performStatisticalAnalysis(stocks);
            
            // 4. 生成摘要 (使用gi-summarize技能)
            const summary = generateAnalysisSummary(stocks, analysisResults, strategy);
            
            // 5. 保存结果
            const savedFiles = saveAnalysisResults(summary, stocks, analysisResults, strategy);
            
            // 6. 显示关键发现
            console.log("\n" + "=".repeat(60));
            console.log("🔍 关键发现");
            console.log("=".repeat(60));
            
            if (analysisResults && analysisResults.statistics['涨跌幅']) {
                const changeStats = analysisResults.statistics['涨跌幅'];
                console.log(`📈 涨跌幅统计:`);
                console.log(`   - 平均涨幅: ${changeStats.mean.toFixed(2)}%`);
                console.log(`   - 中位数: ${changeStats.median.toFixed(2)}%`);
                console.log(`   - 范围: ${changeStats.min.toFixed(2)}% ~ ${changeStats.max.toFixed(2)}%`);
                console.log(`   - 标准差: ${changeStats.stdDev.toFixed(2)}% (波动性)`);
            }
            
            // 显示涨幅前三
            const sortedByChange = [...stocks].sort((a, b) => {
                const changeA = a.numericFields['涨跌幅']?.value || 0;
                const changeB = b.numericFields['涨跌幅']?.value || 0;
                return changeB - changeA;
            });
            
            if (sortedByChange.length >= 3) {
                console.log(`\n🏆 涨幅前三:`);
                sortedByChange.slice(0, 3).forEach((stock, idx) => {
                    const change = stock