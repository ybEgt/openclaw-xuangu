// 修复的mx-xuangu API测试
console.log("📡 修复的mx-xuangu API测试");
console.log("=".repeat(70));

const fs = require('fs');
const path = require('path');
const https = require('https');

// API配置
const API_CONFIG = {
    endpoint: "https://mkapi2.dfcfs.com/finskillshub/api/claw/stock-screen",
    apiKey: "mkt_fgN0XtXWjMxR9zxtDS9EkHx9pz6-OzfHl06C1ywGdls",
    timeout: 15000
};

// 获取API密钥
function getApiKey() {
    // 优先使用环境变量
    if (process.env.MX_APIKEY) {
        console.log(`✅ 使用环境变量API密钥`);
        return process.env.MX_APIKEY;
    }
    
    console.log(`⚠️  使用配置文件API密钥`);
    return API_CONFIG.apiKey;
}

// 构建简单测试条件
function buildTestConditions() {
    return {
        conditions: [
            {
                field: "code",
                operator: "regex",
                value: "^(60|00)"
            }
        ],
        sort: [
            {
                field: "change",
                order: "desc"
            }
        ],
        limit: 5,
        fields: ["code", "name", "price", "change"]
    };
}

// 发送测试请求
async function testApiConnection() {
    console.log("🔍 测试API连接...");
    
    const apiKey = getApiKey();
    if (!apiKey) {
        throw new Error("未找到API密钥");
    }
    
    const conditions = buildTestConditions();
    const postData = JSON.stringify({
        conditions: conditions,
        api_key: apiKey,
        timestamp: Date.now()
    });
    
    return new Promise((resolve, reject) => {
        const options = {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'Content-Length': Buffer.byteLength(postData)
            },
            timeout: API_CONFIG.timeout
        };
        
        console.log(`📤 发送请求到: ${API_CONFIG.endpoint}`);
        console.log(`🔑 API密钥: ${apiKey.substring(0, 15)}...`);
        console.log(`📦 请求数据: ${postData.substring(0, 100)}...`);
        
        const req = https.request(API_CONFIG.endpoint, options, (res) => {
            console.log(`📥 收到响应: 状态码 ${res.statusCode}`);
            console.log(`响应头: ${JSON.stringify(res.headers)}`);
            
            let data = '';
            res.on('data', (chunk) => {
                data += chunk;
            });
            
            res.on('end', () => {
                console.log(`📄 响应大小: ${data.length} 字节`);
                
                try {
                    const result = JSON.parse(data);
                    console.log(`✅ 响应解析成功`);
                    resolve(result);
                } catch (error) {
                    console.error(`❌ 响应解析失败: ${error.message}`);
                    console.log(`原始响应前200字符: ${data.substring(0, 200)}`);
                    reject(new Error(`响应解析失败: ${error.message}`));
                }
            });
        });
        
        req.on('error', (error) => {
            console.error(`❌ 网络错误: ${error.message}`);
            reject(new Error(`网络错误: ${error.message}`));
        });
        
        req.on('timeout', () => {
            console.error(`❌ 请求超时`);
            req.destroy();
            reject(new Error('请求超时'));
        });
        
        req.write(postData);
        req.end();
    });
}

// 主函数
async function main() {
    console.log("🚀 开始API连接测试...");
    console.log("=".repeat(70));
    
    try {
        const result = await testApiConnection();
        
        console.log("\n✅ API连接测试成功!");
        console.log("=".repeat(70));
        
        console.log(`📊 API响应结构:`);
        console.log(`   类型: ${typeof result}`);
        console.log(`   键: ${Object.keys(result).join(', ')}`);
        
        if (result.data && Array.isArray(result.data)) {
            console.log(`\n📈 收到 ${result.data.length} 只股票数据:`);
            
            result.data.slice(0, 3).forEach((stock, index) => {
                console.log(`\n${index + 1}. ${stock.code || 'N/A'} ${stock.name || 'N/A'}`);
                console.log(`   价格: ${stock.price || 'N/A'}`);
                console.log(`   涨跌: ${stock.change || 'N/A'}%`);
            });
        }
        
        // 保存结果
        const timestamp = new Date().toISOString().replace(/[:.]/g, '-');
        const testDir = path.join(__dirname, 'api_tests');
        if (!fs.existsSync(testDir)) {
            fs.mkdirSync(testDir, { recursive: true });
        }
        
        const filepath = path.join(testDir, `success_${timestamp}.json`);
        fs.writeFileSync(filepath, JSON.stringify(result, null, 2), 'utf8');
        
        console.log(`\n💾 结果已保存: ${filepath}`);
        
        // 更新系统状态
        updateSystemState(true, result.data?.length || 0);
        
        return {
            success: true,
            stock_count: result.data?.length || 0,
            file: filepath
        };
        
    } catch (error) {
        console.error(`\n❌ API测试失败: ${error.message}`);
        
        // 保存错误
        const errorDir = path.join(__dirname, 'api_tests', 'errors');
        if (!fs.existsSync(errorDir)) {
            fs.mkdirSync(errorDir, { recursive: true });
        }
        
        const errorFile = path.join(errorDir, `error_${Date.now()}.json`);
        fs.writeFileSync(errorFile, JSON.stringify({
            timestamp: new Date().toISOString(),
            error: error.message,
            stack: error.stack
        }, null, 2), 'utf8');
        
        console.log(`📝 错误报告已保存: ${errorFile}`);
        
        updateSystemState(false, 0, error.message);
        
        return {
            success: false,
            error: error.message,
            errorFile: errorFile
        };
    }
}

// 更新系统状态
function updateSystemState(success, stockCount, error = null) {
    const sessionStatePath = path.join(__dirname, 'SESSION-STATE.md');
    
    if (fs.existsSync(sessionStatePath)) {
        let content = fs.readFileSync(sessionStatePath, 'utf8');
        
        const update = `\n\n## 📡 mx-xuangu API连接测试结果 (${new Date().toLocaleString('zh-CN')})

### 测试状态
${success ? '✅ **连接成功**' : '❌ **连接失败**'}

${success ? `
**成功详情:**
- API端点: ${API_CONFIG.endpoint}
- 测试时间: ${new Date().toLocaleString('zh-CN')}
- 收到数据: ${stockCount} 只股票
- 密钥状态: 有效

**下一步:**
1. 完善选股条件
2. 集成到主系统
3. 开始真实数据选股
` : `
**失败详情:**
- 错误信息: ${error}
- API端点: ${API_CONFIG.endpoint}
- 测试时间: ${new Date().toLocaleString('zh-CN')}

**解决方案:**
1. 检查API密钥格式
2. 验证网络连接
3. 确认API服务状态
`}`;
        
        content += update;
        fs.writeFileSync(sessionStatePath, content, 'utf8');
        
        console.log(`✅ 系统状态已更新`);
    }
}

// 运行测试
main().then(result => {
    console.log("\n" + "=".repeat(70));
    console.log("📋 最终结果:");
    console.log(`   成功: ${result.success ? '✅ 是' : '❌ 否'}`);
    
    if (result.success) {
        console.log(`   股票数量: ${result.stock_count}`);
        console.log(`   结果文件: ${result.file}`);
        console.log("\n🚀 API连接正常，可以开始真实数据选股!");
    } else {
        console.log(`   错误: ${result.error}`);
        console.log(`   错误文件: ${result.errorFile}`);
        console.log("\n⚠️  需要解决API连接问题");
    }
    
    process.exit(result.success ? 0 : 1);
});