// 阶段1剩余任务完成 - 数据质量、主力分析、多维度验证
console.log("🚀 阶段1剩余任务完成");
console.log("=".repeat(70));

const fs = require('fs');
const path = require('path');

// 1. 数据质量保障系统
console.log("\n📊 任务1.2: 数据质量保障系统");
console.log("-".repeat(50));

function createDataQualitySystem() {
    console.log("🔍 创建数据质量保障系统...");
    
    const dataQualityRules = {
        // 数据完整性检查
        completeness: {
            required_fields: ["code", "name", "price", "change", "volume", "turnover", "market_cap"],
            min_price: 0.01, // 最低价格
            max_price: 10000, // 最高价格
            min_volume: 100, // 最低成交量(手)
            max_change: 20, // 最大涨跌幅(±20%)
            min_market_cap: 100000000 // 最低市值(1亿)
        },
        
        // 数据一致性检查
        consistency: {
            price_volume_ratio: 0.8, // 价格-成交量相关性阈值
            change_turnover_ratio: 0.6, // 涨跌-换手率相关性阈值
            time_consistency: true // 时间序列一致性
        },
        
        // 异常值检测
        outlier_detection: {
            price_zscore: 3, // 价格Z-score阈值
            volume_zscore: 3, // 成交量Z-score阈值
            change_zscore: 3, // 涨跌幅Z-score阈值
            iqr_multiplier: 1.5 // IQR倍数
        },
        
        // 数据清洗规则
        cleaning_rules: {
            remove_duplicates: true,
            fill_missing: "linear", // 线性插值填充
            normalize_outliers: "winsorize", // 缩尾处理
            validate_codes: true // 验证股票代码格式
        }
    };
    
    // 数据质量检查函数
    function checkDataQuality(stockData) {
        const issues = [];
        const warnings = [];
        
        // 1. 完整性检查
        dataQualityRules.completeness.required_fields.forEach(field => {
            if (!stockData.hasOwnProperty(field) || stockData[field] === null || stockData[field] === undefined) {
                issues.push(`缺失字段: ${field}`);
            }
        });
        
        // 2. 范围检查
        if (stockData.price < dataQualityRules.completeness.min_price) {
            issues.push(`价格异常低: ${stockData.price}`);
        }
        if (stockData.price > dataQualityRules.completeness.max_price) {
            issues.push(`价格异常高: ${stockData.price}`);
        }
        if (Math.abs(stockData.change) > dataQualityRules.completeness.max_change) {
            warnings.push(`涨跌幅过大: ${stockData.change}%`);
        }
        if (stockData.market_cap < dataQualityRules.completeness.min_market_cap) {
            warnings.push(`市值过小: ${stockData.market_cap}`);
        }
        
        // 3. 逻辑一致性检查
        if (stockData.volume > 0 && stockData.turnover === 0) {
            warnings.push(`成交量>0但换手率为0`);
        }
        if (stockData.change > 10 && stockData.volume < 10000) {
            warnings.push(`大涨但成交量低`);
        }
        
        return {
            passed: issues.length === 0,
            issues: issues,
            warnings: warnings,
            score: Math.max(0, 100 - issues.length * 20 - warnings.length * 5)
        };
    }
    
    // 数据清洗函数
    function cleanStockData(stockData) {
        const cleaned = { ...stockData };
        
        // 处理缺失值
        if (cleaned.price === null || cleaned.price === undefined) {
            cleaned.price = 0;
        }
        if (cleaned.change === null || cleaned.change === undefined) {
            cleaned.change = 0;
        }
        
        // 处理异常值（缩尾处理）
        if (Math.abs(cleaned.change) > 20) {
            cleaned.change = cleaned.change > 0 ? 20 : -20;
        }
        if (cleaned.turnover > 100) {
            cleaned.turnover = 100;
        }
        
        // 标准化字段
        cleaned.code = cleaned.code.toString().padStart(6, '0');
        cleaned.name = cleaned.name.trim();
        
        return cleaned;
    }
    
    // 批量检查函数
    function batchQualityCheck(stocks) {
        const results = {
            total: stocks.length,
            passed: 0,
            failed: 0,
            warnings: 0,
            details: []
        };
        
        stocks.forEach((stock, index) => {
            const quality = checkDataQuality(stock);
            const cleaned = cleanStockData(stock);
            
            results.details.push({
                code: stock.code,
                name: stock.name,
                quality: quality,
                cleaned: cleaned
            });
            
            if (quality.passed) {
                results.passed++;
            } else {
                results.failed++;
            }
            
            results.warnings += quality.warnings.length;
        });
        
        results.pass_rate = (results.passed / results.total * 100).toFixed(1);
        
        return results;
    }
    
    // 保存配置
    const configPath = path.join(__dirname, 'data_quality_config.json');
    fs.writeFileSync(configPath, JSON.stringify(dataQualityRules, null, 2), 'utf8');
    
    console.log(`✅ 数据质量保障系统创建完成`);
    console.log(`   配置文件: ${configPath}`);
    console.log(`   检查规则: ${Object.keys(dataQualityRules).length}类`);
    
    return {
        checkDataQuality,
        cleanStockData,
        batchQualityCheck,
        rules: dataQualityRules
    };
}

// 2. 主力资金分析框架
console.log("\n💰 任务1.3: 主力资金分析框架");
console.log("-".repeat(50));

function createCapitalFlowSystem() {
    console.log("🔍 创建主力资金分析框架...");
    
    const capitalFlowRules = {
        // 主力资金识别
        identification: {
            min_amount: 500000, // 单笔最小金额(元)
            min_ratio: 0.3, // 占当日成交额最小比例
            time_windows: ["09:30-10:00", "10:00-10:30", "13:00-13:30", "14:30-15:00"]
        },
        
        // 主力意图分析
        intention_analysis: {
            // 建仓特征
            accumulation: {
                continuous_days: 3, // 连续流入天数
                avg_inflow_ratio: 0.2, // 平均流入比例
                price_change_range: [-5, 5] // 价格变动范围
            },
            
            // 准备拉升特征
            preparing: {
                inflow_acceleration: 0.3, // 流入加速比例
                volume_increase: 0.5, // 成交量增加比例
                price_consolidation: true // 价格整理
            },
            
            // 已经拉升特征
            lifting: {
                price_increase: 5, // 价格上涨幅度
                inflow_persistent: true, // 持续流入
                volume_expansion: 0.8 // 成交量放大比例
            },
            
            // 一日游特征
            day_trading: {
                inflow_concentration: 0.7, // 流入集中度
                outflow_following: true, // 随后流出
                price_reversal: true // 价格反转
            },
            
            // 骗炮特征
            fake_out: {
                large_inflow_single: true, // 单笔大额流入
                no_follow_through: true, // 无后续跟进
                price_drop_after: true // 随后下跌
            }
        },
        
        // 资金流向分析
        flow_analysis: {
            net_inflow_threshold: 1000000, // 净流入阈值
            inflow_consistency: 0.6, // 流入一致性
            sector_comparison: true // 板块对比
        },
        
        // 风险控制
        risk_control: {
            max_position_ratio: 0.1, // 最大持仓比例
            stop_loss: -0.05, // 止损比例
            take_profit: 0.15, // 止盈比例
            trailing_stop: 0.08 // 移动止损
        }
    };
    
    // 主力资金识别函数
    function identifyCapitalFlow(stockData, historicalData = []) {
        const analysis = {
            has_main_capital: false,
            capital_type: null,
            confidence: 0,
            signals: [],
            risk_level: "低"
        };
        
        // 检查是否有大额资金流入
        if (stockData.capital_inflow > capitalFlowRules.identification.min_amount) {
            analysis.has_main_capital = true;
            analysis.signals.push("检测到大额资金流入");
            
            // 分析主力意图
            const intention = analyzeIntention(stockData, historicalData);
            analysis.capital_type = intention.type;
            analysis.confidence = intention.confidence;
            analysis.signals.push(...intention.signals);
            analysis.risk_level = intention.risk_level;
        }
        
        return analysis;
    }
    
    // 主力意图分析函数
    function analyzeIntention(currentData, historicalData) {
        const result = {
            type: "未知",
            confidence: 0,
            signals: [],
            risk_level: "中"
        };
        
        // 如果有历史数据，进行趋势分析
        if (historicalData.length >= 3) {
            const recentDays = historicalData.slice(-3);
            
            // 检查建仓特征
            const isAccumulation = checkAccumulation(recentDays, currentData);
            if (isAccumulation) {
                result.type = "建仓";
                result.confidence = 70;
                result.signals.push("连续多日资金流入");
                result.signals.push("价格区间震荡");
                result.risk_level = "低";
                return result;
            }
            
            // 检查准备拉升特征
            const isPreparing = checkPreparing(recentDays, currentData);
            if (isPreparing) {
                result.type = "准备拉升";
                result.confidence = 65;
                result.signals.push("资金流入加速");
                result.signals.push("成交量温和放大");
                result.risk_level = "中";
                return result;
            }
            
            // 检查已经拉升特征
            const isLifting = checkLifting(recentDays, currentData);
            if (isLifting) {
                result.type = "已经拉升";
                result.confidence = 75;
                result.signals.push("价格上涨明显");
                result.signals.push("资金持续流入");
                result.risk_level = "高";
                return result;
            }
            
            // 检查一日游特征
            const isDayTrading = checkDayTrading(recentDays, currentData);
            if (isDayTrading) {
                result.type = "一日游";
                result.confidence = 60;
                result.signals.push("单日集中流入");
                result.signals.push("缺乏持续性");
                result.risk_level = "高";
                return result;
            }
            
            // 检查骗炮特征
            const isFakeOut = checkFakeOut(recentDays, currentData);
            if (isFakeOut) {
                result.type = "骗炮";
                result.confidence = 55;
                result.signals.push("大额单笔流入");
                result.signals.push("无后续跟进");
                result.risk_level = "极高";
                return result;
            }
        }
        
        // 基于当前数据的基本判断
        if (currentData.capital_inflow > currentData.capital_outflow * 2) {
            result.type = "资金净流入";
            result.confidence = 50;
            result.signals.push("当日资金净流入明显");
            result.risk_level = "中";
        } else if (currentData.capital_outflow > currentData.capital_inflow * 2) {
            result.type = "资金净流出";
            result.confidence = 50;
            result.signals.push("当日资金净流出明显");
            result.risk_level = "高";
        }
        
        return result;
    }
    
    // 各种意图的检查函数
    function checkAccumulation(days, current) {
        // 连续3天资金流入
        const inflowDays = days.filter(day => day.capital_inflow > day.capital_outflow).length;
        return inflowDays >= 2 && Math.abs(current.change) < 5;
    }
    
    function checkPreparing(days, current) {
        // 资金流入加速
        const avgInflow = days.reduce((sum, day) => sum + day.capital_inflow, 0) / days.length;
        return current.capital_inflow > avgInflow * 1.3 && current.volume > days[0].volume * 1.5;
    }
    
    function checkLifting(days, current) {
        // 价格上涨且资金持续流入
        const priceIncrease = current.price > days[0].price * 1.05;
        const consistentInflow = days.every(day => day.capital_inflow > day.capital_outflow);
        return priceIncrease && consistentInflow;
    }
    
    function checkDayTrading(days, current) {
        // 单日集中流入，之前无显著流入
        const prevInflow = days.slice(0, -1).reduce((sum, day) => sum + day.capital_inflow, 0);
        return current.capital_inflow > prevInflow * 3 && days[0].capital_inflow < current.capital_inflow * 0.3;
    }
    
    function checkFakeOut(days, current) {
        // 大额单笔流入，但价格随后下跌
        const hasLargeSingle = current.capital_inflow > 10000000; // 1000万
        const priceDrop = current.price < days[0].price;
        return hasLargeSingle && priceDrop;
    }
    
    // 资金流向评分函数
    function scoreCapitalFlow(analysis) {
        let score = 50; // 基础分
        
        // 根据主力类型加分
        const typeScores = {
            "建仓": 20,
            "准备拉升": 25,
            "已经拉升": 15,
            "资金净流入": 10,
            "未知": 0,
            "资金净流出": -20,
            "一日游": -15,
            "骗炮": -30
        };
        
        score += typeScores[analysis.capital_type] || 0;
        
        // 根据信心度调整
        score += analysis.confidence * 0.3;
        
        // 根据风险等级调整
        const riskAdjustments = {
            "低": 10,
            "中": 0,
            "高": -10,
            "极高": -20
        };
        
        score += riskAdjustments[analysis.risk_level] || 0;
        
        return Math.max(0, Math.min(100, Math.round(score)));
    }
    
    // 保存配置
    const configPath = path.join(__dirname, 'capital_flow_config.json');
    fs.writeFileSync(configPath, JSON.stringify(capitalFlowRules, null, 2), 'utf8');
    
    console.log(`✅ 主力资金分析框架创建完成`);
    console.log(`   配置文件: ${configPath}`);
    console.log(`   分析类型: 5种主力意图识别`);
    
    return {
        identifyCapitalFlow,
        analyzeIntention,
        scoreCapitalFlow,
        rules: capitalFlowRules
    };
}

// 3. 多维度验证系统
console.log("\n🔍 任务1.4: 多维度验证系统");
console.log("-".repeat(50));

function createMultiDimensionSystem() {
    console.log("🔍 创建多维度验证系统...");
    
    const validationDimensions = {
        // 技术面维度
        technical: {
            indicators: ["MA", "MACD", "RSI", "KDJ", "BOLL"],
            timeframes: ["daily", "weekly", "monthly"],
            weight: 0.25
        },
        
        // 基本面维度
        fundamental: {
            indicators: ["PE", "PB", "ROE", "Revenue_Growth", "Profit_Growth"],
            sectors: ["科技", "消费", "金融", "医药", "能源", "制造"],
            weight: 0.20
        },
        
        // 资金面维度
        capital: {
            indicators: ["Main_Inflow", "Retail_Inflow", "Institution_Inflow", "Northbound"],
            time_windows: ["1d", "3d", "5d", "10d"],
            weight: 0.30
        },
        
        // 市场情绪维度
        sentiment: {
            indicators: ["News_Sentiment", "Social_Media", "Search_Trend", "Market_Heat"],
            sources: ["新闻", "社交媒体", "搜索指数", "市场热度"],
            weight: 0.15
        },
        
        // 风险控制维度
        risk: {
            indicators: ["Volatility", "Drawdown", "Correlation", "Liquidity"],
            thresholds: {
                max_volatility: 0.3,
                max_drawdown: 0.15,
                min_liquidity: 1000000
            },
            weight: 0.10
        }
    };
    
    // 多维度验证函数
    function multiDimensionValidation(stockData, historicalData = []) {
        const validations = {
            technical: validateTechnical(stockData, historicalData),
            fundamental: validateFundamental(stockData),
            capital: validateCapital(stockData, historicalData),
            sentiment: validateSentiment(stockData),
            risk: validateRisk(stockData, historicalData)
        };
        
        // 计算综合得分