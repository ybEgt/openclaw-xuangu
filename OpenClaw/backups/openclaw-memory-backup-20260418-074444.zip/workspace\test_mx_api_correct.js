// 正确的mx-xuangu API测试
console.log("📡 正确的mx-xuangu API测试");
console.log("=".repeat(70));

const fs = require('fs');
const path = require('path');
const https = require('https');

// API配置
const API_CONFIG = {
    endpoint: "https://mkapi2.dfcfs.com/finskillshub/api/claw/stock-screen",
    apiKey: "mkt_fgN0XtXWjMxR9zxtDS9EkHx9pz6-OzfHl06C1ywGdls",
    timeout: 15000
};

// 获取API密钥
function getApiKey() {
    return process.env.MX_APIKEY || API_CONFIG.apiKey;
}

// 构建正确的请求数据
function buildRequestData() {
    const apiKey = getApiKey();
    
    // 根据API文档构建正确格式
    return {
        api_key: apiKey,
        conditions: {
            conditions: [
                {
                    field: "code",
                    operator: "regex",
                    value: "^60"
                }
            ],
            sort: [
                {
                    field: "change",
                    order: "desc"
                }
            ],
            limit: 10
        }
    };
}

// 发送测试请求
async function testApiConnection() {
    console.log("🔍 测试API连接...");
    
    const apiKey = getApiKey();
    if (!apiKey) {
        throw new Error("未找到API密钥");
    }
    
    const requestData = buildRequestData();
    const postData = JSON.stringify(requestData);
    
    console.log(`📤 发送请求到: ${API_CONFIG.endpoint}`);
    console.log(`🔑 API密钥: ${apiKey.substring(0, 15)}...`);
    console.log(`📦 请求数据格式:`);
    console.log(JSON.stringify(requestData, null, 2));
    
    return new Promise((resolve, reject) => {
        const options = {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'Content-Length': Buffer.byteLength(postData)
            },
            timeout: API_CONFIG.timeout
        };
        
        const req = https.request(API_CONFIG.endpoint, options, (res) => {
            console.log(`📥 收到响应: 状态码 ${res.statusCode}`);
            
            let data = '';
            res.on('data', (chunk) => {
                data += chunk;
            });
            
            res.on('end', () => {
                console.log(`📄 响应大小: ${data.length} 字节`);
                
                try {
                    const result = JSON.parse(data);
                    console.log(`✅ 响应解析成功`);
                    resolve(result);
                } catch (error) {
                    console.error(`❌ 响应解析失败: ${error.message}`);
                    console.log(`原始响应: ${data}`);
                    reject(new Error(`响应解析失败: ${error.message}`));
                }
            });
        });
        
        req.on('error', (error) => {
            console.error(`❌ 网络错误: ${error.message}`);
            reject(new Error(`网络错误: ${error.message}`));
        });
        
        req.on('timeout', () => {
            console.error(`❌ 请求超时`);
            req.destroy();
            reject(new Error('请求超时'));
        });
        
        req.write(postData);
        req.end();
    });
}

// 处理响应
function processResponse(result) {
    console.log("\n🔍 处理API响应...");
    
    if (result.success === true) {
        console.log(`✅ API请求成功`);
        
        if (result.data && Array.isArray(result.data)) {
            console.log(`📊 收到 ${result.data.length} 只股票数据`);
            
            if (result.data.length > 0) {
                console.log("\n📈 股票数据示例:");
                result.data.slice(0, 3).forEach((stock, index) => {
                    console.log(`\n${index + 1}. ${stock.code || 'N/A'} ${stock.name || 'N/A'}`);
                    
                    // 显示所有字段
                    Object.entries(stock).forEach(([key, value]) => {
                        if (typeof value === 'number') {
                            console.log(`   ${key}: ${value.toFixed(2)}`);
                        } else {
                            console.log(`   ${key}: ${value}`);
                        }
                    });
                });
            }
            
            return {
                success: true,
                stock_count: result.data.length,
                sample_data: result.data.slice(0, 3),
                message: result.message || "成功"
            };
        } else {
            console.log(`⚠️  数据格式: ${JSON.stringify(result.data)}`);
            return {
                success: true,
                stock_count: 0,
                data_structure: typeof result.data,
                message: result.message || "无数据"
            };
        }
    } else {
        console.log(`❌ API请求失败: ${result.message || '未知错误'}`);
        console.log(`状态码: ${result.code || result.status}`);
        
        return {
            success: false,
            error_code: result.code || result.status,
            error_message: result.message,
            request_id: result.requestId
        };
    }
}

// 主函数
async function main() {
    console.log("🚀 开始API连接测试...");
    console.log("=".repeat(70));
    
    try {
        const response = await testApiConnection();
        const result = processResponse(response);
        
        // 保存结果
        const timestamp = new Date().toISOString().replace(/[:.]/g, '-');
        const testDir = path.join(__dirname, 'api_tests');
        if (!fs.existsSync(testDir)) {
            fs.mkdirSync(testDir, { recursive: true });
        }
        
        const filepath = path.join(testDir, `api_response_${timestamp}.json`);
        fs.writeFileSync(filepath, JSON.stringify({
            timestamp: new Date().toISOString(),
            request: buildRequestData(),
            response: response,
            processed: result
        }, null, 2), 'utf8');
        
        console.log(`\n💾 完整结果已保存: ${filepath}`);
        
        // 更新系统状态
        updateSystemState(result.success, result.stock_count || 0, result.error_message);
        
        return {
            success: result.success,
            stock_count: result.stock_count || 0,
            message: result.message || result.error_message,
            file: filepath
        };
        
    } catch (error) {
        console.error(`\n❌ API测试失败: ${error.message}`);
        
        // 保存错误
        const errorDir = path.join(__dirname, 'api_tests', 'errors');
        if (!fs.existsSync(errorDir)) {
            fs.mkdirSync(errorDir, { recursive: true });
        }
        
        const errorFile = path.join(errorDir, `error_${Date.now()}.json`);
        fs.writeFileSync(errorFile, JSON.stringify({
            timestamp: new Date().toISOString(),
            error: error.message,
            stack: error.stack,
            api_config: API_CONFIG
        }, null, 2), 'utf8');
        
        console.log(`📝 错误报告已保存: ${errorFile}`);
        
        updateSystemState(false, 0, error.message);
        
        return {
            success: false,
            error: error.message,
            errorFile: errorFile
        };
    }
}

// 更新系统状态
function updateSystemState(success, stockCount, error = null) {
    const sessionStatePath = path.join(__dirname, 'SESSION-STATE.md');
    
    if (fs.existsSync(sessionStatePath)) {
        let content = fs.readFileSync(sessionStatePath, 'utf8');
        
        const update = `\n\n## 📡 mx-xuangu API详细测试 (${new Date().toLocaleString('zh-CN')})

### 测试详情
${success ? '✅ **请求成功**' : '❌ **请求失败**'}

**请求信息:**
- API端点: ${API_CONFIG.endpoint}
- 请求时间: ${new Date().toLocaleString('zh-CN')}
- API密钥: ${getApiKey().substring(0, 15)}...

${success ? `
**成功详情:**
- 收到数据: ${stockCount} 只股票
- 响应状态: 200 OK
- 数据格式: JSON

**结论:** API连接和参数传递正确
` : `
**失败详情:**
- 错误信息: ${error}
- 可能原因: API密钥格式错误、参数格式不符

**建议:**
1. 检查API密钥是否正确
2. 验证请求参数格式
3. 查看API文档确认参数要求
`}

### 下一步行动
${success && stockCount > 0 ? `
1. **完善选股条件** - 添加更多筛选维度
2. **数据验证** - 验证返回数据的准确性
3. **集成到系统** - 替换模拟数据
4. **性能测试** - 测试大数据量处理
` : success ? `
1. **调整筛选条件** - 当前条件可能无匹配股票
2. **测试其他条件** - 尝试不同筛选条件
3. **验证数据可用性** - 确认API数据范围
` : `
1. **参数调试** - 调整请求参数格式
2. **密钥验证** - 确认API密钥有效性
3. **联系支持** - 获取API使用帮助
`}`;
        
        content += update;
        fs.writeFileSync(sessionStatePath, content, 'utf8');
        
        console.log(`✅ 系统状态已更新`);
    }
}

// 运行测试
main().then(result => {
    console.log("\n" + "=".repeat(70));
    console.log("📋 最终测试结果:");
    console.log(`   成功: ${result.success ? '✅ 是' : '❌ 否'}`);
    
    if (result.success) {
        console.log(`   股票数量: ${result.stock_count}`);
        console.log(`   消息: ${result.message}`);
        console.log(`   结果文件: ${result.file}`);
        
        if (result.stock_count > 0) {
            console.log("\n🎉 API连接和数据获取都成功!");
            console.log("可以开始真实数据选股系统开发!");
        } else {
            console.log("\n⚠️  API连接成功但无数据返回");
            console.log("可能需要调整筛选条件");
        }
    } else {
        console.log(`   错误: ${result.error || result.message}`);
        console.log(`   错误文件: ${result.errorFile || result.file}`);
        console.log("\n🔧 需要调试API参数");
    }
    
    console.log("\n💡 建议下一步:");
    console.log("1. 检查保存的响应文件了解详细情况");
    console.log("2. 根据响应调整请求参数");
    console.log("3. 参考API文档确认正确格式");
    
    process.exit(result.success && result.stock_count > 0 ? 0 : 1);
});