// A股主板短线选股演示 - 完整流程
const nodemailer = require('nodemailer');
const fs = require('fs');
const path = require('path');

console.log("🎯 A股主板短线选股演示 - 完整流程");
console.log("=".repeat(70));

// 1. 选股约束配置
const STOCK_CONSTRAINTS = {
    // 主板代码模式
    mainBoard: {
        shanghai: /^60\d{4}$/,  // 沪市主板
        shenzhen: /^00\d{4}$/   // 深市主板
    },
    
    // 排除代码模式
    excluded: {
        starMarket: /^688\d{3}$/,  // 科创板
        gem: /^300\d{3}$/,         // 创业板
        beijing: /^8\d{5}$/,       // 北交所
        bShares: /^900\d{3}$/,     // B股
        others: /^(002|003|200|730|780)/ // 其他
    },
    
    // ST规则
    stRules: [/ST/, /\*ST/, /S\s*T/, /退市/, /风险警示/]
};

// 2. 股票验证函数
function validateStock(stock) {
    const { code, name, price_change, turnover_rate, status } = stock;
    
    // 检查主板代码
    const isShanghai = STOCK_CONSTRAINTS.mainBoard.shanghai.test(code);
    const isShenzhen = STOCK_CONSTRAINTS.mainBoard.shenzhen.test(code);
    
    if (!isShanghai && !isShenzhen) {
        // 检查排除代码
        for (const [type, pattern] of Object.entries(STOCK_CONSTRAINTS.excluded)) {
            if (pattern.test(code)) {
                return { valid: false, reason: `排除: ${type}` };
            }
        }
        return { valid: false, reason: "非主板代码" };
    }
    
    // 检查ST
    if (name) {
        for (const pattern of STOCK_CONSTRAINTS.stRules) {
            if (pattern.test(name)) {
                return { valid: false, reason: "ST股票" };
            }
        }
    }
    
    // 检查代码中的ST
    if (/ST/i.test(code)) {
        return { valid: false, reason: "代码含ST" };
    }
    
    // 检查停牌
    if (status && status.includes("停牌")) {
        return { valid: false, reason: "停牌" };
    }
    
    // 检查异常数据
    if (price_change && (price_change < -20 || price_change > 20)) {
        return { valid: false, reason: "涨跌幅异常" };
    }
    
    if (turnover_rate && turnover_rate > 50) {
        return { valid: false, reason: "换手率异常" };
    }
    
    return {
        valid: true,
        market: isShanghai ? "沪市主板" : "深市主板",
        code, name,
        analysis: "符合所有约束条件"
    };
}

// 3. 模拟股票数据
const mockStocks = [
    { code: "600519", name: "贵州茅台", price_change: 2.5, turnover_rate: 0.8, status: "正常" },
    { code: "000858", name: "五粮液", price_change: 1.8, turnover_rate: 1.2, status: "正常" },
    { code: "688981", name: "中芯国际", price_change: 3.2, turnover_rate: 2.5, status: "正常" },
    { code: "300750", name: "宁德时代", price_change: -1.5, turnover_rate: 1.8, status: "正常" },
    { code: "000002", name: "万科A", price_change: 0.5, turnover_rate: 0.9, status: "正常" },
    { code: "600123", name: "ST兰花", price_change: 5.2, turnover_rate: 3.5, status: "正常" },
    { code: "000001", name: "平安银行", price_change: 1.2, turnover_rate: 0.7, status: "正常" },
    { code: "600036", name: "招商银行", price_change: 0.8, turnover_rate: 0.6, status: "正常" },
    { code: "000333", name: "美的集团", price_change: 1.5, turnover_rate: 0.9, status: "正常" },
    { code: "600276", name: "恒瑞医药", price_change: -0.5, turnover_rate: 1.1, status: "正常" }
];

// 4. 执行选股筛选
console.log("\n🔍 执行选股筛选:");
console.log("=".repeat(70));

const screenedStocks = [];
const excludedStocks = [];

mockStocks.forEach(stock => {
    const validation = validateStock(stock);
    
    if (validation.valid) {
        screenedStocks.push({
            ...stock,
            validation
        });
        console.log(`✅ ${stock.code} ${stock.name}: 通过`);
    } else {
        excludedStocks.push({
            ...stock,
            validation
        });
        console.log(`❌ ${stock.code} ${stock.name}: ${validation.reason}`);
    }
});

console.log(`\n📊 筛选结果: ${screenedStocks.length} 只通过 / ${mockStocks.length} 只总数`);

// 5. 主力资金分析 (模拟)
console.log("\n💰 主力资金分析:");
console.log("=".repeat(70));

screenedStocks.forEach((stock, index) => {
    // 模拟主力资金分析
    const capitalFlow = Math.random() * 10000 - 5000; // 主力净流入(万元)
    const intentionTypes = ["建仓", "准备拉升", "已经拉升", "一日游", "骗炮"];
    const intention = intentionTypes[Math.floor(Math.random() * intentionTypes.length)];
    const confidence = Math.random() * 30 + 70; // 置信度70-100%
    const score = Math.random() * 30 + 70; // 综合评分70-100
    
    stock.analysis = {
        capital_flow: capitalFlow.toFixed(0),
        intention,
        confidence: confidence.toFixed(1),
        score: score.toFixed(1),
        recommendation: score > 80 ? "重点关注" : score > 70 ? "观察" : "谨慎"
    };
    
    console.log(`${index + 1}. ${stock.code} ${stock.name}`);
    console.log(`   主力净流入: ${stock.analysis.capital_flow}万元`);
    console.log(`   主力意图: ${stock.analysis.intention} (${stock.analysis.confidence}%置信)`);
    console.log(`   综合评分: ${stock.analysis.score}/100 - ${stock.analysis.recommendation}`);
});

// 6. 邮件发送配置
const QQ_EMAIL = "zhangyuru999@qq.com";
const QQ_PASSWORD = "yjhatgqnbailcahb";

const transporter = nodemailer.createTransport({
    host: "smtp.qq.com",
    port: 465,
    secure: true,
    auth: {
        user: QQ_EMAIL,
        pass: QQ_PASSWORD
    }
});

// 7. 生成选股报告邮件
async function sendScreeningReport() {
    console.log("\n📧 生成选股报告并发送邮件...");
    
    const reportDate = new Date().toLocaleString('zh-CN');
    const passedCount = screenedStocks.length;
    const totalCount = mockStocks.length;
    
    // 按评分排序
    const topStocks = [...screenedStocks]
        .sort((a, b) => b.analysis.score - a.analysis.score)
        .slice(0, 5);
    
    const emailContent = {
        from: `"A股选股研究助手" <${QQ_EMAIL}>`,
        to: QQ_EMAIL,
        subject: `📈 A股主板选股报告 - ${reportDate}`,
        text: `A股主板短线选股报告

报告时间: ${reportDate}
筛选条件: 主板(60xxxx/00xxxx), 排除ST/科创板/创业板等
筛选结果: ${passedCount}只通过 / ${totalCount}只总数

📊 精选股票 (前5名):
${topStocks.map((stock, i) => `${i+1}. ${stock.code} ${stock.name}
   主力净流入: ${stock.analysis.capital_flow}万元
   主力意图: ${stock.analysis.intention}
   综合评分: ${stock.analysis.score}/100
   建议: ${stock.analysis.recommendation}`).join('\n\n')}

🔍 筛选详情:
${screenedStocks.map(stock => `✅ ${stock.code} ${stock.name}`).join('\n')}

${excludedStocks.length > 0 ? `\n❌ 排除股票:\n${excludedStocks.map(stock => `${stock.code} ${stock.name}: ${stock.validation.reason}`).join('\n')}` : ''}

📋 系统信息:
• 系统: A股主板短线选股研究助手
• 策略: 主力资金分析框架
• 约束: 严格主板筛选
• 时间: ${reportDate}

⚠️ 风险提示:
本报告基于模拟数据生成，仅供参考。股市有风险，投资需谨慎。`,

        html: `<div style="font-family: 'Microsoft YaHei', Arial, sans-serif; max-width: 800px; margin: 0 auto; color: #333;">
    <div style="background: linear-gradient(135deg, #1890ff 0%, #096dd9 100%); padding: 30px; border-radius: 10px 10px 0 0; color: white; text-align: center;">
        <h1 style="margin: 0; font-size: 28px;">📈 A股主板选股报告</h1>
        <p style="margin: 10px 0 0; opacity: 0.9;">严格约束下的主力资金分析</p>
    </div>
    
    <div style="padding: 30px; background: white; border-radius: 0 0 10px 10px; box-shadow: 0 4px 12px rgba(0,0,0,0.1);">
        <!-- 报告头 -->
        <div style="margin-bottom: 30px;">
            <table style="width: 100%; border-collapse: collapse;">
                <tr>
                    <td style="padding: 8px 0; width: 100px; font-weight: bold;">报告时间:</td>
                    <td style="padding: 8px 0;">${reportDate}</td>
                </tr>
                <tr>
                    <td style="padding: 8px 0; font-weight: bold;">筛选条件:</td>
                    <td style="padding: 8px 0;">主板(60xxxx/00xxxx), 排除ST/科创板/创业板等</td>
                </tr>
                <tr>
                    <td style="padding: 8px 0; font-weight: bold;">筛选结果:</td>
                    <td style="padding: 8px 0;">
                        <span style="color: #52c41a; font-weight: bold;">${passedCount}只通过</span> / 
                        <span>${totalCount}只总数</span>
                    </td>
                </tr>
            </table>
        </div>
        
        <!-- 精选股票 -->
        <div style="margin-bottom: 30px;">
            <h2 style="color: #1890ff; border-bottom: 2px solid #1890ff; padding-bottom: 10px;">📊 精选股票 (前5名)</h2>
            <div style="overflow-x: auto;">
                <table style="width: 100%; border-collapse: collapse; border: 1px solid #ddd;">
                    <thead>
                        <tr style="background-color: #f5f5f5;">
                            <th style="padding: 12px; text-align: left; border: 1px solid #ddd;">排名</th>
                            <th style="padding: 12px; text-align: left; border: 1px solid #ddd;">代码</th>
                            <th style="padding: 12px; text-align: left; border: 1px solid #ddd;">名称</th>
                            <th style="padding: 12px; text-align: left; border: 1px solid #ddd;">主力净流入</th>
                            <th style="padding: 12px; text-align: left; border: 1px solid #ddd;">主力意图</th>
                            <th style="padding: 12px; text-align: left; border: 1px solid #ddd;">综合评分</th>
                            <th style="padding: 12px; text-align: left; border: 1px solid #ddd;">建议</th>
                        </tr>
                    </thead>
                    <tbody>
                        ${topStocks.map((stock, i) => `
                        <tr style="${i % 2 === 0 ? 'background-color: #fafafa;' : ''}">
                            <td style="padding: 12px; border: 1px solid #ddd; text-align: center;">${i+1}</td>
                            <td style="padding: 12px; border: 1px solid #ddd; font-family: monospace;">${stock.code}</td>
                            <td style="padding: 12px; border: 1px solid #ddd;">${stock.name}</td>
                            <td style="padding: 12px; border: 1px solid #ddd; text-align: right; color: ${stock.analysis.capital_flow > 0 ? '#cf1322' : '#389e0d'}">
                                ${stock.analysis.capital_flow}万元
                            </td>
                            <td style="padding: 12px; border: 1px solid #ddd;">
                                <span style="display: inline-block; padding: 4px 8px; background-color: ${getIntentionColor(stock.analysis.intention)}; color: white; border-radius: 4px; font-size: 12px;">
                                    ${stock.analysis.intention}
                                </span>
                            </td>
                            <td style="padding: 12px; border: 1px solid #ddd; text-align: center;">
                                <span style="font-weight: bold; color: ${getScoreColor(stock.analysis.score)}">
                                    ${stock.analysis.score}
                                </span>
                            </td>
                            <td style="padding: 12px; border: 1px solid #ddd;">
                                <span style="color: ${getRecommendationColor(stock.analysis.recommendation)}; font-weight: bold;">
                                    ${stock.analysis.recommendation}
                                </span>
                            </td>
                        </tr>
                        `).join('')}
                    </tbody>
                </table>
            </div>
        </div>
        
        <!-- 筛选详情 -->
        <div style="margin-bottom: 30px;">
            <h2 style="color: #1890ff; border-bottom: 2px solid #1890ff; padding-bottom: 10px;">🔍 筛选详情</h2>
            <div style="display: flex; flex-wrap: wrap; gap: 10px;">
                ${screenedStocks.map(stock => `
                <div style="background-color: #f6ffed; padding: 8px 16px; border-radius: 20px; font-size: 14px; border: 1px solid #b7eb8f;">
                    ✅ ${stock.code} ${stock.name}
                </div>
                `).join('')}
            </div>
        </div>
        
        ${excludedStocks.length > 0 ? `
        <!-- 排除股票 -->
        <div style="margin-bottom: 30px;">
            <h2 style="color: #ff4d4f; border-bottom: 2px solid #ff4d4f; padding-bottom: 10px;">❌ 排除股票</h2>
            <div style="background-color: #fff2f0; padding: 20px; border-radius: 8px;">
                <ul style="margin: 0; padding-left: 20px;">
                    ${excludedStocks.map(stock => `
                    <li style="margin-bottom: 8px;">
                        ${stock.code} ${stock.name}: 
                        <span style="color: #cf1322; font-weight: bold;">${stock.validation.reason}</span>
                    </li>
                    `).join('')}
                </ul>
            </div>
        </div>
        ` : ''}
        
        <!-- 系统信息 -->
        <div style="background-color: #f0f9ff; padding: 20px; border-radius: 8px; margin-bottom: 30px;">
            <h3 style="margin: 0 0 15px; color: #096dd9;">📋 系统信息</h3>
            <table style="width: 100%; border-collapse: collapse;">
                <tr>
                    <td style="padding: 8px 0; width: 100px; font-weight: bold;">系统:</td>
                    <td style="padding: 8px 0;">A股主板短线选股研究助手</td>
                </tr>
                <tr>
                    <td style="padding: 8px 0; font-weight: bold;">策略:</td>
                    <td style="padding: 8px 0;">主力资金分析框架</td>
                </tr>
                <tr>
                    <td style="padding: 8px 0; font-weight: bold;">约束:</td>
                    <td style="padding: 8px 0;">严格主板筛选 (60xxxx/00xxxx)</td>
                </tr>
                <tr