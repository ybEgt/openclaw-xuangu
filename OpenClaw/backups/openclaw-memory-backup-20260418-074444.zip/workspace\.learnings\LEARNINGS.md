## [LRN-20250416-001] skill_naming_inconsistency

**Logged**: 2025-04-16T10:30:00+08:00
**Priority**: medium
**Status**: pending
**Area**: config

### Summary
技能命名不一致导致可用性误判 - Agent Browser技能在技能列表中显示为"Agent Browser"，但在实际使用时需要安装agent-browser CLI工具

### Details
用户请求使用"Agent Browser"技能打开网页，技能列表中显示该技能可用，但实际执行时发现agent-browser命令未安装。技能名称"Agent Browser"与实际的CLI工具名"agent-browser"存在大小写和空格差异，导致误判技能可用性。

具体问题：
1. 技能列表显示：Agent Browser (技能文件：agent-browser-0/SKILL.md)
2. 实际CLI工具名：agent-browser (需要npm install -g agent-browser)
3. 技能描述中提到了安装步骤，但技能可用性检查仅基于技能文件存在，未验证实际工具是否安装

### Suggested Action
1. 在技能可用性检查中增加工具安装状态验证
2. 统一技能显示名称与实际工具名称
3. 在技能描述中更明确地说明安装要求

### Metadata
- Source: error
- Related Files: ~/.openclaw/workspace/skills/agent-browser-0/SKILL.md
- Tags: skill-management, tool-availability, installation-check
- Pattern-Key: skill.availability_verification

---
