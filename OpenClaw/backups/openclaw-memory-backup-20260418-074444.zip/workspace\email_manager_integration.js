// email-manager技能集成系统
const nodemailer = require('nodemailer');
const fs = require('fs');
const path = require('path');

console.log("📧 email-manager技能集成系统");
console.log("=".repeat(70));

// QQ邮箱配置
const QQ_EMAIL = "zhangyuru999@qq.com";
const QQ_PASSWORD = "yjhatgqnbailcahb";
const SMTP_SERVER = "smtp.qq.com";
const SMTP_PORT = 465;

// 创建transporter
const transporter = nodemailer.createTransport({
    host: SMTP_SERVER,
    port: SMTP_PORT,
    secure: true,
    auth: {
        user: QQ_EMAIL,
        pass: QQ_PASSWORD
    }
});

// 邮件模板
const emailTemplates = {
    // A股选股研究报告模板
    stock_research_report: (data) => ({
        subject: `📈 A股选股研究报告 - ${data.date || new Date().toLocaleDateString('zh-CN')}`,
        text: `A股主板短线选股研究报告

研究日期: ${data.date || new Date().toLocaleString('zh-CN')}
研究范围: ${data.scope || 'A股主板'}
筛选条件: ${data.criteria || '未指定'}

📊 选股结果:
${data.stocks ? data.stocks.map((stock, i) => `${i+1}. ${stock.code} ${stock.name} - ${stock.reason || '符合筛选条件'}`).join('\n') : '暂无选股结果'}

📈 市场分析:
${data.analysis || '基于技术面和基本面分析'}

⚠️ 风险提示:
${data.risks || '股市有风险，投资需谨慎。本报告仅供参考，不构成投资建议。'}

🔍 数据来源:
- 东方财富妙想API (mx-xuangu, mx-data, mx-search)
- 多搜索引擎信息整合 (multi-search-engine)
- 专业数据分析 (data-analyst, data-analyst-cn)

📋 报告生成:
A股主板短线选股研究助手
${new Date().toLocaleString('zh-CN')}`,

        html: `<div style="font-family: 'Microsoft YaHei', Arial, sans-serif; max-width: 800px; margin: 0 auto; color: #333;">
    <div style="background: linear-gradient(135deg, #1890ff 0%, #096dd9 100%); padding: 30px; border-radius: 10px 10px 0 0; color: white;">
        <h1 style="margin: 0; font-size: 28px;">📈 A股选股研究报告</h1>
        <p style="margin: 10px 0 0; opacity: 0.9;">专业、及时、全面的股票研究分析</p>
    </div>
    
    <div style="padding: 30px; background: white; border-radius: 0 0 10px 10px; box-shadow: 0 4px 12px rgba(0,0,0,0.1);">
        <!-- 基本信息 -->
        <div style="margin-bottom: 30px;">
            <h2 style="color: #1890ff; border-bottom: 2px solid #1890ff; padding-bottom: 10px;">📋 报告信息</h2>
            <table style="width: 100%; border-collapse: collapse;">
                <tr>
                    <td style="padding: 8px 0; width: 150px; font-weight: bold;">研究日期:</td>
                    <td style="padding: 8px 0;">${data.date || new Date().toLocaleString('zh-CN')}</td>
                </tr>
                <tr>
                    <td style="padding: 8px 0; font-weight: bold;">研究范围:</td>
                    <td style="padding: 8px 0;">${data.scope || 'A股主板'}</td>
                </tr>
                <tr>
                    <td style="padding: 8px 0; font-weight: bold;">筛选条件:</td>
                    <td style="padding: 8px 0;">${data.criteria || '未指定'}</td>
                </tr>
            </table>
        </div>
        
        <!-- 选股结果 -->
        <div style="margin-bottom: 30px;">
            <h2 style="color: #1890ff; border-bottom: 2px solid #1890ff; padding-bottom: 10px;">📊 选股结果</h2>
            ${data.stocks && data.stocks.length > 0 ? `
            <div style="overflow-x: auto;">
                <table style="width: 100%; border-collapse: collapse; border: 1px solid #ddd;">
                    <thead>
                        <tr style="background-color: #f5f5f5;">
                            <th style="padding: 12px; text-align: left; border: 1px solid #ddd;">序号</th>
                            <th style="padding: 12px; text-align: left; border: 1px solid #ddd;">股票代码</th>
                            <th style="padding: 12px; text-align: left; border: 1px solid #ddd;">股票名称</th>
                            <th style="padding: 12px; text-align: left; border: 1px solid #ddd;">入选理由</th>
                        </tr>
                    </thead>
                    <tbody>
                        ${data.stocks.map((stock, i) => `
                        <tr style="${i % 2 === 0 ? 'background-color: #fafafa;' : ''}">
                            <td style="padding: 12px; border: 1px solid #ddd;">${i+1}</td>
                            <td style="padding: 12px; border: 1px solid #ddd; font-family: monospace;">${stock.code}</td>
                            <td style="padding: 12px; border: 1px solid #ddd;">${stock.name}</td>
                            <td style="padding: 12px; border: 1px solid #ddd;">${stock.reason || '符合筛选条件'}</td>
                        </tr>
                        `).join('')}
                    </tbody>
                </table>
            </div>
            ` : '<p style="color: #999; text-align: center; padding: 20px;">暂无选股结果</p>'}
        </div>
        
        <!-- 市场分析 -->
        <div style="margin-bottom: 30px;">
            <h2 style="color: #1890ff; border-bottom: 2px solid #1890ff; padding-bottom: 10px;">📈 市场分析</h2>
            <div style="background-color: #f0f9ff; padding: 20px; border-radius: 8px; border-left: 4px solid #1890ff;">
                <p style="margin: 0; line-height: 1.6;">${data.analysis || '基于技术面和基本面分析，结合市场情绪和资金流向进行综合评估。'}</p>
            </div>
        </div>
        
        <!-- 风险提示 -->
        <div style="margin-bottom: 30px;">
            <h2 style="color: #ff4d4f; border-bottom: 2px solid #ff4d4f; padding-bottom: 10px;">⚠️ 风险提示</h2>
            <div style="background-color: #fff2f0; padding: 20px; border-radius: 8px; border-left: 4px solid #ff4d4f;">
                <p style="margin: 0; line-height: 1.6;">${data.risks || '股市有风险，投资需谨慎。本报告基于公开数据和算法分析生成，仅供参考，不构成投资建议。投资者应独立判断并承担相应风险。'}</p>
            </div>
        </div>
        
        <!-- 数据来源 -->
        <div style="margin-bottom: 30px;">
            <h2 style="color: #1890ff; border-bottom: 2px solid #1890ff; padding-bottom: 10px;">🔍 数据来源</h2>
            <div style="display: flex; flex-wrap: wrap; gap: 10px;">
                <span style="background-color: #e6f7ff; padding: 8px 16px; border-radius: 20px; font-size: 14px;">东方财富妙想API</span>
                <span style="background-color: #f6ffed; padding: 8px 16px; border-radius: 20px; font-size: 14px;">多搜索引擎整合</span>
                <span style="background-color: #f0f9ff; padding: 8px 16px; border-radius: 20px; font-size: 14px;">专业数据分析</span>
                <span style="background-color: #fff7e6; padding: 8px 16px; border-radius: 20px; font-size: 14px;">实时行情数据</span>
            </div>
        </div>
        
        <!-- 报告信息 -->
        <div style="border-top: 1px solid #ddd; padding-top: 20px; margin-top: 30px; color: #666;">
            <p style="margin: 0; font-size: 14px;">
                <strong>报告生成系统:</strong> A股主板短线选股研究助手<br>
                <strong>生成时间:</strong> ${new Date().toLocaleString('zh-CN')}<br>
                <strong>系统版本:</strong> 集成email-manager技能 v1.0
            </p>
            <p style="margin: 10px 0 0; font-size: 12px; color: #999;">
                ※ 本报告由AI系统自动生成，数据仅供参考，不保证准确性。
            </p>
        </div>
    </div>
</div>`
    }),

    // 市场风险预警模板
    risk_alert: (data) => ({
        subject: `🚨 市场风险预警 - ${data.title || '重要风险提示'}`,
        text: `市场风险预警通知

预警级别: ${data.level || '中等'}
预警时间: ${new Date().toLocaleString('zh-CN')}
影响范围: ${data.scope || 'A股市场'}

📢 预警内容:
${data.content || '检测到市场异常波动或潜在风险'}

💡 建议措施:
${data.suggestions || '建议谨慎操作，控制仓位，关注后续发展'}

📊 相关数据:
${data.data || '基于实时行情和数据分析'}

⚠️ 注意事项:
1. 本预警基于算法分析，仅供参考
2. 市场变化快速，请及时关注最新信息
3. 投资决策需结合个人风险承受能力

A股主板短线选股研究助手
风险监控系统`,

        html: `<div style="font-family: 'Microsoft YaHei', Arial, sans-serif; max-width: 800px; margin: 0 auto; color: #333;">
    <div style="background: linear-gradient(135deg, #ff4d4f 0%, #cf1322 100%); padding: 30px; border-radius: 10px 10px 0 0; color: white;">
        <h1 style="margin: 0; font-size: 28px;">🚨 市场风险预警</h1>
        <p style="margin: 10px 0 0; opacity: 0.9;">及时、准确的风险识别与预警</p>
    </div>
    
    <div style="padding: 30px; background: white; border-radius: 0 0 10px 10px; box-shadow: 0 4px 12px rgba(0,0,0,0.1);">
        <!-- 预警头 -->
        <div style="text-align: center; margin-bottom: 30px;">
            <div style="display: inline-block; background-color: #fff2f0; padding: 20px 40px; border-radius: 10px; border: 2px solid #ff4d4f;">
                <h2 style="color: #cf1322; margin: 0 0 10px;">${data.level || '中等'}风险预警</h2>
                <p style="margin: 0; color: #666;">${new Date().toLocaleString('zh-CN')}</p>
            </div>
        </div>
        
        <!-- 预警内容 -->
        <div style="margin-bottom: 30px;">
            <h3 style="color: #1890ff; margin-bottom: 15px;">📢 预警内容</h3>
            <div style="background-color: #fff7e6; padding: 20px; border-radius: 8px; border-left: 4px solid #faad14;">
                <p style="margin: 0; line-height: 1.6; font-size: 16px;">${data.content || '检测到市场异常波动或潜在风险，请密切关注。'}</p>
            </div>
        </div>
        
        <!-- 影响范围 -->
        <div style="margin-bottom: 30px;">
            <h3 style="color: #1890ff; margin-bottom: 15px;">🌐 影响范围</h3>
            <div style="background-color: #f6ffed; padding: 15px; border-radius: 8px;">
                <p style="margin: 0;">${data.scope || 'A股市场及相关板块'}</p>
            </div>
        </div>
        
        <!-- 建议措施 -->
        <div style="margin-bottom: 30px;">
            <h3 style="color: #1890ff; margin-bottom: 15px;">💡 建议措施</h3>
            <div style="background-color: #e6f7ff; padding: 20px; border-radius: 8px;">
                <ul style="margin: 0; padding-left: 20px;">
                    ${(data.suggestions || '建议谨慎操作，控制仓位，关注后续发展').split('\n').map(s => `<li style="margin-bottom: 8px;">${s}</li>`).join('')}
                </ul>
            </div>
        </div>
        
        <!-- 数据支持 -->
        <div style="margin-bottom: 30px;">
            <h3 style="color: #1890ff; margin-bottom: 15px;">📊 数据支持</h3>
            <div style="display: flex; flex-wrap: wrap; gap: 10px;">
                <span style="background-color: #f0f9ff; padding: 8px 16px; border-radius: 20px; font-size: 14px;">实时行情监控</span>
                <span style="background-color: #f6ffed; padding: 8px 16px; border-radius: 20px; font-size: 14px;">资金流向分析</span>
                <span style="background-color: #fff7e6; padding: 8px 16px; border-radius: 20px; font-size: 14px;">市场情绪检测</span>
                <span style="background-color: #fff2f0; padding: 8px 16px; border-radius: 20px; font-size: 14px;">风险模型评估</span>
            </div>
        </div>
        
        <!-- 注意事项 -->
        <div style="background-color: #fafafa; padding: 20px; border-radius: 8px; border: 1px solid #ddd;">
            <h4 style="color: #666; margin-top: 0;">⚠️ 注意事项</h4>
            <ol style="margin: 0; padding-left: 20px; color: #666;">
                <li style="margin-bottom: 8px;">本预警基于算法分析，仅供参考</li>
                <li style="margin-bottom: 8px;">市场变化快速，请及时关注最新信息</li>
                <li style="margin-bottom: 8px;">投资决策需结合个人风险承受能力</li>
                <li>如有疑问，请咨询专业投资顾问</li>
            </ol>
        </div>
        
        <!-- 底部信息 -->
        <div style="border-top: 1px solid #ddd; padding-top: 20px; margin-top: 30px; text-align: center; color: #999;">
            <p style="margin: 0; font-size: 14px;">
                A股主板短线选股研究助手 · 风险监控系统<br>
                ${new Date().toLocaleString('zh-CN')}
            </p>
        </div>
    </div>
</div>`
    }),

    // 系统状态报告模板
    system_status: (data) => ({
        subject: `🔄 系统状态报告 - A股选股研究助手`,
        text: `系统状态报告

报告时间: ${new Date().toLocaleString('zh-CN')}
系统名称: A股主板短线选股研究助手

📊 系统状态:
${data.status || '运行正常'}

🛠️ 技能集成:
${data.skills || '9个核心技能已集成'}

📈 最近活动:
${data.activities || '选股研究、数据分析、风险监控'}

🔧 配置更新:
${data.updates || 'email-manager技能配置完成'}

📋 下一步计划:
${data.plans || '优化选股算法，增强风险控制'}

A股主板短线选股研究助手
系统监控中心`,

        html: `<div style="font-family: 'Microsoft YaHei', Arial, sans-serif; max-width: 800px; margin: 0 auto; color: #333;">
    <div style="background: linear-gradient(135deg, #52c41a 0%, #389e0d 100%); padding: 30px; border-radius: 10px 10px 0 0; color: white;">
        <h1 style="margin: 0; font-size: